// ignore_for_file: unused_local_variable, unused_import

import 'dart:convert';
import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:homeplus_phase1/backgroundService.dart';
import 'package:homeplus_phase1/page/splashScreenPage.dart';
import 'package:permission_handler/permission_handler.dart';

import 'cookiesValue.dart';

import 'package:http/http.dart' as http;
import 'package:restart_app/restart_app.dart';

//ไฟล์นี้จะเป็นไฟล์แรกที่โปรแกรมจะเริ่มทำงาน

// class MyHttpOverrides extends HttpOverrides {
//   @override
//   HttpClient createHttpClient(SecurityContext? context) {
//     return super.createHttpClient(context)
//       ..badCertificateCallback =
//           (X509Certificate cert, String host, int port) => true;
//   }
// }

void main() async {
  //HttpOverrides.global = MyHttpOverrides();
  WidgetsFlutterBinding.ensureInitialized();

  LocationPermission permission =
      await Geolocator.requestPermission(); //ร้องขอการเข้าถึงตำแหน่ง

  await Firebase.initializeApp();
  await initializeService(); // bg service start

  FirebaseMessaging.instance.getToken().then((value) {
    print("get token : $value");
    setCookie('tokenPhone', value.toString());
  });

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);
  final AppStateObserver _appStateObserver = AppStateObserver();

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addObserver(_appStateObserver);
    return WillPopScope(
      onWillPop: () async => false,
      child: MaterialApp(
        //title: 'Flutter Demo',
        navigatorKey: NavigationService
            .navigatorKey, //กำหนดค่า global context เรียกใช้จริงใน initState ในไฟล์ loginPage
        theme: ThemeData(
            fontFamily: 'FCfont'), //กำหนดธีมของแอปให้ฟ้อนต์เป็น FCfont
        debugShowCheckedModeBanner: false, //ลบ logo debug ที่แสดงตอนรันแอปออก

        //   routes: <String, WidgetBuilder> {
        //   '/a': (BuildContext context) => const AddDevicePage(),
        // },
        home:
            const SplashScreenPage(), //ส่วนนี้จะเป็นการเรียกใช้ไฟล์ทีเราต้องการให้มันแสดงเป็นหน้าแรกของแอป
      ),
    ); //SplashScreenPage
  }
}

//เป็นการกำหนด global context เพื่อที่จะใช้ในการแสดงตัว pop up เมื่อมีการ login ซ้อน
class NavigationService {
  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
}

class AppStateObserver extends WidgetsBindingObserver {
  bool isAppOpen = false;

  @override
  Future<void> didChangeAppLifecycleState(AppLifecycleState state) async {
    super.didChangeAppLifecycleState(state);

    switch (state) {
      case AppLifecycleState.resumed:
        // App is in the foreground
        isAppOpen = true;
        print('isAppOpen');
        break;
      case AppLifecycleState.inactive:
        print('inactive');
        break;
      case AppLifecycleState.paused:
        print('pause: ${await getCookie("clientIdSelectedDevice")}');
        if (await getCookie("clientIdSelectedDevice") != "null") {
          //call api
          await cancelUseDevice();
          //clear cookie
          Restart.restartApp();
        }

        break;
      case AppLifecycleState.detached:
        // App is in the background or not running
        isAppOpen = false;
        print('isAppClose');
        if (await getCookie("clientIdSelectedDevice") != "null") {
          //call api
          await cancelUseDevice();
          //clear cookie
          //Restart.restartApp();
        }

        // if (getCookie("clientIdSelectedDevice").toString() != "") {
        //   //pop up navigator

        //   //call api
        //   //clear cookie
        // }
        break;
    }
  }
}

cancelUseDevice() async {
  print('[getAllPersonInHouse] Im getAllPersonInHouse function');
  String tempSn = await getCookie('serial');
  String uid = await getUserId();
  String urlBase = await getUrlBase();

  Uri myUri = Uri.parse('$urlBase/cancelUseDevice');
  try {
    http.Response response = await http.post(myUri,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        encoding: Encoding.getByName('utf-8'),
        body: {"userid": uid, "serialNumber": tempSn});

    print('[getAllPersonInHouse] status Code : ${response.statusCode}');
  } catch (e) {
    print('[getAllPersonInHouse] error: $e');
  }
}



//flutter build apk --target-platform android-arm,android-arm64 --split-per-abi
//--no-sound-null-safety
//build apk : flutter build apk --split-per-abi --no-sound-null-safety



///scan wifi
// import 'dart:async';

// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:wifi_scan/wifi_scan.dart';

// void main() {
//   runApp(const MyApp());
// }

// /// Example app for wifi_scan plugin.
// class MyApp extends StatefulWidget {
//   /// Default constructor for [MyApp] widget.
//   const MyApp({Key? key}) : super(key: key);

//   @override
//   State<MyApp> createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> {
//   List<WiFiAccessPoint> accessPoints = <WiFiAccessPoint>[];
//   StreamSubscription<List<WiFiAccessPoint>>? subscription;
//   bool shouldCheckCan = true;

//  // bool get isStreaming => subscription != null;

//   // Future<void> _startScan(BuildContext context) async {
//   //   // check if "can" startScan
//   //   if (shouldCheckCan) {
//   //     // check if can-startScan
//   //     final can = await WiFiScan.instance.canStartScan();
//   //     // if can-not, then show error
//   //     if (can != CanStartScan.yes) {
//   //       if (mounted) kShowSnackBar(context, "Cannot start scan: $can");
//   //       return;
//   //     }
//   //   }

//   //   // call startScan API
//   //   final result = await WiFiScan.instance.startScan();
//   //   if (mounted) kShowSnackBar(context, "startScan: $result");
//   //   // reset access points.
//   //   setState(() => accessPoints = <WiFiAccessPoint>[]);
//   // }

//   Future<bool> _canGetScannedResults(BuildContext context) async {
//     if (shouldCheckCan) {
//       // check if can-getScannedResults
//       final can = await WiFiScan.instance.canGetScannedResults();
//       // if can-not, then show error
//       if (can != CanGetScannedResults.yes) {
//         if (mounted) kShowSnackBar(context, "Cannot get scanned results: $can");
//         accessPoints = <WiFiAccessPoint>[];
//         return false;
//       }
//     }
//     return true;
//   }

//   Future<void> _getScannedResults(BuildContext context) async {
//     if (await _canGetScannedResults(context)) {
//       // get scanned results
//       final results = await WiFiScan.instance.getScannedResults();
//       setState(() => accessPoints = results);
//     }
//   }

//   // Future<void> _startListeningToScanResults(BuildContext context) async {
//   //   if (await _canGetScannedResults(context)) {
//   //     subscription = WiFiScan.instance.onScannedResultsAvailable
//   //         .listen((result) => setState(() => accessPoints = result));
//   //   }
//   // }

//   // void _stopListeningToScanResults() {
//   //   subscription?.cancel();
//   //   setState(() => subscription = null);
//   // }

//   // @override
//   // void dispose() {
//   //   super.dispose();
//   //   // stop subscription for scanned results
//   //   _stopListeningToScanResults();
//   // }

//   // // build toggle with label
//   // Widget _buildToggle({
//   //   String? label,
//   //   bool value = false,
//   //   ValueChanged<bool>? onChanged,
//   //   Color? activeColor,
//   // }) =>
//   //     Row(
//   //       children: [
//   //         if (label != null) Text(label),
//   //         Switch(value: value, onChanged: onChanged, activeColor: activeColor),
//   //       ],
//   //     );

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         // appBar: AppBar(
//         //   title: const Text('Plugin example app'),
//         //   actions: [
//         //     _buildToggle(
//         //         label: "Check can?",
//         //         value: shouldCheckCan,
//         //         onChanged: (v) => setState(() => shouldCheckCan = v),
//         //         activeColor: Colors.purple)
//         //   ],
//         // ),
//         body: Builder(
//           builder: (context) => Padding(
//             padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
//             child: Column(
//               mainAxisSize: MainAxisSize.max,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     // ElevatedButton.icon(
//                     //   icon: const Icon(Icons.perm_scan_wifi),
//                     //   label: const Text('SCAN'),
//                     //   onPressed: () async => _startScan(context),
//                     // ),
//                     ElevatedButton.icon(
//                       icon: const Icon(Icons.refresh),
//                       label: const Text('GET'),
//                       onPressed: () async => _getScannedResults(context),
//                     ),
//                     // _buildToggle(
//                     //   label: "STREAM",
//                     //   value: isStreaming,
//                     //   onChanged: (shouldStream) async => shouldStream
//                     //       ? await _startListeningToScanResults(context)
//                     //       : _stopListeningToScanResults(),
//                     // ),
//                   ],
//                 ),
//                 const Divider(),
//                 Flexible(
//                   child: Center(
//                     child: accessPoints.isEmpty
//                         ? const Text("NO SCANNED RESULTS")
//                         : ListView.builder(
//                             itemCount: accessPoints.length,
//                             itemBuilder: (context, i) =>
//                                 _AccessPointTile(accessPoint: accessPoints[i])),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// /// Show tile for AccessPoint.
// ///
// /// Can see details when tapped.
// class _AccessPointTile extends StatelessWidget {
//   final WiFiAccessPoint accessPoint;

//   const _AccessPointTile({Key? key, required this.accessPoint})
//       : super(key: key);

//   // build row that can display info, based on label: value pair.
//   Widget _buildInfo(String label, dynamic value) => Container(
//         decoration: const BoxDecoration(
//           border: Border(bottom: BorderSide(color: Colors.grey)),
//         ),
//         child: Row(
//           children: [
//             Text(
//               "$label: ",
//               style: const TextStyle(fontWeight: FontWeight.bold),
//             ),
//             Expanded(child: Text(value.toString()))
//           ],
//         ),
//       );

//   @override
//   Widget build(BuildContext context) {
//     final title = accessPoint.ssid.isNotEmpty ? accessPoint.ssid : "**EMPTY**";
//     final signalIcon = accessPoint.level >= -80
//         ? Icons.signal_wifi_4_bar
//         : Icons.signal_wifi_0_bar;
//     return ListTile(
//       visualDensity: VisualDensity.compact,
//       leading: Icon(signalIcon),
//       title: Text(title),
//       subtitle: Text(accessPoint.capabilities),
//       onTap: () => showDialog(
//         context: context,
//         builder: (context) => AlertDialog(
//           title: Text(title),
//           content: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               _buildInfo("BSSDI", accessPoint.bssid),
//               _buildInfo("Capability", accessPoint.capabilities),
//               _buildInfo("frequency", "${accessPoint.frequency}MHz"),
//               _buildInfo("level", accessPoint.level),
//               _buildInfo("standard", accessPoint.standard),
//               _buildInfo(
//                   "centerFrequency0", "${accessPoint.centerFrequency0}MHz"),
//               _buildInfo(
//                   "centerFrequency1", "${accessPoint.centerFrequency1}MHz"),
//               _buildInfo("channelWidth", accessPoint.channelWidth),
//               _buildInfo("isPasspoint", accessPoint.isPasspoint),
//               _buildInfo(
//                   "operatorFriendlyName", accessPoint.operatorFriendlyName),
//               _buildInfo("venueName", accessPoint.venueName),
//               _buildInfo("is80211mcResponder", accessPoint.is80211mcResponder),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// /// Show snackbar.
// void kShowSnackBar(BuildContext context, String message) {
//   if (kDebugMode) print(message);
//   ScaffoldMessenger.of(context)
//     ..hideCurrentSnackBar()
//     ..showSnackBar(SnackBar(content: Text(message)));
// }
