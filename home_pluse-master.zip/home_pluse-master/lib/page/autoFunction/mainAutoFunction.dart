import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/autoFunction/selectFunction.dart';
// import 'package:homeplus_phase1/page/autoFunction/systemNotification.dart';
// import 'package:shared_preferences/shared_preferences.dart';
import '../../modelData/getDeviceAutoListModel.dart';
import '../../cookiesValue.dart';
import 'package:http/http.dart' as http;

class MainAutoFunctionPage extends StatefulWidget {
  const MainAutoFunctionPage({super.key});

  @override
  State<MainAutoFunctionPage> createState() => _MainAutoFunctionPageState();
}

class _MainAutoFunctionPageState extends State<MainAutoFunctionPage> {
  //get list device with auto status
  GetDeviceAutoListModel? deiviceAutoList;
  Future<GetDeviceAutoListModel?> getDeviceAutoListApi() async {
    print('[getDeviceAutoListApi] Im getDeviceAutoListApi function');
    String userid = await getUserId();
    String houseid = await getHouseId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/deviceAutoList');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"houseid": houseid, "userid": userid});

      print('[getDeviceAutoListApi] status Code : ${response.statusCode}');
      print('[getDeviceAutoListApi] response body : ${response.body}');
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'].toString() == 'false') {
        deiviceAutoList = getDeviceAutoListModelFromJson(response.body);
        print('[getDeviceAutoListApi] finsih!');
        return deiviceAutoList;
      } else {
        return null; //return null if error happened
      }
    } catch (e) {
      print('[getDeviceAutoListApi] error: $e');
      return null;
    }
  }

  Future<void> _pullRefresh() async {
    setState(() {});
    // why use freshNumbers var? https://stackoverflow.com/a/52992836/2301224
  }

  @override
  void initState() {
    removeCookie('serialNumberAuto');
    removeCookie('clientIDAuto');
    removeCookie('tokenAuto');
    removeCookie('cancelAuto');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
      child: RefreshIndicator(
          onRefresh: _pullRefresh,
          child: FutureBuilder(
            future: getDeviceAutoListApi(),
            builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                if (snapshot.data != null) {
                  print('snapshot data in data: ${snapshot.data.data.length}');
                  return Container(
                      width: size.width,
                      height: size.height,
                      color: const Color.fromARGB(255, 243, 243, 243),
                      child: Column(
                        children: [
                          //AppBar
                          Container(
                            width: size.width,
                            height: size.height * 0.13,
                            padding: const EdgeInsets.only(
                                left: 20, right: 10, top: 20),
                            alignment: Alignment.bottomLeft,
                            child: Row(
                              children: [
                                const Text(
                                  'Automatic Function',
                                  style: TextStyle(
                                      fontSize: 25,
                                      fontWeight: FontWeight.bold),
                                ),
                                const Spacer(),
                                Container(),
                                // Container(
                                //   height: size.height * 0.12,
                                //   alignment: Alignment.centerLeft,
                                //   child: IconButton(
                                //     icon: const Icon(Icons.notifications),
                                //     onPressed: () {
                                //       print('go system notification page');
                                //       Navigator.of(context)
                                //           .push(MaterialPageRoute(
                                //               builder: (context) =>
                                //                   const SystemNotificationPage()))
                                //           .then((value) {
                                //         setState(() {});
                                //       });
                                //     },
                                //   ),
                                // ),
                              ],
                            ),
                          ),

                          //body
                          SizedBox(
                              width: size.width,
                              height: size.height * 0.745,
                              child: ListView(
                                children: [
                                  if (snapshot.data.data.length != 0) ...{
                                    for (int i = 0;
                                        i < snapshot.data.data.length;
                                        i++) ...{
                                      deviceBox(
                                          serialNumber: snapshot
                                              .data.data[i].serialNumber
                                              .toString(),
                                          name: snapshot.data.data[i].deviceName
                                              .toString(),
                                          room: snapshot.data.data[i].room
                                              .toString(),
                                          clientID: snapshot
                                              .data.data[i].clientId
                                              .toString(),
                                          token: snapshot.data.data[i].token
                                              .toString(),
                                          setTimeStatus: snapshot
                                              .data.data[i].setTimeStatus
                                              .toString(),
                                          countTimeStatus: snapshot
                                              .data.data[i].countTimeStatus
                                              .toString()),
                                    }
                                  } else ...{
                                    //show no have any device in this house
                                    SizedBox(
                                      width: size.width,
                                      height: size.height * 0.7,
                                      //color: Colors.red,
                                      child: const Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            Icon(
                                              Icons.desktop_windows,
                                              size: 100,
                                              color: Color.fromARGB(
                                                  255, 180, 180, 220),
                                            ),
                                            Text("Don't have any device.",
                                                style: TextStyle(
                                                    fontSize: 24,
                                                    color: Color.fromARGB(
                                                        255, 180, 180, 220),
                                                    fontWeight:
                                                        FontWeight.w600))
                                          ]),
                                    )
                                  }
                                ],
                              ))
                        ],
                      ));
                } else {
                  //connect failed!
                  return connectFailed();
                }
              } else {
                //loading...
                return loadingBox();
              }
            },
          )),
    );
  }

  //เป็น box สำหรับแสดงอุปกรณ์
  deviceBox(
      {serialNumber,
      name,
      room,
      clientID,
      token,
      setTimeStatus,
      countTimeStatus}) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ

    return Container(
      width: size.width,
      height: 123.08571428571427, //size.height * 0.15,
      padding: const EdgeInsets.only(left: 30, right: 30),
      margin: const EdgeInsets.only(bottom: 20),
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          foregroundColor: Colors.white,
          padding:
              const EdgeInsets.only(top: 30, bottom: 20, left: 30, right: 25),
        ),
        onPressed: () async {
          //print('go smart plug page');
          //set serialnumber,clientID and token cookies of device for using in the next page.
          setCookie("serialNumberAuto", serialNumber);
          setCookie("clientIDAuto", clientID);
          setCookie("tokenAuto", token);

          //push to next page by send set and count time status
          Navigator.of(context)
              .push(MaterialPageRoute(
                  builder: (context) => SelectFunction(nameDevice: name)))
              .then((value) {
            setState(() {}); //รีบิ้วเมื่อกลับมาหน้า mainpage
          });
        },
        child: Row(
          children: [
            SizedBox(
              width: size.width * 0.5,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w600,
                          color: Colors.black)),
                  Text(room,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w600,
                          color: Colors.black38))
                ],
              ),
            ),
            const Spacer(),
            SizedBox(
                //width: 100,
                height: 30,
                child: Row(
                  children: [
                    //set time icon
                    // Icon(
                    //   Icons.access_alarm,
                    //   color: setTimeStatus != "idle"
                    //       ? const Color.fromARGB(255, 117, 138, 214)
                    //       : Colors.black26,
                    // ),
                    // Spacer(),
                    //const SizedBox(width: 5),
                    Icon(
                      Icons.access_time,
                      color: countTimeStatus != "idle"
                          ? const Color.fromARGB(255, 117, 138, 214)
                          : Colors.black26,
                    ),
                    // Spacer(),
                    const SizedBox(width: 5),
                    const Icon(
                      Icons.arrow_forward_ios,
                      color: Colors.black,
                    ),
                  ],
                )),
          ],
        ),
      ),
    );
  }

  //แสดงตอนเชื่อมต่อล้มเหลว snapshot = null
  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Connection failed!',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width * 0.3,
            height: size.height * 0.06,
            child: TextButton(
              style: TextButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                foregroundColor: Colors.white,
                padding: EdgeInsets.zero,
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {}); //กดปุ่มแล้วจะรีบิ้วใหม่
              },
              child: const Text(
                'Try again',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'FCfont',
                  fontSize: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  //โหลดหน้ารอ snapshot
  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Loading...',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }
}
