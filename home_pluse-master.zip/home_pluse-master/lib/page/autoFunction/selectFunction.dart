import 'dart:convert';

import 'package:flutter/material.dart';
//import 'package:homeplus_phase1/page/autoFunction/setPeriodFunction.dart';
import 'package:homeplus_phase1/page/autoFunction/setTimeFunction.dart';
import 'package:http/http.dart' as http;
import '../../cookiesValue.dart';
import '../../modelData/getDeviceAutoListModel.dart';
import 'newSetPeriodFunction.dart';

class SelectFunction extends StatefulWidget {
  const SelectFunction({
    super.key,
    required this.nameDevice,
  });

  final String nameDevice;

  @override
  State<SelectFunction> createState() => _SelectFunctionState();
}

class _SelectFunctionState extends State<SelectFunction> {
  var deviceDetail;
  Future<GetDeviceAutoListModel?> getDeviceAutoListApi() async {
    print('[getDeviceAutoListApi] Im getDeviceAutoListApi function');
    String userid = await getUserId();
    String houseid = await getHouseId();
    String urlBase = await getUrlBase();

    String tempSn = await getCookie('serialNumberAuto');

    Uri myUri = Uri.parse('$urlBase/deviceAutoList');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"houseid": houseid, "userid": userid});

      print('[getDeviceAutoListApi] status Code : ${response.statusCode}');
      print('[getDeviceAutoListApi] response body : ${response.body}');
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'].toString() == 'false') {
        var deiviceAutoList = getDeviceAutoListModelFromJson(response.body);
        var index = deiviceAutoList.data
            .indexWhere((element) => element.serialNumber == tempSn);
        deviceDetail = deiviceAutoList.data[index];

        // print('index: $index');
        // print('deviceDetail $deviceDetail');
        // print('deviceDetail type ${deviceDetail.runtimeType}');
        print('[getDeviceAutoListApi] finsih!');
        return deiviceAutoList;
      } else {
        return null; //return null if error happened
      }
    } catch (e) {
      print('[getDeviceAutoListApi] error: $e');
      return null;
    }
  }

   @override
  void dispose() {
    removeCookie('serialNumberAuto');
    removeCookie('clientIDAuto');
    removeCookie('tokenAuto');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return FutureBuilder(
        future: getDeviceAutoListApi(),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.data != null) {
              //print('deviceDetail: ${deviceDetail.room}');
              return Scaffold(
                backgroundColor: Colors.white,
                appBar: AppBar(
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    color: Colors.black,
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  toolbarHeight: size.height * 0.075,
                  backgroundColor: Colors.white,
                  centerTitle: true,
                  elevation: 0, //remove shadow
                  title: Container(
                    width: size.width * 0.65,
                    alignment: Alignment.center,
                    child: Text(widget.nameDevice,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Colors.black)),
                  ),
                  iconTheme: const IconThemeData(
                      color: Color.fromARGB(255, 69, 47, 139)),
                ),
                body: Container(
                    width: size.width,
                    height: size.height,
                    color: Colors.white,
                    child: ListView(
                      children: [
                        Container(
                            width: size.width,
                            height: size.height * 0.05,
                            padding: const EdgeInsets.only(
                                left: 25, right: 25, top: 0),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              deviceDetail.room,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black38),
                            )),

                        //set the on-off time
                        // selectBox(
                        //     name: "Set the on-off time",
                        //     status: deviceDetail.setTimeStatus == "idle"
                        //         ? "Off"
                        //         : "On",
                        //     checkpage: "1"),

                        //set the duration of work
                        selectBox(
                            name: "Set the duration of work",
                            status: deviceDetail.countTimeStatus == "idle"
                                ? "Off"
                                : "On",
                            checkpage: "2"),
                      ],
                    )),
              );
            } else {
              //connection failed!
              return connectFailed();
            }
          } else {
            //loading...
            return loadingBox();
          }
        });
  }

  selectBox({name, status, checkpage}) {
    Size size = MediaQuery.of(context).size;

    return SizedBox(
      width: size.width,
      height: 90,
      //color: Colors.red,
      child: TextButton(
        onPressed: () async {
          if (checkpage == "1") {
            print('go set time page');
            Navigator.of(context)
                .push(MaterialPageRoute(
                    builder: (context) =>
                        const SetTimeFunction())) //ไปที่หน้าตั้งเวลา เปิด-ปิด
                .then((value) => {setState(() {})});
          } else {
            print('go set period page');
            Navigator.of(context)
                .push(MaterialPageRoute(
                    builder: (context) =>
                        const NewSetPeriodFuction())) //ไปที่หน้ากำหนดระยะเวลาการทำงาน
                .then((value) => {setState(() {})});
          }
        },
        child: Container(
          width: size.width,
          height: 90,
          padding:
              const EdgeInsets.only(left: 35, right: 35, top: 10, bottom: 5),
          child: Column(
            children: [
              Row(children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: Colors.black),
                    ),
                    Text(
                      status,
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: status == "On"
                              ? Colors.green[300]
                              : Colors.black38),
                    )
                  ],
                ),
                const Spacer(),
                const Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.black,
                  size: 20,
                )
              ]),
              const Spacer(),
              Container(
                width: size.width,
                height: 2,
                color: Colors.black12,
              )
            ],
          ),
        ),
      ),
    );
  }

  //แสดงตอนเชื่อมต่อล้มเหลว snapshot = null
  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => Navigator.of(context).pop(),
          ),
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow
          title: Text(widget.nameDevice,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black)),
          iconTheme:
              const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Card(
                shadowColor: Colors.transparent,
                elevation: 0,
                child: Text(
                  'Connection failed!',
                  style: TextStyle(fontSize: 24),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              SizedBox(
                width: size.width * 0.3,
                height: size.height * 0.06,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.zero,
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    setState(() {}); //กดปุ่มแล้วจะรีบิ้วใหม่
                  },
                  child: const Text(
                    'Try again',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'FCfont',
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  //โหลดหน้ารอ snapshot
  loadingBox() {
    return const Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 5),
            Card(
              shadowColor: Colors.transparent,
              elevation: 0,
              child: Text(
                'Loading...',
                style: TextStyle(fontSize: 24),
                textAlign: TextAlign.center,
              ),
            )
          ],
        ),
      ),
    );
  }
}
