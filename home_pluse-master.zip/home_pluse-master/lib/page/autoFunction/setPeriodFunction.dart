import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

//import '../../backgroundService.dart';
import '../../cookiesValue.dart';

//! ฟังก์ชั่น SetPeriodFuction ยังไม่ได้ใช้ในตอนนี้ ไปใช้ newSetPeriodFuction แทน

class SetPeriodFuction extends StatefulWidget {
  const SetPeriodFuction({super.key});

  @override
  State<SetPeriodFuction> createState() => _SetPeriodFuctionState();
}

class _SetPeriodFuctionState extends State<SetPeriodFuction> {
  String? countTimeStatus;
  String? timerStart; //time start counting ( timerOpen in api)
  String? timerFinish; //time finish counting ( timerClose in api)
  String? deviceName;
  List<String> deviceValue =
      []; //use for keep "closeTime" and "device name" that using in background service.

  getCountTimeDetailApi() async {
    print('[getCountTimeDetailApi] Start getCountTimeDetailApi function');
    String tempSn = await getCookie('serialNumberAuto');
    String urlBase = await getUrlBase();

    //print('[getHouseListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/getCountTime');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "serialNumber": tempSn,
          });

      print('[getCountTimeDetailApi] status Code : ${response.statusCode}');
      print('[getCountTimeDetailApi] response body : ${response.body}');
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'] == false) {
        countTimeStatus = jsonResponse['data'][0]['countTimeStatus'].toString();
        //timerOpen and timerClose is DateTime value
        timerStart = jsonResponse['data'][0]['timerOpen'].toString();
        timerFinish = jsonResponse['data'][0]['timerClose'].toString();
        deviceName = jsonResponse['data'][0]['deviceName'].toString();
        // print("countTimeStatusl: $countTimeStatus");
        // print(
        //     "timerStart: $timerStart");
        // print("timerFinish: $timerFinish");

        // print("time finish (formated): ${DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.parse(timerFinish!))}");
        // print("date now : ${DateTime.parse(DateTime.now().toString())}");

        print('[getCountTimeDetailApi] check time');
        if (countTimeStatus != 'idle') {
          if (DateFormat('yyyy-MM-dd HH:mm:ss')
                  .parse(DateTime.parse(timerFinish!).toString())
                  .compareTo(DateFormat('yyyy-MM-dd HH:mm:ss')
                      .parse(DateTime.now().toString())) >
              0) {
            duration = DateTime.parse(DateTime.parse(timerFinish!).toString())
                .difference(DateTime.now());
            print('[getCountTimeDetailApi] duration : $duration');
            return true;
          } else {
            //time out!
            print('[getCountTimeDetailApi] TIME OUT!');
            setCountTimeApi('idle', DateTime.parse('0000-01-01 00:00:00'),
                DateTime.parse('0000-01-01 00:00:00'), false);
            return false;
          }
        }

        print('[getCountTimeDetailApi] finsih!');

        String clientIdAuto = await getCookie('clientIDAuto');
        String tokenAuto = await getCookie('tokenAuto');

        //getStatus device
        deviceStatus = await getStatusDevice(
            clientIdAuto.toString(), tokenAuto.toString());

        if (deviceStatus == 'Failed' || deviceStatus == '-') {
          //throw err
          throw Exception('get device Status err');
        }

        print('[getCountTimeDetailApi] finsih!');

        return true;
      } else {
        print('[getCountTimeDetailApi] finsih! but err is ture');
        return false;
      }
    } catch (e) {
      print('[getCountTimeDetailApi] error: $e');
      return false;
    }
  }

  setCountTimeApi(String countTimeStatus, DateTime timeStart,
      DateTime timeClose, bool cancel) async {
    print('[setCountTimeApi] Im setCountTimeApi function');
    print('[setCountTimeApi] countTimeStatus: ${countTimeStatus.toString()}');
    print('[setCountTimeApi] timeStart: ${timeStart.toString()}');
    print('[setCountTimeApi] timeClose: ${timeClose.toString()}');

    String serialNumber = await getCookie('serialNumberAuto');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/countTime');
    try {
      http.Response response = await http.put(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "serialNumber": serialNumber,
            "countTimeStatus": countTimeStatus,
            "timerOpen": timeStart.toString(),
            'timerClose': timeClose.toString(),
          });

      print('[setCountTimeApi] status Code : ${response.statusCode}');
      print('[setCountTimeApi] response body: ${response.body}');

      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)

      if (jsonResponse['error'] == false) {
        if (countTimeStatus == 'idle' && cancel) {
          //remove cookie
          var snaNow = await getCookie('serialNumberAuto');
          var serialNumberAutoList = await getCookie('serialNumberAutoList');
          if (serialNumberAutoList != 'null' && serialNumberAutoList != '') {
            //กรณีที่ไม่ใช่ค่าว่าง หมายความว่ามีข้อมูลอยู่แล้ว ต้องนำมาทำเป็น list ก่อน
            List<String> tempList = serialNumberAutoList.split(',');
            print('finish convert string to list');
            //เพิิ่ม ซีเรียลนัมเบอร์ ของอุปกรณ์ตัวใหม่เข้าไป
            print('list of device  that set timer: $tempList');

            tempList.remove(snaNow);

            if (tempList.isEmpty) {
              removeCookie(
                  "serialNumberAutoList"); // remove serial number from cookie.
            } else {
              String tempString =
                  tempList.join(','); //change list of deviceAutoList to string
              setCookie(
                  'serialNumberAutoList',
                  tempString
                      .toString()); //save current device that set timer to cookie.
            }
          }
          removeCookie(snaNow);
        }

        //send off shadow to netpie
        //หลังจากเพิ่มอุปกรณ์เสร้จจะ้ตองส่งคำสั่งควบคุอุปกรณ์ครั้งแรกให้เป็น off
        //return popup('Add device is complete.', 'move');
        // FlutterBackgroundService().invoke("stopService");
        // Timer(
        //     //จับเวลา 3 วิหลังจากนั้นจะทำงานตามที่เราเขียนโค้ดไว้
        //     const Duration(seconds: 3),
        //     () async => await initializeService());

        if (mounted) {
          setState(() {});
        }
      } else {
        return popup(
            'Failed to set counting time!\nSomething is wrong.', 'null');
      }
    } catch (e) {
      print('[setCountTimeApi] error: $e');
      popup("Failed to set counting time!\nConnection failed.",
          'null'); //wrong code or can't connect to server.
    }
  }

  String deviceStatus = "";
  getStatusDevice(cn, tk) async {
    //cn = clientId ,tk = token
    print('[getStatusDevice] Im in  getStatusDevice');

    String basicAuth = 'Device $cn:$tk';
    Uri myUri = Uri.parse('https://api.netpie.io/v2/device/status');
    try {
      http.Response r = await http
          .get(myUri, headers: <String, String>{'authorization': basicAuth});
      print('[getStatusDevice]  status code : ${r.statusCode}');
      print('[getStatusDevice] response body : ${r.body}');

      var jsonResponse = jsonDecode(r.body);
      if (jsonResponse['status'] == 0) {
        return 'Offline';
      } else if (jsonResponse['status'] == 1) {
        return 'Online';
      } else {
        return 'Failed';
      }
    } catch (e) {
      print('[getStatusDevice] error : $e');
      return '-';
    }
  }

  bool startStatus = false; // switch value of open timer
  bool offStatus = false; // switch value of close timer

  DateTime dateTime = DateTime.now();
  bool counting = false;

  var timerSelect;
  var timerNowSelect;
  var statePage = "1";
  var timeHours;
  var timeMins;
  var timeSecs;

  //time ที่ใช้ในการนับเวลา (เวลา ที่ต้องส่งไปยังอุปกรณ์)
  Duration duration = const Duration(hours: 0, minutes: 0, seconds: 0);

  //เปลี่ยน format ของเวลาเพื่อใช้เช็คว่าเวลาที่ตั้ง > หนึ่งนาที หรือไม่?
  String formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));

    timeHours = int.parse(hours);
    timeMins = int.parse(minutes);
    timeSecs = int.parse(seconds);

    return '$hours:$minutes:$seconds'; //return String
  }

  //countdown
  // var countdownDuration = Duration();

  Timer? timer; // ใช้นับเวลา

  void startTimer(StateSetter setStateCT, {bool resets = true}) {
    //เริ่มนับเวลา โดยมีการเรียกใช้ countTime ที่ทำหน้าที่ลดลงทีละหนึ่งวิ
    timer = Timer.periodic(
        const Duration(seconds: 1), (_) => countTime(setStateCT));
  }

  void countTime(setStateCT) {
    const countSeconds = 1; //ลดเวลาที่ละหนึ่งวิ
    setStateCT(() {
      counting = true;
      // duration ถูกกำหนดให้เป็น เวลา ที่มีค่าเท่ากับค่าที่ user เลือกมา
      final seconds = duration.inSeconds - countSeconds;

      //หมดเวลา
      if (seconds < 0) {
        //seconds เวลาในตอนนี้น้อยกว่า 0 = เวลาหมด ยกเลิกการนับเวลาและกลับไปที่ statepage 1 (หน้า Set Period)
        timer?.cancel(); //หยุดนับเวลา
        //TODOWORK : send api เพื่อบอกว่านับเวลาจบแล้ว (ทีหลัง)
        //TODOWORK : change state page, set cookies and setState
        // setCountTimeApi('idle', DateTime.parse('0000-01-01 00:00:00'),
        //     DateTime.parse('0000-01-01 00:00:00'));
        if (mounted) {
          setState(() {});
        }

        //(success) TODOWORK : show pop up after finish counting
        popup("The countdown has been completed.", '');
      } else {
        //ยังไม่หมดเวลา ให้ duration = ค่าที่เวลาล่าสุด
        duration = Duration(seconds: seconds);
      }
    });
  }

  Future<void> setupCookieForBackgroundService(String closeTime) async {
    //(OK)TODOWORK: SET DURATION AND TYPE OF TIMER TO COOKIES HRER!
    //serialNumber : finsih time //ใช้คำนวนใน bg service
    //sna = serial number auto
    var serialNumberAuto = await getCookie('serialNumberAuto');

    //add closetime and device name to list.
    deviceValue.add(closeTime);
    deviceValue.add(deviceName!);

    //convert list to string for save to cookie.
    String deviceValueString = deviceValue.join(',');

    print("deviceValueString: $deviceValueString");

    //set serialnumberAuto : closeTime,deviceName //we use  device name for local notification
    setCookie(serialNumberAuto, deviceValueString.toString());
    deviceValue = [];

    //get serialNumberAutoList ข้อมูลอยู่ในรูปแบบ "text,text,text"
    //แล้วค่อยเปลี่ยนเป็น list
    var serialNumberAutoList = '${await getCookie('serialNumberAutoList')}';
    print('serialNumberAutoList: $serialNumberAutoList');

    //ทำการเช็ค serialNumberAutoList ว่าเป็นค่าว่างหรือไม่?
    if (serialNumberAutoList != "null" && serialNumberAutoList != '') {
      //กรณีที่ไม่ใช่ค่าว่าง หมายความว่ามีข้อมูลอยู่แล้ว ต้องนำมาทำเป็น list ก่อน
      List<String> tempList = serialNumberAutoList.split(',');
      print('finish convert string to list');
      //เพิิ่ม ซีเรียลนัมเบอร์ ของอุปกรณ์ตัวใหม่เข้าไป
      tempList.add("$serialNumberAuto");
      print('list of device  that set timer: $tempList');

      //จากนั้นเปลี่ยน list ให้เป็น string and save cookie
      String tempString = tempList.join(',');
      print('string of device  that set timer: $tempString');
      setCookie('serialNumberAutoList', tempString.toString());
    } else {
      //กรณีเป็นค่าว่างก็ทำเซฟลงคุกกี้ได้เลย
      //build list
      print('build new list of device that set timer.');
      setCookie('serialNumberAutoList', serialNumberAuto.toString());
    }
  }

  @override
  void initState() {
    super.initState();
    print('DATE TIME NOW : ${dateTime.toString()}');
  }

  @override
  void dispose() {
    timer?.cancel(); // stop timer when navicator pop
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return FutureBuilder(
        future: getCountTimeDetailApi(),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.data) {
              return Scaffold(
                  backgroundColor: Colors.white,
                  appBar: AppBar(
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back),
                      color: Colors.black,
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    actions: [
                      if (countTimeStatus == "idle") ...{
                        TextButton(
                          onPressed: deviceStatus == 'Online'
                              ? () async {
                                  // print(new DateFormat('yyyy/MM/dd HH:mm:ss')
                                  //     .parse('0000/01/01 ${timerNowSelect.toString()}'));

                                  if ((startStatus == true ||
                                          offStatus == true) &&
                                      (timerNowSelect != null ||
                                          timerSelect != null)) {
                                    if (DateFormat('yyyy/MM/dd HH:mm:ss')
                                            .parse(
                                                '0000/01/01 ${timerNowSelect != null ? timerNowSelect.toString() : timerSelect.toString()}')
                                            .compareTo(DateFormat(
                                                    'yyyy/MM/dd HH:mm:ss')
                                                .parse('0000/01/01 00:00:59')) >
                                        0) {
                                      print("true");

                                      // // set count time
                                      duration = Duration(
                                          hours: timeHours,
                                          minutes: timeMins,
                                          seconds: timeSecs);

                                      DateTime startTime = DateTime.now();
                                      DateTime closeTime =
                                          DateTime.now().add(duration);

                                      print(duration.toString());
                                      //display: 0:04:00.000000

                                      //:::::::::::::: KEEP COOKIE FOR BH SERVICE :::::::::::::://
                                      setupCookieForBackgroundService(
                                          closeTime.toString());

                                      setCountTimeApi(
                                          startStatus ? 'Open' : 'Close',
                                          startTime,
                                          closeTime,
                                          false);
                                    } else {
                                      print('false');
                                      popup(
                                          "It should be set for more than 1 minute.",
                                          '');
                                      // (success) TODOWORK : SHOW POP UP ว่าไม่สามารถ save ได้ (cannot save)
                                    }
                                  } else {
                                    print('error');
                                    // print(startStatus);
                                    // print(offStatus);
                                    // print(timerNowSelect);
                                    popup("Cannot save, should select a time.",
                                        '');
                                    // (success) TODOWORK : SHOW POP UP ว่า err (error)
                                  }
                                }
                              : null,
                          child: Text(
                            "Save",
                            style: TextStyle(
                              color: deviceStatus == 'Online'
                                  ? const Color.fromARGB(255, 117, 138, 214)
                                  : Colors.black38,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        )
                      } else ...{
                        //not show any bt when countTimeStatus != idle
                      }
                    ],
                    toolbarHeight: size.height * 0.075,
                    backgroundColor: Colors.white,
                    centerTitle: true,
                    elevation: 0, //remove shadow
                    title: Text(
                        countTimeStatus == "idle" ? 'Set Period' : 'Count time',
                        style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Colors.black)),
                    iconTheme: const IconThemeData(
                        color: Color.fromARGB(255, 69, 47, 139)),
                  ),
                  body: Column(
                    children: [
                      if (countTimeStatus == "idle") ...{
                        //new stateflu widget
                        StatefulBuilder(
                          builder: (BuildContext contextSub, setStateSub) {
                            counting = false;
                            return Container(
                              //กรอบใหญ่
                              padding: const EdgeInsets.all(30),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 255, 255, 255),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                children: [
                                  //device status
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 5, right: 5),
                                    child: Row(
                                      children: [
                                        const Text(
                                          'Device Status',
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black),
                                        ),
                                        const Spacer(),
                                        if (deviceStatus == 'Online') ...{
                                          Text(deviceStatus,
                                              style: const TextStyle(
                                                  fontSize: 24,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.green)),
                                        } else ...{
                                          Text(deviceStatus,
                                              style: const TextStyle(
                                                  fontSize: 24,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.grey)),
                                        }
                                      ],
                                    ),
                                  ),

                                  //เว้น
                                  const SizedBox(
                                    height: 20,
                                  ),

                                  //Start working
                                  Container(
                                    padding: const EdgeInsets.only(
                                        left: 10,
                                        right: 10,
                                        top: 10,
                                        bottom: 25),
                                    width: size.width,
                                    height: size.height * 0.175,
                                    decoration: BoxDecoration(
                                      color: const Color.fromARGB(
                                          255, 255, 255, 255),
                                      border: Border.all(
                                        color: const Color.fromARGB(
                                            255, 117, 138, 214),
                                        width: 1,
                                      ),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Column(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 10, right: 10),
                                          child: Row(
                                            children: [
                                              Text(
                                                'Start Working',
                                                style: TextStyle(
                                                  fontSize: 25,
                                                  fontWeight: FontWeight.bold,
                                                  color:
                                                      deviceStatus == "Online"
                                                          ? Colors.black
                                                          : Colors.black38,
                                                ),
                                              ),
                                              const Spacer(),
                                              //สวิตซ์เปิดการทำงาน
                                              FlutterSwitch(
                                                width: 40,
                                                height: 20,
                                                valueFontSize: 15.0,
                                                toggleSize: 25.0,
                                                value: startStatus,
                                                borderRadius: 30.0,
                                                padding: 4.0,
                                                // showOnOff: true,
                                                disabled:
                                                    deviceStatus == "Online"
                                                        ? false
                                                        : true,
                                                activeColor:
                                                    const Color.fromARGB(
                                                        255, 117, 138, 214),
                                                onToggle: (val) {
                                                  setStateSub(() {
                                                    startStatus = val;
                                                    if (startStatus == true) {
                                                      offStatus = false;
                                                      timerSelect = null;
                                                      timerNowSelect = null;
                                                      duration = const Duration(
                                                          hours: 0,
                                                          minutes: 0,
                                                          seconds: 0);
                                                      print('Start Working');
                                                    } else {
                                                      timerSelect = null;
                                                      timerNowSelect = null;
                                                    }
                                                  });
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        Container(
                                            width: size.width,
                                            height: size.height * 0.06,
                                            //จับเวลา
                                            padding: const EdgeInsets.only(
                                                left: 10, right: 10),
                                            child: TextButton(
                                              onPressed: startStatus
                                                  ? (() => {
                                                        showCupertinoModalPopup(
                                                          barrierDismissible:
                                                              false,
                                                          context: context,
                                                          builder: (context1) =>
                                                              CupertinoActionSheet(
                                                            actions: [
                                                              buildTimePicker(),
                                                            ],
                                                            cancelButton:
                                                                CupertinoActionSheetAction(
                                                              child: const Text(
                                                                  'Done'),
                                                              onPressed: () {
                                                                setStateSub(() {
                                                                  final value =
                                                                      formatDuration(
                                                                          duration);
                                                                  timerNowSelect =
                                                                      value;
                                                                  showSnackBar(
                                                                      context1,
                                                                      'Selected "$value"');

                                                                  Navigator.pop(
                                                                      context1);
                                                                });
                                                              },
                                                            ),
                                                          ),
                                                        )
                                                      })
                                                  : null,
                                              child: Row(
                                                children: [
                                                  Text(
                                                    'Timer',
                                                    style: TextStyle(
                                                        fontSize: 18,
                                                        color: startStatus
                                                            ? Colors.black
                                                            : Colors.grey,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  const Spacer(),
                                                  Text(
                                                    timerNowSelect ??
                                                        'Select Time',
                                                    style: const TextStyle(
                                                        fontSize: 16,
                                                        color: Color.fromARGB(
                                                            255,
                                                            160,
                                                            160,
                                                            160)),
                                                  ),
                                                  Icon(
                                                    Icons.arrow_forward_ios,
                                                    color: startStatus
                                                        ? Colors.black
                                                        : Colors.grey,
                                                  ),
                                                ],
                                              ),
                                            )),
                                        Container(
                                          width: size.width,
                                          height: 2,
                                          color: Colors.black12,
                                        ),
                                      ],
                                    ),
                                  ),

                                  //เว้น
                                  SizedBox(
                                    width: size.width,
                                    height: 30,
                                  ),

                                  //Turn Off
                                  Container(
                                    padding: const EdgeInsets.only(
                                        left: 10,
                                        right: 10,
                                        top: 10,
                                        bottom: 25),
                                    width: size.width,
                                    height: size.height * 0.175,
                                    decoration: BoxDecoration(
                                      color: const Color.fromARGB(
                                          255, 255, 255, 255),
                                      border: Border.all(
                                        color: const Color.fromARGB(
                                            255, 117, 138, 214),
                                        width: 1,
                                      ),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Column(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 10, right: 10),
                                          child: Row(
                                            children: [
                                              Text(
                                                'Turn Off',
                                                style: TextStyle(
                                                  fontSize: 25,
                                                  fontWeight: FontWeight.bold,
                                                  color:
                                                      deviceStatus == "Online"
                                                          ? Colors.black
                                                          : Colors.black38,
                                                ),
                                              ),
                                              const Spacer(),
                                              //สวิตซ์ปิดการทำงาน
                                              FlutterSwitch(
                                                width: 40,
                                                height: 20,
                                                valueFontSize: 15.0,
                                                toggleSize: 25.0,
                                                value: offStatus,
                                                borderRadius: 30.0,
                                                padding: 4.0,
                                                // showOnOff: true,
                                                disabled:
                                                    deviceStatus == "Online"
                                                        ? false
                                                        : true,
                                                activeColor:
                                                    const Color.fromARGB(
                                                        255, 117, 138, 214),
                                                onToggle: (val) {
                                                  setStateSub(() {
                                                    offStatus = val;
                                                    if (offStatus == true) {
                                                      startStatus = false;
                                                      timerSelect = null;
                                                      timerNowSelect = null;
                                                      duration = const Duration(
                                                          hours: 0,
                                                          minutes: 0,
                                                          seconds: 0);
                                                      print('Turn Off');
                                                    } else {
                                                      timerSelect = null;
                                                      timerNowSelect = null;
                                                    }
                                                  });
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 10, right: 10),
                                          child: TextButton(
                                            onPressed: offStatus
                                                ? () {
                                                    showCupertinoModalPopup(
                                                      barrierDismissible: false,
                                                      context: context,
                                                      builder: (context1) =>
                                                          CupertinoActionSheet(
                                                        actions: [
                                                          buildTimePicker(),
                                                        ],
                                                        cancelButton:
                                                            CupertinoActionSheetAction(
                                                          child: const Text(
                                                              'Done'),
                                                          onPressed: () {
                                                            setStateSub(() {
                                                              final value =
                                                                  formatDuration(
                                                                      duration);
                                                              timerSelect =
                                                                  value;
                                                              showSnackBar(
                                                                  context1,
                                                                  'Selected "$value"');

                                                              Navigator.pop(
                                                                  context1);
                                                            });
                                                          },
                                                        ),
                                                      ),
                                                    );
                                                  }
                                                : null,
                                            child: Row(
                                              children: [
                                                Text(
                                                  'Timer',
                                                  style: TextStyle(
                                                      fontSize: 18,
                                                      color: offStatus
                                                          ? Colors.black
                                                          : Colors.grey,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                const Spacer(),
                                                Text(
                                                  timerSelect ?? 'Select Time',
                                                  style: const TextStyle(
                                                      fontSize: 16,
                                                      color: Color.fromARGB(
                                                          255, 160, 160, 160)),
                                                ),
                                                Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: offStatus
                                                      ? Colors.black
                                                      : Colors.grey,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: size.width,
                                          height: 2,
                                          color: Colors.black12,
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            );
                          },
                        )
                      } else ...{
                        StatefulBuilder(
                            builder: (BuildContext context, setStateCT) {
                          if (!counting) {
                            startTimer(setStateCT);
                          }
                          return Center(
                              child: SizedBox(
                            height: size.height * 0.75,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  countTimeStatus == "Open"
                                      ? "Working"
                                      : "Turn Off",
                                  style: const TextStyle(
                                      fontSize: 36,
                                      fontWeight: FontWeight.bold),
                                ),
                                buildTime(),
                                const SizedBox(height: 20),
                                buidButtons()
                              ],
                            ),
                          ));
                        })
                      }
                    ],
                  ));
            } else {
              //failed connection
              return connectFailed();
            }
          } else {
            //loading...
            return loadingBox();
          }
        });
  }

  //countdown
  Widget buidButtons() {
    // final isRunning = timer == null ? false : timer!.isActive;
    // final isCompleted = duration.inSeconds == 0;

    return TextButton(
      // style: ElevatedButton.styleFrom(minimumSize: Size(100, 42)),
      // ignore: sort_child_properties_last
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(width: 8),
          Text(
            'CANCEL',
            style: TextStyle(
              decoration: TextDecoration.underline,
              fontSize: 20,
              color: Color.fromARGB(255, 117, 138, 214),
            ),
          ),
        ],
      ),
      onPressed: (() {
        // stopTimer();
        popup("Confirm to cancel.", 'cancel');
      }),
    );
  }

  Widget buildTime() {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        buildTimeCard(time: hours, header: 'HOURS'),
        const SizedBox(
          width: 8,
        ),
        buildTimeCard(time: minutes, header: 'MINUTES'),
        const SizedBox(
          width: 8,
        ),
        buildTimeCard(time: seconds, header: 'SECONDS'),
      ],
    );
  }

  Widget buildTimeCard({required String time, required String header}) =>
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              time,
              // ignore: prefer_const_constructors
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.black,
                fontSize: 72,
              ),
            ),
          ),
          const SizedBox(height: 0),
          Text(header),
        ],
      );

  //เลือกเวลา ใน pageState 1
  Widget buildTimePicker() {
    return SizedBox(
        height: 180,
        child: StatefulBuilder(
          builder: (BuildContext context, setStateTp) {
            return CupertinoTimerPicker(
              initialTimerDuration: duration,
              mode: CupertinoTimerPickerMode.hms,
              minuteInterval: 1,
              secondInterval: 1,
              onTimerDurationChanged: (duration) =>
                  setStateTp(() => this.duration = duration),
            );
          },
        ));
  }

  // แสดงตอนเพิ่มเลือกเวลาเสร็จ
  static void showSnackBar(BuildContext context, String text) {
    final snackBar = SnackBar(
      content: Text(text, style: const TextStyle(fontSize: 24)),
    );

    ScaffoldMessenger.of(context)
      ..removeCurrentSnackBar()
      ..showSnackBar(snackBar);
  }

  //popup
  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false,
        child: AlertDialog(
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            if (move == 'cancel') ...{
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  //cancel
                  Container(
                    alignment: Alignment.center,
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context, 'Cancel');
                      },
                      child: const Text(
                        'Cancel',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Color.fromARGB(255, 117, 138, 214)),
                      ),
                    ),
                  ),

                  //ok
                  Container(
                    alignment: Alignment.center,
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context, 'Cancel');
                        duration = const Duration(
                            hours: 0,
                            minutes: 0,
                            seconds: 0); //reset count time
                        //statePage = "1"; //change to statePage 1

                        timer?.cancel(); // stop timer
                        timer = null; //set to null(?)

                        // timeSelect to null
                        timerSelect = null;
                        timerNowSelect = null;

                        //set time selected in hour , minm and sec to null
                        timeHours = null;
                        timeMins = null;
                        timeSecs = null;
                        startStatus = false; // switch value of open timer
                        offStatus = false;

                        setCountTimeApi(
                            'idle',
                            DateTime.parse('0000-01-01 00:00:00'),
                            DateTime.parse('0000-01-01 00:00:00'),
                            true);
                      },
                      child: const Text(
                        'Ok',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Color.fromARGB(255, 117, 138, 214)),
                      ),
                    ),
                  ),
                ],
              ),
            } else ...{
              Container(
                alignment: Alignment.center,
                child: TextButton(
                  onPressed: () {
                    Navigator.pop(context, 'Ok');
                  },
                  child: const Text(
                    'Ok',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 117, 138, 214)),
                  ),
                ),
              ),
            }
          ],
        ),
      ),
    );
  }

  //แสดงตอนเชื่อมต่อล้มเหลว snapshot = null
  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => Navigator.of(context).pop(),
          ),
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow
          title: const Text('Set Period',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black)),
          iconTheme:
              const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Card(
                shadowColor: Colors.transparent,
                elevation: 0,
                child: Text(
                  deviceStatus == "-" || deviceStatus == "Failed"
                      ? "Device status error!"
                      : 'Connection failed!',
                  style: const TextStyle(fontSize: 24),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              SizedBox(
                width: size.width * 0.3,
                height: size.height * 0.06,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.zero,
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    setState(() {}); //กดปุ่มแล้วจะรีบิ้วใหม่
                  },
                  child: const Text(
                    'Try again',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'FCfont',
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  //โหลดหน้ารอ snapshot
  loadingBox() {
    return const Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 5),
            Card(
              shadowColor: Colors.transparent,
              elevation: 0,
              child: Text(
                'Loading...',
                style: TextStyle(fontSize: 24),
                textAlign: TextAlign.center,
              ),
            )
          ],
        ),
      ),
    );
  }
}
