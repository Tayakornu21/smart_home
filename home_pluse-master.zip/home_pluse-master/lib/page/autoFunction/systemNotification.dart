import 'package:flutter/material.dart';

class SystemNotificationPage extends StatefulWidget {
  const SystemNotificationPage({super.key});

  @override
  State<SystemNotificationPage> createState() => _SystemNotificationPageState();
}

//! หน้า notification ยังไม่ได้ใช้ในตอนนี้

class _SystemNotificationPageState extends State<SystemNotificationPage> {
  var noti = true;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.of(context).pop(),
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        title: const Text('System Notification',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: Container(
        padding: const EdgeInsets.all(20),
        alignment: Alignment.center,
        child: Column(
          children: <Widget>[
            if (noti == false) ...{ //true เรียกใช้ฟังก์ชั่นการแจ้งเตือนขึ้นมา
              Column(
                children: [
                  houseBox(
                    status: "Device stops working",
                    room: "The bedroom smart plug stopped working suddenly",
                    date: "02/05/2023",
                    time: "08:30 PM",
                  ),
                ],
              )
            } else ...{
              SizedBox(
                height: size.height * 0.8,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(
                      Icons.message,
                      color: Color.fromARGB(255, 158, 158, 158),
                      size: 100,
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      'No messages in the last 7 days',
                      style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 158, 158, 158)),
                    ),
                  ],
                ),
              )
            }
          ],
        ),
      ),
    );
  }

  houseBox({status, room, date, time, check}) {
    Size size = MediaQuery.of(context).size;
    return Container(
      width: size.width,
      height: 100,
      padding: const EdgeInsets.only(left: 35, right: 35, top: 10, bottom: 5),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            status,
            style: const TextStyle(
                fontSize: 24, fontWeight: FontWeight.w600, color: Colors.black),
          ),
          Text(
            room,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.black38),
          ),
          const Spacer(),
          Row(
            children: [
              Text(
                date,
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
              const Spacer(),
              Text(
                time,
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width,
            height: 2,
            color: Colors.black12,
          ),
        ],
      ),
    );
  }
}
