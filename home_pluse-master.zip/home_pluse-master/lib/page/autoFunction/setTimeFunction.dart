import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
// import 'package:homeplus_phase1/utils.dart';
// import 'package:homeplus_phase1/widget/button_widget.dart';
import 'package:intl/intl.dart';

//! ฟังก์ชั่น ตั้งเวลาการทำงานของตัวอุปกรณ์ ยังไม่ได้ใช้ในตอนนี้ ไปใช้ newSet
class SetTimeFunction extends StatefulWidget {
  const SetTimeFunction({super.key});

  @override
  State<SetTimeFunction> createState() => _SetTimeFunctionState();
}

class _SetTimeFunctionState extends State<SetTimeFunction> {
  bool status1 = false;
  bool status2 = false;
  bool status3 = false;
  bool status4 = false;
  // ignore: unused_field
  late FixedExtentScrollController _controller;

  late TextEditingController controller;
  late FixedExtentScrollController scrollController;
  final items = [
    'Once',
    'Evervy Day',
    'Monday to Friday',
    'Saturday to Sunday',
  ];

  int index = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _controller = FixedExtentScrollController();
    controller = TextEditingController(text: items[index]);
    scrollController = FixedExtentScrollController(initialItem: index);
  }

  @override
  void dispose() {
    controller.dispose();
    scrollController.dispose();

    super.dispose();
  }

  DateTime dateTime = DateTime.now();
  //creat TimeOfDay variable
  TimeOfDay timeOfDay = TimeOfDay(hour: 8, minute: 30);

  //show date picker method open
  void _showDatePicker() {
    showDatePicker(
      context: context,
      initialDate: dateSelect ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    ).then((value) {
      setState(() {
        dateTime = value!;
        dateSelect = dateTime;
        dateNowSelect =
            "${dateTime.day}/${dateTime.month}/${dateTime.year}"; //วันเดือนปีปัจจุบัน
        print('Select Date: $dateNowSelect');
      });
    });
  }

  //show time picker method open
  void _showTimePicker() {
    showTimePicker(
      context: context,
      initialTime: timeSelect ?? TimeOfDay.now(),
    ).then((value) {
      setState(() {
        timeOfDay = value!;
        timeSelect = timeOfDay;
        timeNowSelect = timeOfDay.format(context).toString();
        print('Select Time: $timeNowSelect');
      });
    });
  }

  //show date picker method close
  void _showDatePicker1() {
    showDatePicker(
      context: context,
      initialDate: dateSelect ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    ).then((value) {
      setState(() {
        dateTime = value!;
        dateSelect1 = dateTime;
        dateNowSelect1 =
            "${dateTime.day}/${dateTime.month}/${dateTime.year}"; //วันเดือนปีปัจจุบัน
        print('Select Date1: $dateNowSelect1');
      });
    });
  }

  //show time picker method close
  void _showTimePicker1() {
    showTimePicker(
      context: context,
      initialTime: timeSelect ?? TimeOfDay.now(),
    ).then((value) {
      setState(() {
        timeOfDay = value!;
        timeSelect1 = timeOfDay;
        timeNowSelect1 = timeOfDay.format(context).toString();
        print('Select Time1: $timeNowSelect1');
      });
    });
  }

  //open
  var repSelect;
  var repSelectReal;
  var repetState;
  var dateSelect;
  var dateNowSelect;
  var timeNowSelect;
  var timeSelect;

  //close
  var rep1Select;
  var rep1SelectReal;
  var dateSelect1;
  var dateNowSelect1;
  var timeSelect1;
  var timeNowSelect1;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => Navigator.of(context).pop(),
          ),
          actions: [
            TextButton(
              onPressed: () {
                //เช็คบนเปิด ล่างปิด
                if (status1 == true && status2 == false) {
                  if (dateNowSelect == null ||
                      timeNowSelect == null ||
                      repSelectReal == null) {
                    popup("Cannot save, All 3 options should be selected.", '');
                  } else {
                    //popup save ได้
                    popup("Saved", '');
                  }
                  //เช็คล่างเปิด บนปิด
                } else if (status1 == false && status2 == true) {
                  if (dateNowSelect1 == null ||
                      timeNowSelect1 == null ||
                      rep1SelectReal == null) {
                    popup("Cannot save, All 3 options should be selected.", '');
                  } else {
                    //popup save ได้
                    popup("Saved", '');
                  }
                  //เช็คเปิดทั้งคู่
                } else if (status1 == true && status2 == true) {
                  if (dateNowSelect == null ||
                      timeNowSelect == null ||
                      repSelectReal == null ||
                      dateNowSelect1 == null ||
                      timeNowSelect1 == null ||
                      rep1SelectReal == null) {
                    popup("Cannot save, All 6 options should be selected.", '');
                  } else {
                    if (DateFormat('yyyy/MM/dd HH:mm:ss')
                            .parse(
                                '${dateNowSelect.toString()} ${timeNowSelect.toString()}')
                            .compareTo(DateFormat('yyyy/MM/dd HH:mm:ss').parse(
                                '${dateNowSelect1.toString()} ${timeNowSelect1.toString()}')) >
                        0) {
                      //wrong show popup
                      //วันที่ไม่ถูกต้อง เพราะว่า เวลาปิดอุปกรณ์มันอยู่ก่อนเวลาเปิดอุปกรณ์
                      popup(
                          "The date and time are incorrect. please check again",
                          '');
                    } else {
                      //ok show popup
                      popup("Saved", '');
                    }
                  }
                } else {
                  popup("Cannot save, should select a time.", '');
                }
              },
              child: const Text(
                "Save",
                style: TextStyle(
                  color: Color.fromARGB(255, 117, 138, 214),
                  fontWeight: FontWeight.w800,
                ),
              ),
            )
          ],
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow
          title: const Text('Set Time',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black)),
          iconTheme:
              const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: Container(
            //กรอบใหญ่
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 255, 255, 255),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(children: [
              //กรอบเลือกเวลาเปิด
              Container(
                padding: const EdgeInsets.only(
                    left: 10, right: 10, top: 10, bottom: 25),
                width: size.width,
                height: size.height * 0.35,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 255, 255, 255),
                  border: Border.all(
                    color: const Color.fromARGB(255, 117, 138, 214),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    //เริ่มทำงาน
                    Container(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Row(
                        children: [
                          const Text(
                            'Start Working',
                            style: TextStyle(
                                fontSize: 25, fontWeight: FontWeight.bold),
                          ),
                          const Spacer(),
                          //สวิตซ์เปิดการทำงาน
                          FlutterSwitch(
                            width: 40,
                            height: 20,
                            valueFontSize: 15.0,
                            toggleSize: 25.0,
                            value: status1,
                            borderRadius: 30.0,
                            padding: 4.0,
                            // showOnOff: true,
                            activeColor:
                                const Color.fromARGB(255, 117, 138, 214),
                            onToggle: (val) {
                              setState(() {
                                status1 = val;
                                if (status1 == true) {
                                  // status2 = false;
                                  print('Start Working');
                                } else {
                                  dateNowSelect = null;
                                  timeNowSelect = null;
                                  repSelectReal = null;
                                }
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    //วันที่
                    Container(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: TextButton(
                          onPressed: (() =>
                              {status1 ? _showDatePicker() : null}),
                          child: Row(
                            children: [
                              Text(
                                'Date',
                                style: TextStyle(
                                    fontSize: 18,
                                    color: status1 ? Colors.black : Colors.grey,
                                    fontWeight: FontWeight.bold),
                              ),
                              const Spacer(),
                              Text(
                                dateNowSelect ?? 'Select Date',
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromARGB(255, 160, 160, 160)),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                color: status1 ? Colors.black : Colors.grey,
                              ),
                            ],
                          ),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    //เวลา
                    Container(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: TextButton(
                          onPressed: (() =>
                              {status1 ? _showTimePicker() : null}),
                          child: Row(children: [
                            Text(
                              'Time',
                              style: TextStyle(
                                  fontSize: 18,
                                  color: status1 ? Colors.black : Colors.grey,
                                  fontWeight: FontWeight.bold),
                            ),
                            const Spacer(),
                            Text(
                              timeNowSelect ?? 'Select Time',
                              style: const TextStyle(
                                  fontSize: 16,
                                  color: Color.fromARGB(255, 160, 160, 160)),
                            ),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: status1 ? Colors.black : Colors.grey,
                            ),
                          ]),
                        )),
                    const Spacer(),
                    //การทำซ้ำ
                    Container(
                        padding: const EdgeInsets.only(
                            left: 10, right: 10, bottom: 10),
                        child: TextButton(
                          onPressed: () => {
                            scrollController.dispose(),
                            scrollController =
                                FixedExtentScrollController(initialItem: index),
                            status1
                                ? showCupertinoModalPopup(
                                    //กดออกไม่ได้
                                    barrierDismissible: false,
                                    context: context,
                                    builder: (context1) => CupertinoActionSheet(
                                      actions: [RepetitionOpen()],
                                      cancelButton: CupertinoActionSheetAction(
                                        child: const Text('OK'),
                                        onPressed: () {
                                          setState(() {
                                            repSelectReal = repSelect ?? 'Once';
                                          });
                                          Navigator.pop(context1);
                                        },
                                      ),
                                    ),
                                  )
                                : null
                          },
                          child: Row(children: [
                            Text(
                              'Repetition',
                              style: TextStyle(
                                  fontSize: 18,
                                  color: status1 ? Colors.black : Colors.grey,
                                  fontWeight: FontWeight.bold),
                            ),
                            const Spacer(),
                            Text(
                              repSelectReal ?? 'Select Reptition',
                              style: const TextStyle(
                                  fontSize: 16,
                                  color: Color.fromARGB(255, 160, 160, 160)),
                            ),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: status1 ? Colors.black : Colors.grey,
                            ),
                          ]),
                        )),
                    Container(
                      //padding left:5, right:5
                      width: size.width,
                      height: 2,
                      color: Colors.black12,
                    )
                  ],
                ),
              ),
              SizedBox(
                width: size.width,
                height: 30,
              ),
              //กรอบปิดการทำงาน
              Container(
                  padding: const EdgeInsets.only(
                      left: 10, right: 10, top: 10, bottom: 25),
                  width: size.width,
                  height: size.height * 0.35,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 255, 255, 255),
                    border: Border.all(
                      color: const Color.fromARGB(255, 117, 138, 214),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      Container(
                        //กดปิดการทำงาน
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Row(
                          children: [
                            const Text(
                              'Turn Off',
                              style: TextStyle(
                                  fontSize: 25, fontWeight: FontWeight.bold),
                            ),
                            const Spacer(),
                            //สวิตซ์ปิดการทำงาน
                            FlutterSwitch(
                              width: 40,
                              height: 20,
                              valueFontSize: 15.0,
                              toggleSize: 25.0,
                              value: status2,
                              borderRadius: 30.0,
                              padding: 4.0,
                              // showOnOff: true,
                              activeColor:
                                  const Color.fromARGB(255, 117, 138, 214),
                              onToggle: (val) {
                                setState(() {
                                  status2 = val;
                                  if (status2 == true) {
                                    // status1 = false;
                                    print('Turn Off');
                                  } else {
                                    dateNowSelect1 = null;
                                    timeNowSelect1 = null;
                                    rep1SelectReal = null;
                                  }
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      //วันที่
                      Container(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: TextButton(
                          onPressed: () {
                            status2 ? _showDatePicker1() : null;
                          },
                          child: Row(
                            children: [
                              Text(
                                'Date',
                                style: TextStyle(
                                    fontSize: 18,
                                    color: status2 ? Colors.black : Colors.grey,
                                    fontWeight: FontWeight.bold),
                              ),
                              const Spacer(),
                              Text(
                                dateNowSelect1 ?? 'Select Date',
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromARGB(255, 160, 160, 160)),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                color: status2 ? Colors.black : Colors.grey,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      //เวลา
                      Container(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: TextButton(
                            onPressed: () {
                              status2 ? _showTimePicker1() : null;
                            },
                            child: Row(children: [
                              Text(
                                'Time',
                                style: TextStyle(
                                    fontSize: 18,
                                    color: status2 ? Colors.black : Colors.grey,
                                    fontWeight: FontWeight.bold),
                              ),
                              const Spacer(),
                              Text(
                                timeNowSelect1 ?? 'Select Time',
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromARGB(255, 160, 160, 160)),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                color: status2 ? Colors.black : Colors.grey,
                              ),
                            ]),
                          )),
                      const Spacer(),
                      //การทำซ้ำ
                      Container(
                        padding: const EdgeInsets.only(
                            left: 10, right: 10, bottom: 10),
                        child: TextButton(
                          onPressed: () {
                            scrollController.dispose();
                            scrollController =
                                FixedExtentScrollController(initialItem: index);
                            status2
                                ? showCupertinoModalPopup(
                                    //กดออกไม่ได้
                                    barrierDismissible: false,
                                    context: context,
                                    builder: (context2) => CupertinoActionSheet(
                                      actions: [RepetitionClose()],
                                      cancelButton: CupertinoActionSheetAction(
                                        child: const Text('OK'),
                                        onPressed: () {
                                          setState(() {
                                            rep1SelectReal =
                                                rep1Select ?? 'Once';
                                          });
                                          Navigator.pop(context2);
                                        },
                                      ),
                                    ),
                                  )
                                : null;
                          },
                          child: Row(
                            children: [
                              Text(
                                'Repetition',
                                style: TextStyle(
                                    fontSize: 18,
                                    color: status2 ? Colors.black : Colors.grey,
                                    fontWeight: FontWeight.bold),
                              ),
                              const Spacer(),
                              Text(
                                rep1SelectReal ?? 'Select Reptition',
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromARGB(255, 160, 160, 160)),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                color: status2 ? Colors.black : Colors.grey,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: size.width,
                        height: 2,
                        color: Colors.black12,
                      )
                    ],
                  ))
            ])));
  }

  //Repetition Open
  Widget RepetitionOpen() => SizedBox(
        height: 180,
        child: StatefulBuilder(
          builder: (context, setState) => CupertinoPicker(
            scrollController: scrollController,
            looping: true,
            itemExtent: 64,
            selectionOverlay: CupertinoPickerDefaultSelectionOverlay(
              background: CupertinoColors.activeBlue.withOpacity(0.2),
            ),
            children: List.generate(items.length, (index) {
              final isSelected = this.index == index;
              final item = items[index];
              final color = isSelected
                  ? CupertinoColors.activeBlue
                  : CupertinoColors.black;
              return Center(
                child: Text(
                  item,
                  style: TextStyle(color: color, fontSize: 22),
                ),
              );
            }),
            onSelectedItemChanged: (index) {
              final item = items[index];
              controller.text = item;
              this.index = index;
              setState(
                () => {
                  repSelect = item,
                  index = items.indexWhere((e) => e == repSelect),
                  print('Select Repetition: $repSelect'),
                },
              );
            },
          ),
        ),
      );

  //Repetition Close
  Widget RepetitionClose() => SizedBox(
        height: 200,
        child: StatefulBuilder(
          builder: (context, setState) => CupertinoPicker(
            scrollController: scrollController,
            looping: true,
            itemExtent: 64,
            selectionOverlay: CupertinoPickerDefaultSelectionOverlay(
              background: CupertinoColors.activeBlue.withOpacity(0.2),
            ),
            children: List.generate(items.length, (index) {
              final isSelected = this.index == index;
              final item = items[index];
              final color = isSelected
                  ? CupertinoColors.activeBlue
                  : CupertinoColors.black;
              return Center(
                child: Text(
                  item,
                  style: TextStyle(color: color, fontSize: 22),
                ),
              );
            }),
            onSelectedItemChanged: (index) {
              final item = items[index];
              controller.text = item;
              this.index = index;
              setState(
                () => {
                  rep1Select = item,
                  print('Select Repetition: $rep1Select'),
                },
              );
            },
          ),
        ),
      );

  //popup
  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false,
        child: AlertDialog(
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            if (move == 'cancel') ...{
              //ok
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    alignment: Alignment.center,
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context, 'Cancel');
                        setState(() {});
                      },
                      child: const Text(
                        'Ok',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Color.fromARGB(255, 117, 138, 214)),
                      ),
                    ),
                  ),

                  //cancel
                  Container(
                    alignment: Alignment.center,
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context, 'Cancel');
                      },
                      child: const Text(
                        'Cancel',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Color.fromARGB(255, 117, 138, 214)),
                      ),
                    ),
                  ),
                ],
              ),
            } else ...{
              Container(
                alignment: Alignment.center,
                child: TextButton(
                  onPressed: () {
                    Navigator.pop(context, 'Ok');
                  },
                  child: const Text(
                    'Ok',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 117, 138, 214)),
                  ),
                ),
              ),
            }
          ],
        ),
      ),
    );
  }
}
