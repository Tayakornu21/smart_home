import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/addDevice/addDevicePage.dart';
import 'package:homeplus_phase1/widget/navigationBottomBarWidget.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingWifiPage extends StatefulWidget {
  const SettingWifiPage({super.key});

  @override
  State<SettingWifiPage> createState() => _SettingWifiPageState();
}

class _SettingWifiPageState extends State<SettingWifiPage> {
  // Future<String> getWifiName() async {
  //   final NetworkInfo networkInfo = NetworkInfo();
  //   var wifiName = await networkInfo.getWifiName();
  //   return wifiName.toString();
  // }

  tokenClear() async {
    print('[tokenClear] Im tokenClear function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('serial');
    prefs.remove('cilentId');
    prefs.remove('token');
    prefs.remove('secret');
  }

  @override
  void initState() {
    super.initState();
    print('setting wifi page');
    //เริ่มต้นการทำงานในรหน้านี้จะทำการเปิดหน้า ตั้งค่าไวไฟของมือถือ
    //ให้ไปเชื่อมต่อไวไฟของตัวอุปกรณ์
    AppSettings.openWIFISettings(
      asAnotherTask: true, //กดย้อนกลับจะกลับมาที่แอป
    ); //open setting system of phone.
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false, //กดย้อนกลับไม่ได้
      child: Scaffold(
          body: Container(
        width: size.width,
        height: size.height,
        color: Colors.white,

        ///alignment: Alignment.center,
        child: Stack(
          children: [
            Container(
              alignment: Alignment.center,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // const Icon(
                    //   Icons.signal_wifi_statusbar_connected_no_internet_4,
                    //   size: 100,
                    //   color: Color.fromARGB(255, 180, 180, 220),
                    // ),

                    //text 'Press "Connect" to connect to the device.'
                    Container(
                      width: size.width,
                      alignment: Alignment.center,
                      child: const Text(
                          'Press "Connect" to connect to the device.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 24,
                              color: Color.fromARGB(255, 180, 180, 220),
                              fontWeight: FontWeight.w600)),
                    ),

                    //เว้นว่าง
                    const SizedBox(
                      height: 15,
                    ),

                    //bt เชื่อมต่อ
                    SizedBox(
                      width: size.width * 0.3,
                      height: size.height * 0.06,
                      child: TextButton(
                        style: TextButton.styleFrom(
                          backgroundColor:
                              const Color.fromARGB(255, 117, 138, 214),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.zero,
                          textStyle: const TextStyle(fontSize: 20),
                        ),
                        onPressed: () async {
                          // final info = NetworkInfo();
                          // var wifiName = await info.getWifiName();
                          //เป็นการเช้คว่าไวไฟที่มือถือเชื่อมต่ออยุ่ตอนนี้เป็นชื่อเดียวกันกับที่อุปกรณ์ปล่อยออกมาไหม
                          final wifiManager = NetworkInfo();
                          final wifiName = await wifiManager.getWifiName();
                          print('currentSSID: $wifiName');
                          if (wifiName == '"SmartPlug_Configure_WiFi"') {
                            //if (true) {
                            //ถ้าตรงจะแสดงป้อปอัพและเปลี่ยนหน้า
                            // ignore: use_build_context_synchronously
                            showDialog<String>(
                              barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) => WillPopScope(
                                onWillPop: () async => false,
                                child: AlertDialog(
                                  title: const Row(
                                    //mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Notification',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.black),
                                      ),
                                    ],
                                  ),
                                  content: const Text(
                                      '   successfully connected to the device',
                                      style: TextStyle(
                                          fontSize: 21,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black)),
                                  actions: <Widget>[
                                    TextButton(
                                      onPressed: () => {
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const AddDevicePage()))
                                        //Navigator.pop(context, 'OK')
                                      },
                                      child: const Text('Ok',
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w500)),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          } else {
                            //ไม่เหมือนแจ้งเตือนเฉยๆ
                            // ignore: use_build_context_synchronously
                            showDialog<String>(
                              barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) => WillPopScope(
                                onWillPop: () async => false,
                                child: AlertDialog(
                                  title: const Row(
                                    //mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Notification',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.black),
                                      ),
                                    ],
                                  ),
                                  content: const Text(
                                      '   Connection error!, Please check the WiFi you are connected to.',
                                      style: TextStyle(
                                          fontSize: 21,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black)),
                                  actions: <Widget>[
                                    TextButton(
                                      onPressed: () {
                                        popupExit(
                                            '   Do you want to un-add a device?');
                                      },
                                      child: const Text('Exit',
                                          style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w500,
                                          )),
                                    ),
                                    TextButton(
                                      onPressed: () => {
                                        AppSettings.openWIFISettings(
                                          asAnotherTask: true,
                                        ).then((value) {
                                          Navigator.pop(context, 'OK');
                                        })
                                        //Navigator.pop(context, 'OK')
                                      },
                                      child: const Text('Try again',
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w500)),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }
                        },
                        child: const Text('Connect',
                            style: TextStyle(
                                // decoration: TextDecoration.underline,
                                fontSize: 21,
                                color: Colors.white,
                                fontWeight: FontWeight.w600)),
                      ),
                    ),
                  ]),
            ),

            //ปุ่มยกเลิก
            Container(
              margin: EdgeInsets.only(top: size.height * 0.88),
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  TextButton(
                      onPressed: () {
                        print('exit');
                        popupExit('   Do you want to un-add a device?');
                      },
                      child: const Text(
                        'Cancel',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 21,
                          decoration: TextDecoration.underline,
                          color: Colors.black38,
                          fontWeight: FontWeight.w600,
                        ),
                      )),
                ],
              ),
            )
          ],
        ),
      )),
    );
  }

  popupExit(text) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false,
        child: AlertDialog(
          title: const Row(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Notification',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
            ],
          ),
          content: Text(text,
              style: const TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.w500,
                  color: Colors.black)),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.pop(context, 'cancel');
              },
              child: const Text('Cancel',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                  )),
            ),
            TextButton(
              onPressed: () => {
                Navigator.pop(context, 'OK'),
                tokenClear(),
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            const NavigationBottomBarWidget()))
              },
              child: const Text('OK',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500)),
            ),
          ],
        ),
      ),
    );
  }

  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Loading...',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }
}
