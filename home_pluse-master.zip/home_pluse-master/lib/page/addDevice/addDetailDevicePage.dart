import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/widget/navigationBottomBarWidget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

//หลังจาก Configure wifi เสร็จแล้วต้องทำการกลับมาเชื่อม internet ก่อน
//หน้านี้จะเป็นการเพิ่มรายละเอียดของอุปกรณ์
class AddDetailDevice extends StatefulWidget {
  const AddDetailDevice({super.key});

  @override
  State<AddDetailDevice> createState() => _AddDetailDeviceState();
}

class _AddDetailDeviceState extends State<AddDetailDevice> {
  //String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";
  String? nameDevice;
  String? selectRoom;
  TextEditingController deviceNameController = TextEditingController();
  TextEditingController roomNameController = TextEditingController();
  var roomList = [
    'Bedroom',
    'Bathroom',
    'Shower room',
    'Kitchen',
    'Living room',
    "Eating room",
    "Children's room",
    'Work room',
    'Office',
    'Balcony',
    'Garden',
  ];

  //api function----------------------------------------------------------------
  addDevice(nameDevice, selectRoom) async {
    print('[addDevice] Im addDevice function');
    String serialNumber = await getSerialNumber();
    String houseId = await getHouseId();
    String clientId = await getClientId();
    String token = await getToken();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/updateDevice');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "serialNumber": serialNumber,
            "deviceName": nameDevice,
            "houseID": houseId,
            'room': selectRoom,
            //'typeName': 'plug-4',
          });

      print('[addDevice] status Code : ${response.statusCode}');
      print('[addDevice] response body: ${response.body}');

      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)

      if (jsonResponse['error'] == false) {
        //send off shadow to netpie
        //หลังจากเพิ่มอุปกรณ์เสร้จจะ้ตองส่งคำสั่งควบคุอุปกรณ์ครั้งแรกให้เป็น off
        sendHTTPNETPIERelay1Off(clientId, token);
        sendHTTPNETPIERelay2Off(clientId, token);
        sendHTTPNETPIERelay3Off(clientId, token);
        sendHTTPNETPIERelay4Off(clientId, token);
        tokenClear();
        return popup('Add device is complete.', 'move');
      } else {
        if (jsonResponse['message'] ==
            "Data too long for column 'deviceName' at row 1") {
          return popup("Can't add device!\nThe name is too long.",
              'null'); //wrong status code
        } else {
          return popup('Failed to add device!\nSomething is wrong.', 'null');
        }
      }
    } catch (e) {
      print('[addDevice] error: $e');
      popup("Failed to add device.!\nConnection failed.",
          'null'); //wrong code or can't connect to server.
    }
  }
  //----------------------------------------------------------------------------

  //control netpie -------------------------------------------------------------
  void sendHTTPNETPIERelay1Off(clientId, token) async {
    String username = clientId; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0';
    String password = token; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP';
    // String basicAuth = 'Basic ' +
    //     convert.base64Encode(convert.utf8.encode('$username:$password'));
    String basicAuth = 'Device $username:$password';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay1');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: "R01_OFF");

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay2Off(clientId, token) async {
    String username = clientId; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0';
    String password = token; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP';
    String basicAuth = 'Basic ' +
        convert.base64Encode(convert.utf8.encode('$username:$password'));
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay2');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R02_OFF');

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay3Off(clientId, token) async {
    String username = clientId; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0';
    String password = token; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP';
    String basicAuth = 'Basic ' +
        convert.base64Encode(convert.utf8.encode('$username:$password'));
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay3');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R03_OFF');

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay4Off(clientId, token) async {
    String username = clientId; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0';
    String password = token; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP';
    String basicAuth = 'Basic ' +
        convert.base64Encode(convert.utf8.encode('$username:$password'));
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay4');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R04_OFF');

    print(r.statusCode);
    print(r.body);
  }
  //----------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //get and clear data in localstorage
  getSerialNumber() async {
    print('[getSerialNumber] Im in  getSerialNumber');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('serial').toString();
    //prefs.setString('accessToken', token);
  }

  getHouseId() async {
    print('[getHouseId] Im in  getHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('mainHouseid').toString();
    //prefs.setString('accessToken', token);
  }

  getClientId() async {
    print('[getClientId] Im in  getClientId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('clientId').toString();
    //prefs.setString('accessToken', token);
  }

  getToken() async {
    print('[getToken] Im in  getToken');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('token').toString();
    //prefs.setString('accessToken', token);
  }

  //clear token
  tokenClear() async {
    print('[tokenClear] Im tokenClear function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('serial');
    prefs.remove('clientId');
    prefs.remove('token');
    prefs.remove('secret');
  }
  //----------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        body: SingleChildScrollView(
            child: Container(
          width: size.width,
          height: size.height,
          color: Colors.white,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              //Appbar
              Container(
                  width: size.width,
                  height: size.height * 0.082,
                  //color: Colors.red,
                  //padding: EdgeInsets.only(left: 10, top: size.height * 0.03),
                  alignment: Alignment.bottomCenter,
                  child: const Text(
                    'Device details',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600),
                  )),

              //body//
              Container(
                width: size.width,
                height: size.height * 0.88,
                //color: Colors.yellow,
                padding: const EdgeInsets.only(
                    top: 20, bottom: 10, left: 10, right: 10),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  //name device//
                  Container(
                    width: size.width * 0.9,
                    height: size.height * 0.08,
                    //color: Colors.orange,
                    padding: const EdgeInsets.only(left: 10),
                    alignment: Alignment.center,
                    child: Row(
                      children: [
                        const Text('Name',
                            style: TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w600)),
                        const Spacer(),
                        TextButton(
                          onPressed: () {
                            deviceNameController.clear;
                            showModalBottomSheet(
                                isDismissible: false,
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(
                                        top: Radius.circular(25.0))),
                                backgroundColor: Colors.white,
                                context: context,
                                isScrollControlled: true,
                                builder: (BuildContext context) {
                                  return StatefulBuilder(builder:
                                      (BuildContext context, setState) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 12.0),
                                            child: Container(
                                              width: size.width,
                                              height: size.height * 0.08,
                                              //color: Colors.red,
                                              alignment: Alignment.center,
                                              child: const Text(
                                                'Device name',
                                                style: TextStyle(
                                                    fontSize: 24,
                                                    fontWeight:
                                                        FontWeight.w600),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 12.0),
                                            child: Container(
                                              width: size.width * 0.9,
                                              height: size.height * 0.08,
                                              alignment: Alignment.center,
                                              //margin: const EdgeInsets.only(top: 15),
                                              decoration: BoxDecoration(
                                                color: Colors.black12,
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                              ),
                                              padding: const EdgeInsets.only(
                                                  left: 20, right: 20),
                                              child: TextField(
                                                controller:
                                                    deviceNameController, //อาจจะไม่ได้ใช้
                                                onChanged: (text) {
                                                  setState(() {
                                                    //for check controller
                                                  });
                                                },
                                                enableSuggestions: false,
                                                autocorrect: false,
                                                decoration:
                                                    const InputDecoration(
                                                  hintStyle: TextStyle(
                                                      color: Colors.black38,
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.w600),
                                                  hintText: 'Device name',
                                                  border: InputBorder.none,
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: 10),
                                          Padding(
                                              padding: EdgeInsets.only(
                                                  bottom: MediaQuery.of(context)
                                                      .viewInsets
                                                      .bottom),
                                              child: Container(
                                                width: size.width * 0.9,
                                                height: size.height * 0.08,
                                                alignment: Alignment.center,
                                                //color: Colors.yellowAccent,
                                                padding: const EdgeInsets.only(
                                                    left: 10, right: 10),
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      width: size.width * 0.38,
                                                      height:
                                                          size.height * 0.07,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20),
                                                        color: const Color
                                                                .fromARGB(
                                                            255, 189, 189, 189),
                                                      ),
                                                      child: TextButton(
                                                          style: ButtonStyle(
                                                              shape: MaterialStateProperty.all<
                                                                      RoundedRectangleBorder>(
                                                                  RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20),
                                                          ))),
                                                          child: const Text(
                                                            'Cancel',
                                                            style: TextStyle(
                                                                fontSize: 24,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                color: Color
                                                                    .fromARGB(
                                                                        255,
                                                                        35,
                                                                        35,
                                                                        35)),
                                                          ),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    context)
                                                                .pop();
                                                          }),
                                                    ),
                                                    const Spacer(),
                                                    if (deviceNameController
                                                            .text !=
                                                        '') ...{
                                                      Container(
                                                        width:
                                                            size.width * 0.38,
                                                        height:
                                                            size.height * 0.07,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(20),
                                                          color: const Color
                                                                  .fromARGB(255,
                                                              117, 138, 214),
                                                        ),
                                                        child: TextButton(
                                                            style: ButtonStyle(
                                                                shape: MaterialStateProperty.all<
                                                                        RoundedRectangleBorder>(
                                                                    RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          20),
                                                            ))),
                                                            child: const Text(
                                                              'Ok',
                                                              style: TextStyle(
                                                                  fontSize: 24,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            onPressed: () {
                                                              //setstate
                                                              setState(() {
                                                                nameDevice =
                                                                    deviceNameController
                                                                        .text;
                                                              });

                                                              //close popup
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            }),
                                                      ),
                                                    } else ...{
                                                      Container(
                                                        width:
                                                            size.width * 0.38,
                                                        height:
                                                            size.height * 0.07,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(20),
                                                          color: const Color
                                                                  .fromARGB(122,
                                                              117, 138, 214),
                                                        ),
                                                        child: TextButton(
                                                            style: ButtonStyle(
                                                                shape: MaterialStateProperty.all<
                                                                        RoundedRectangleBorder>(
                                                                    RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          20),
                                                            ))),
                                                            child: const Text(
                                                              'Ok',
                                                              style: TextStyle(
                                                                  fontSize: 24,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            onPressed: () {
                                                              //notting
                                                            }),
                                                      ),
                                                    }
                                                  ],
                                                ),
                                              )),
                                          const SizedBox(height: 10),
                                        ],
                                      ),
                                    );
                                  });
                                });
                          },
                          child: Row(
                            children: [
                              Container(
                                  width: size.width * 0.6,
                                  height: size.height * 0.074,
                                  alignment: Alignment.centerRight,
                                  padding: const EdgeInsets.only(left: 5),
                                  //color: Colors.yellow,
                                  child: Text(
                                    nameDevice ?? 'Specify device name',
                                    style: const TextStyle(
                                        color: Colors.black38, fontSize: 24),
                                  )),
                              //const Spacer(),
                              Container(
                                  width: size.width * 0.055,
                                  height: size.height * 0.074,
                                  alignment: Alignment.centerRight,
                                  //color: Colors.blue,
                                  child: const Icon(
                                    Icons.arrow_forward_ios,
                                    size: 15,
                                    color: Colors.black,
                                  ))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),

                  //Space//
                  Container(
                    width: size.width * 0.9,
                    height: 2,
                    color: Colors.black45,
                    margin: const EdgeInsets.only(top: 10),
                  ),

                  //select room//
                  Container(
                    width: size.width * 0.9,
                    height: size.height * 0.08,
                    //color: Colors.orange,
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(top: 10),
                    padding: const EdgeInsets.only(left: 10),
                    child: Row(
                      children: [
                        const Text('Room',
                            style: TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w600)),
                        const Spacer(),
                        TextButton(
                          onPressed: () {
                            roomNameController.clear();
                            showDialog<String>(
                                context: context,
                                builder: (BuildContext context) => AlertDialog(
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10))),
                                    contentPadding:
                                        const EdgeInsets.only(bottom: 10),
                                    title: Column(
                                      children: [
                                        Row(
                                          children: [
                                            //back bt
                                            Container(
                                              width: 35,
                                              alignment: Alignment.centerLeft,
                                              child: TextButton(
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                                child: const Icon(
                                                  Icons.arrow_back,
                                                  size: 20,
                                                  color: Colors.black,
                                                ),
                                              ),
                                            ),
                                            const Spacer(),
                                            const Text(
                                              'Select room',
                                              style: TextStyle(
                                                  fontSize: 24,
                                                  fontWeight: FontWeight.w600),
                                            ),
                                            const Spacer(),

                                            //ok bt
                                            Container(
                                              width: 35,
                                              alignment: Alignment.centerLeft,
                                              child: TextButton(
                                                onPressed: () {
                                                  if (roomNameController.text !=
                                                      '') {
                                                    setState(() {
                                                      selectRoom =
                                                          roomNameController
                                                              .text;
                                                    });
                                                  }

                                                  Navigator.of(context).pop();
                                                },
                                                child: const Icon(
                                                  Icons.check,
                                                  size: 20,
                                                  color: Colors.black,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                        Container(
                                          width: size.width * 0.9,
                                          height: size.height * 0.06,
                                          alignment: Alignment.centerLeft,
                                          margin:
                                              const EdgeInsets.only(top: 15),
                                          decoration: BoxDecoration(
                                            color: Colors.black12,
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          padding:
                                              const EdgeInsets.only(left: 10),
                                          child: TextField(
                                            maxLength: 30,
                                            controller: roomNameController,
                                            enableSuggestions: false,
                                            autocorrect: false,
                                            decoration: const InputDecoration(
                                              counterText: '',
                                              hintStyle: TextStyle(
                                                  color: Colors.black38,
                                                  fontSize: 21,
                                                  fontWeight: FontWeight.w600),
                                              hintText: 'Room name',
                                              border: InputBorder.none,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        Container(
                                          width: size.width * 0.8,
                                          height: 2,
                                          color: Colors.black45,
                                        ),
                                      ],
                                    ),
                                    content: Container(
                                      width: size.width,
                                      //height: size.height*0.5,
                                      padding: const EdgeInsets.all(10),
                                      //color: Colors.yellow,
                                      child: Stack(
                                        children: [
                                          Container(
                                              padding: const EdgeInsets.only(
                                                  left: 15),
                                              child: const Text(
                                                'Recommended room',
                                                style: TextStyle(
                                                    fontSize: 21,
                                                    color: Colors.black38),
                                              )),
                                          Container(
                                            margin:
                                                const EdgeInsets.only(top: 20),
                                            child: ListView.builder(
                                                shrinkWrap: true,
                                                itemCount: roomList.length,
                                                itemBuilder: (context, i) =>
                                                    Container(
                                                      width: size.width,
                                                      height:
                                                          size.height * 0.05,
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 15),
                                                      child: TextButton(
                                                        style: TextButton
                                                            .styleFrom(
                                                          alignment: Alignment
                                                              .centerLeft,
                                                          padding:
                                                              EdgeInsets.zero,
                                                        ),
                                                        onPressed: () {
                                                          setState(() {
                                                            selectRoom =
                                                                roomList[i]
                                                                    .toString();
                                                          });
                                                          Navigator.of(context)
                                                              .pop();
                                                        },
                                                        child: SizedBox(
                                                          width: size.width,
                                                          child: Text(
                                                            roomList[i],
                                                            textAlign:
                                                                TextAlign.left,
                                                            style:
                                                                const TextStyle(
                                                                    fontSize:
                                                                        21,
                                                                    color: Colors
                                                                        .black),
                                                          ),
                                                        ),
                                                      ),
                                                    )),
                                          ),
                                        ],
                                      ),
                                    )));
                          },
                          child: Row(
                            children: [
                              Container(
                                  width: size.width * 0.6,
                                  height: size.height * 0.074,
                                  alignment: Alignment.centerRight,
                                  padding: const EdgeInsets.only(left: 5),
                                  //color: Colors.yellow,
                                  child: Text(
                                    selectRoom ?? 'Specify room name',
                                    style: const TextStyle(
                                        color: Colors.black38, fontSize: 24),
                                  )),
                              //const Spacer(),
                              Container(
                                  width: size.width * 0.055,
                                  height: size.height * 0.074,
                                  alignment: Alignment.centerRight,
                                  //color: Colors.blue,
                                  child: const Icon(
                                    Icons.arrow_forward_ios,
                                    size: 15,
                                    color: Colors.black,
                                  ))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const Spacer(),

                  //bt
                  if (nameDevice != null && selectRoom != null) ...{
                    //กดได้
                    Container(
                      width: size.width * 0.8,
                      height: size.height * 0.07,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: const Color.fromARGB(255, 117, 138, 214)),
                      child: TextButton(
                          style: ButtonStyle(
                              shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ))),
                          child: const Text(
                            'Save',
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          ),
                          onPressed: () async {
                            print('comeback to main page');
                            //for demo
                            // SharedPreferences prefs =
                            //     await SharedPreferences.getInstance();
                            // prefs.setString(
                            //     'demo', 'ok'); //set userId to localstorage

                            //send add api
                            //got ot main page
                            loadingPopup(context);
                            addDevice(nameDevice, selectRoom);
                            //Navigator.pop(context, 'Cancel');
                          }),
                    )
                  } else ...{
                    //กดไม่ได้
                    Container(
                      width: size.width * 0.8,
                      height: size.height * 0.07,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: const Color.fromARGB(122, 117, 138, 214)),
                      child: TextButton(
                          style: ButtonStyle(
                              shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ))),
                          onPressed: null,
                          child: const Text(
                            'Save',
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          )),
                    )
                  }
                ]),
              )
            ],
          ),
        )),
      ),
    );
  }

  popup(text, move) {
    //no block
    return showDialog<String>(
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () async {
                  //clear loading popup
                  Navigator.pop(context, 'Cancel');
                  if (move == 'move') {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const NavigationBottomBarWidget()));
                  } else {
                    //clear  popup
                    Navigator.of(context).pop();
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  loadingPopup(context) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.all(20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: const Text(
              'Loading...',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
        ),
      ),
    );
  }
}
