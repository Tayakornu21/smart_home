// ignore_for_file: avoid_print

import 'dart:convert';

import 'package:flutter/material.dart';
//import 'package:homeplus_phase1/page/addDevice/addDevicePage.dart';
import 'package:homeplus_phase1/page/addDevice/settingWifiPage.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SendSerialPage extends StatefulWidget {
  const SendSerialPage({super.key});

  @override
  State<SendSerialPage> createState() => _SendSerialPageState();
}

class _SendSerialPageState extends State<SendSerialPage> {
  //String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";
  TextEditingController serialController = TextEditingController();

  //Api function ---------------------------------------------------------------
  sendSerialApi(sn) async {
    //sn = Serial Number
    print('[sendSerialApi] Im sendSerialApi function');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/addDevice');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"serialNumber": sn, "typeName": 'plug-4'});

      //print('[sendSerialApi] status Code : ${response.statusCode}');
      //print('[sendSerialApi] status Code : ${response.body}');
      var jsonResponse = await jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        print('[sendSerialApi] response.body: ${response.body}');

        if (jsonResponse['error'] == false) {
          //print('test: ${jsonResponse['data'][0]['clientID'].toString()}');
          // print(
          //     '[sendSerialApi] clientID: ${jsonResponse['data']['clientID'].toString()}');
          // print(
          //     '[sendSerialApi] token: ${jsonResponse['data']['token'].toString()}');
          // print(
          //     '[sendSerialApi] secret: ${jsonResponse['data']['secret'].toString()}');
          //storage to local : token and secert
          //46f16633-d9b6-46b6-9d55-47f77610d8b3 Tx3qdoCpmBxYkQGfPMf9deFEMWJ47eTw
          //หลังจากส่งค่า serial number ไปแล้วก็จะ set ค่าที่รับมาจากเซิฟเวอร์ลง localStorage
          setToken(
              sn,
              jsonResponse['data']['clientID'].toString(),
              jsonResponse['data']['token'].toString(),
              jsonResponse['data']['secret'].toString());
          print('[sendSerialApi] finsih!');
          return popup(
              "Serial number is correct.\nPlease connect device's wifi.",
              "move"); //correct serial number
        } else {
          print('[sendSerialApi] finsih! worng serial');
          return popup('Serial number is incorrect.\nPlease try again.',
              'null'); //wrong serial number (maybe)
        }
        
      } else {
        //something wrong about status code ส่ง serial มั่วจะได้ status code 400
        if (jsonResponse["message"] != null &&
            jsonResponse["message"] ==
                "not enought serialNumber please add one.") {
          print('[sendSerialApi] finsih! old serial');
          return popup('This serial number already used.\nPlease try again.',
              'null'); //old serial number
        } else {
          print('[sendSerialApi] finsih! worng serial');
          return popup('Serial number is incorrect.\nPlease try again.',
              'null'); //wrong serial number (maybe)
        }
      }

    } catch (e) {
      print('[sendSerialApi] error: $e');
      return popup("Can't send serial number!\nConnection failed.",
          'null'); //something wrong about code and can't connect to server
    }
  }

  //----------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //บันทึกค่า(token) ที่รับมาจากเซฺฟเวอร์ลง LocalStorage เพื่อใช้ในการเพิ่มอุปกรณ์ในหน้าต่อๆ ไป
  setToken(serial, clientId, token, secret) async {
    print('[setToken] Im setToken function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('serial', serial);
    prefs.setString('clientId', clientId);
    prefs.setString('token', token);
    prefs.setString('secret', secret);
  }

  //ล้าง token ใน localStorage กรณีต้องการยกเลิกการเพิ่มอุปกรณ์
  tokenClear() async {
    print('[tokenClear] Im tokenClear function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('serial');
    prefs.remove('clientId');
    prefs.remove('token');
    prefs.remove('secret');
  }
  //----------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () {
            tokenClear();
            Navigator.of(context).pop();
          },
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow

        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: size.width,
              height: size.height * 0.835,
              color: Colors.white,
              child: Column(
                  // mainAxisAlignment: MainAxisAlignment.start,
                  // crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //text "Fill in serial number"
                    Container(
                        width: size.width,
                        height: size.height * 0.08,
                        //color: Colors.yellow,
                        alignment: Alignment.center,
                        child: const Text(
                          'Fill in serial number',
                          style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w600,
                              color: Color.fromARGB(255, 117, 138, 214)),
                        )),

                    //textfield serial number
                    Container(
                      width: size.width,
                      height: size.height * 0.08,
                      //color: Colors.orange,
                      alignment: Alignment.center,
                      padding: const EdgeInsets.only(
                          left: 40, right: 40, top: 10, bottom: 10),
                      child: TextField(
                        controller: serialController,
                        //obscureText: true,
                        onChanged: (_) {
                          setState(() {});
                        },
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          prefixIcon: const Icon(
                            Icons.email,
                            color: Colors.black,
                          ),
                          //labelText: 'รหัสยืนยัน',
                          contentPadding: const EdgeInsets.only(left: 20),
                          hintText: "Device serial number",
                          hintStyle: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Colors.black26),
                        ),
                      ),
                    ),

                    //เว้นระยะห่าง
                    const Spacer(),

                    //bt เช้คว่ามี textfield ได้กรอกค่าอะไรไหม
                    if (serialController.text != '') ...{
                      //กดได้
                      SizedBox(
                        width: size.width * 0.8,
                        height: size.height * 0.07,
                        //color: Colors.red,
                        child: TextButton(
                          style: TextButton.styleFrom(
                            backgroundColor:
                                const Color.fromARGB(255, 117, 138, 214),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.zero,
                            textStyle: const TextStyle(fontSize: 20),
                          ),
                          onPressed: () {
                            print('serial Number: ${serialController.text}');
                            //send serial to server for get token
                            sendSerialApi(serialController.text.toString());
                            //check token and going next page (yet)
                            //this popup will show after check token already. (yet)
                          },
                          child: const Text(
                            'Send',
                            style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          ),
                        ),
                      )
                    } else ...{
                      //กดไม่ได้
                      SizedBox(
                        width: size.width * 0.8,
                        height: size.height * 0.07,
                        //color: Colors.red,
                        child: TextButton(
                          style: TextButton.styleFrom(
                            backgroundColor:
                                const Color.fromARGB(122, 117, 138, 214),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.zero,
                            textStyle: const TextStyle(fontSize: 20),
                          ),
                          onPressed: null,
                          child: const Text(
                            'Send',
                            style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          ),
                        ),
                      )
                    }
                  ]),
            ),
          ],
        ),
      ),
    );
  }

  popup(text, move) {
    //no block
    return showDialog<String>(
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
      
            height: move == "move" ? 120 : 80,
            alignment: Alignment.center,
            child: Column(
              children: [
                const SizedBox(
                  height: 10,
                ),
                if (move == "move") ...{
                  const SizedBox(
                    height: 50,
                    width: 50,
                    child: Icon(
                      Icons.check_circle,
                      color: Color.fromARGB(255, 117, 138, 214),
                      size: 50.0,
                      semanticLabel: 'Text to announce in accessibility modes',
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                },
                Text(
                  text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w600,
                      color: Colors.black),
                ),
              ],
            ),
          ),
      
          actions: <Widget>[
            Container(
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () async {
                  if (move == 'move') {
                    //check location permission allowed
                    //หลังจากส่ง serial number สำเร็จก็จะรอขอการเข้าถึงที่อยู่มือถือ
                    var locationStatus = await Permission.location.status;
                    if (locationStatus.isDenied) {
                      await Permission.locationWhenInUse
                          .request(); //request location permission : use for get wifi name
                    }
                    if (await Permission.location.isRestricted) {
                      //notting here!
                      //openAppSettings();
                    }
      
                    if (await Permission.location.isGranted) {
                      //when the location permission is allowed.
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const SettingWifiPage())); //go to setting page for connect wifi of device.
                    } else {
                      //if not
                      print('!location.isGranted');
                      Navigator.of(context).pop(); //close popup
                      return popup(
                          'Location permission is not allowed\nPlease allow it.',
                          'null'); // and open new popup for allert that location permission is not allowed.
      
                    }
                  } else {
                    Navigator.of(context).pop();
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
