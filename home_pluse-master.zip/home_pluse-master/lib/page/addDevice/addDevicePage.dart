import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/addDevice/addDetailDevicePage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wifi_scan/wifi_scan.dart';
import 'package:http/http.dart' as http;
import '../../widget/navigationBottomBarWidget.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

//หน้านี้จะเป็นการ configure wifi ให้กับตัวอุปกรณ์
//แอปจะติดต่อกับตัวอุปกรณ์โดยตรงภาพไวไฟของตัวอุปกรร์ที่มือถือกำลังเชื่อมอยู่
class AddDevicePage extends StatefulWidget {
  const AddDevicePage({Key? key}) : super(key: key);

  @override
  State<AddDevicePage> createState() => _AddDevicePageState();
}

class _AddDevicePageState extends State<AddDevicePage> {
  TextEditingController passwordWifiController = TextEditingController();
  bool _isObscure = true;
  String? ssid;
  var page = "sending";

  //Scan wifi variable and function --------------------------------------
  List<WiFiAccessPoint> accessPoints = <WiFiAccessPoint>[];
  //StreamSubscription<List<WiFiAccessPoint>>? subscription;
  bool shouldCheckCan = true;

  //Configure wifi ส่งค่าสำหรับการ configure wifi ไปยังอุปกรณ์
  configureWifi(ssid, password) async {
    print('[configureWifi] Im configureWifi configureWifi');
    //get clientId , token and secert
    String clientId = await getClientId();
    String token = await getToken();
    String secret = await getSecret();

    Map data = {
      "mqtt_Client": clientId
          .toString(), //clientId.toString(), //225c3b90-e3c7-4232-b6f5-eb0346dd9edf
      "mqtt_username": token
          .toString(), //token.toString(), //koUzVUaBwGjm2GPgWKKrD7m1Xq2dFSiB
      "mqtt_password": secret
          .toString(), //secret.toString(), //crHAqN3V3F_jxt3BFTWcEkUmCsmTH36J
      "Device_name": "SmartPlugRelay", //???
      "ssid": ssid.toString(), //'@_@.', //ssid.toString(),
      "password": password.toString() //'0828834901' //password.toString()
    };
    Uri myUri = Uri.parse('http://192.168.4.1/setWIFI');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": 'application/json',
          },
          encoding: Encoding.getByName('utf-8'),
          body: jsonEncode(data));

      print('[configureWifi] status Code : ${response.statusCode}');
      print('[configureWifi] body : ${response.body}');

      //sending api completed
      if (response.statusCode == 201 || response.statusCode == 200) {
        print('ok');
        // //go to add detail device page

        //TODOLIST(OK) : CALL SECOND API HERE FOR CHECK DEVICE CONNECT WIFI!
        //TODOLIST(OK) : COUNT TIME FOR CALL API
        Timer(
            //จับเวลา 3 วิหลังจากนั้นจะทำงานตามที่เราเขียนโค้ดไว้
            const Duration(seconds: 5),
            () => {print('call next api'), checkDeviceConnection()});

        // Navigator.pushReplacement(context,
        //     MaterialPageRoute(builder: (context) => const AddDetailDevice()));
      } else {
        return popupAlert("Cannot configure wifi.\nPlease try again.", 'null',
            'null'); //can't configure wifi.
      }
    } catch (e) {
      print('[configureWifi] error: $e');
      return popupAlert(
          "Cannot configure wifi because $e. Please try again.",
          'null',
          'null'); //something wrong about code and can't connect to server
      // return popup('Something is wrong!\nPlease try again.', 'null',
      //     'null'); //something wrong about code and can't connect to server
    }
  }

  checkDeviceConnection() async {
    print('[checkDeviceConnection] Im checkDeviceConnection');
    Uri myUri = Uri.parse('http://192.168.4.1/checkWIFIConnect');
    try {
      http.Response response = await http.get(
        myUri,
      );
      //body: jsonEncode(data));

      print('[checkDeviceConnection] status Code : ${response.statusCode}');
      print('[checkDeviceConnection] body : ${response.body}');
      var responseData = json.decode(response.body);

      //TODOLIST(OK) : CHECK RESPONSE
      if (responseData["status"] == "connected") {
        //change to next page
        // ignore: use_build_context_synchronously
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => const AddDetailDevice()));
      } else {
        //popup
        popupAlert(
            "Wifi configuration failed! Please try again.",
            'null',
            'null');
      }
    } catch (e) {
      print('[checkDeviceConnection] error: $e');
      if (e.toString() == "Connection closed before full header was received") {
        print('[checkDeviceConnection] re send checkDeviceConnection api');
        checkDeviceConnection();
      } else {
        return popupAlert(
            "Cannot configure wifi because $e. Please try again.",
            'null',
            'null'); //something wrong about code and can't connect to server
        // return popup('Something is wrong!\nPlease try again.', 'null',
        //     'null'); //something wrong about code and can't connect to server
      }
    }
  }

  //Cut whiteSpace of Thai ssid function
  //ไวไฟที่สแกนมาแสดงอาจจะเป็นช่องว่างเปล่าๆ เลยต้องตัดออก
  String chackSsid(ssid) {
    String newSsid;
    newSsid = ssid.replaceAll(RegExp(r"\s+"), "");
    if (newSsid == '') {
      return 'null';
    } else {
      return newSsid;
    }
  }

  //check password space
  //ไวไฟที่สแกนมาแสดงจะตัดส่วนที่เป็นเว้นว่างออก
  bool checkPasswordSpace(String password) {
    bool check;
    check = password.contains(' ');
    return check;
  }

  /// Show snackbar function
  void kShowSnackBar(BuildContext context, String message) {
    if (kDebugMode) print(message);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<bool> _canGetScannedResults(BuildContext context) async {
    if (shouldCheckCan) {
      // check if can-getScannedResults
      final can = await WiFiScan.instance.canGetScannedResults();
      // if can-not, then show error
      if (can != CanGetScannedResults.yes) {
        if (mounted) kShowSnackBar(context, "Cannot get scanned results: $can");
        accessPoints = <WiFiAccessPoint>[];
        return false;
      }
    }
    return true;
  }

  Future<void> _getScannedResults(BuildContext context) async {
    print('hello scan wifi');
    if (await _canGetScannedResults(context)) {
      // get scanned results
      final results = await WiFiScan.instance.getScannedResults();
      setState(() => accessPoints = results);
    }
  }
  //----------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  //clear token (yet) we will clear token after finish add device
  tokenClear() async {
    print('[tokenClear] Im tokenClear function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('serial');
    prefs.remove('clientId');
    prefs.remove('token');
    prefs.remove('secret');
  }

  getClientId() async {
    print('[getClientId] Im in  getClientId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('clientId').toString();
    //prefs.setString('accessToken', token);
  }

  getToken() async {
    print('[getToken] Im in  getToken');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('token').toString();
    //prefs.setString('accessToken', token);
  }

  getSecret() async {
    print('[getSecret] Im in  getSecret');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('secret').toString();
    //prefs.setString('accessToken', token);
  }
  //----------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    print('[addDevicePage] welcome to addDvicePage');
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(children: [
            //back bt
            // Container(
            //   width: size.width,
            //   height: size.height * 0.1,
            //   //color: Colors.red,
            //   padding: EdgeInsets.only(left: 10, top: size.height * 0.03),
            //   alignment: Alignment.centerLeft,
            //   child: IconButton(
            //     icon: const Icon(Icons.arrow_back),
            //     onPressed: () {
            //       print('go back');
            //       Navigator.of(context).pop();
            //     },
            //   ),
            // ),

            //เว้นว่าง
            SizedBox(
              width: size.width,
              height: size.height * 0.1,
            ),

            //body
            if (page == "sending") ...{
              Container(
                width: size.width,
                height: size.height * 0.865,
                //color: Colors.red,
                alignment: Alignment.center,
                child: Column(
                  //mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    const Text('Configure device wifi',
                        style: TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis),

                    //SSID and Password
                    Padding(
                        padding:
                            const EdgeInsets.only(top: 20, left: 15, right: 15),
                        child: SizedBox(
                          width: size.width,
                          height: size.height * 0.6,
                          child: Column(children: <Widget>[
                            //SSID
                            Padding(
                              padding: const EdgeInsets.all(15),
                              child: Container(
                                width: size.width * 0.8,
                                height: size.height * 0.074,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: const Color.fromARGB(
                                            255, 117, 138, 214))),
                                //color: Colors.orange,
                                child: TextButton(
                                  onPressed: () async {
                                    setState(() {
                                      accessPoints = <WiFiAccessPoint>[];
                                      //กดแล้วจะนำลิสของไวไฟที่สแกนเจอมาแสดง
                                      _getScannedResults(context).then((_) {
                                        //แสดง popup ที่ใช้แสดงรายชื่อของไวไฟ
                                        showDialog<String>(
                                            //show list of near wifi name.
                                            context: context,
                                            builder: (BuildContext context) =>
                                                AlertDialog(
                                                    shape: const RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    10))),
                                                    contentPadding:
                                                        const EdgeInsets.only(
                                                            bottom: 10),
                                                    title: Column(
                                                      //หัวข้อของ popup
                                                      children: [
                                                        //text "WIFI"
                                                        const Text(
                                                          'WIFI',
                                                          style: TextStyle(
                                                              fontSize: 24,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600),
                                                        ),

                                                        //เว้นว่าง
                                                        const SizedBox(
                                                          height: 20,
                                                        ),

                                                        //เส้นสีดำ
                                                        Container(
                                                          width:
                                                              size.width * 0.8,
                                                          height: 2,
                                                          color: Colors.black45,
                                                        ),
                                                      ],
                                                    ),
                                                    content: Container(
                                                      //เนื้อหาใน popup
                                                      width: size.width,
                                                      //height: size.height*0.5,
                                                      padding:
                                                          const EdgeInsets.all(
                                                              10),
                                                      //color: Colors.yellow,
                                                      child: accessPoints
                                                              .isEmpty //ในกรณ๊ที่ผลการสแกนไวไฟมันว่าง
                                                          ? ListView.builder(
                                                              shrinkWrap: true,
                                                              itemCount: 1,
                                                              itemBuilder:
                                                                  (context,
                                                                          i) =>
                                                                      Container(
                                                                        width: size
                                                                            .width,
                                                                        height: size.height *
                                                                            0.1,
                                                                        alignment:
                                                                            Alignment.center,
                                                                        padding:
                                                                            const EdgeInsets.all(15),
                                                                        child:
                                                                            const Text(
                                                                          "NO SCANNED RESULTS",
                                                                          style:
                                                                              TextStyle(fontSize: 21),
                                                                        ),
                                                                      ))
                                                          : ListView.builder(
                                                              //นำ List ของไวไฟ ที่สแกนเจอมาแสดง
                                                              shrinkWrap: true,
                                                              itemCount:
                                                                  accessPoints
                                                                      .length,
                                                              itemBuilder:
                                                                  (context, i) {
                                                                //check thai ssid (wifi ที่เป็นชื่อว่าง)
                                                                if (chackSsid(accessPoints[i]
                                                                            .ssid
                                                                            .toString())
                                                                        .toString() ==
                                                                    'null') {
                                                                  return Container(); //ไม่ต้องแสดงอะไร
                                                                } else {
                                                                  //แสดงชื่อไวไฟ สามารถกดได้เพื่อเลือกไวไฟ
                                                                  return Container(
                                                                    width: size
                                                                        .width,
                                                                    height: size
                                                                            .height *
                                                                        0.05,
                                                                    alignment:
                                                                        Alignment
                                                                            .centerLeft,
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            15),
                                                                    child:
                                                                        TextButton(
                                                                      style: TextButton
                                                                          .styleFrom(
                                                                        alignment:
                                                                            Alignment.centerLeft,
                                                                        padding:
                                                                            EdgeInsets.zero,
                                                                      ),
                                                                      onPressed:
                                                                          () {
                                                                        setState(
                                                                            () {
                                                                          //ให้ ssid = ไวไฟที่เราเลือก
                                                                          ssid = accessPoints[i]
                                                                              .ssid
                                                                              .toString();
                                                                        });
                                                                        Navigator.of(context)
                                                                            .pop();
                                                                      },
                                                                      child:
                                                                          SizedBox(
                                                                        width: size
                                                                            .width,
                                                                        child:
                                                                            Text(
                                                                          accessPoints[i]
                                                                              .ssid
                                                                              .toString(),
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          style: const TextStyle(
                                                                              fontSize: 21,
                                                                              color: Color.fromARGB(255, 66, 82, 137)),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  );
                                                                }
                                                              }),
                                                    )));
                                      });
                                    });
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                          width: size.width * 0.6,
                                          height: size.height * 0.074,
                                          alignment: Alignment.centerLeft,
                                          padding:
                                              const EdgeInsets.only(left: 5),
                                          //color: Colors.yellow,
                                          child: Text(
                                            ssid ?? 'Select Your WIFI Name',
                                            style: const TextStyle(
                                                color: Colors.black38,
                                                fontSize: 16),
                                          )),
                                      const Spacer(),
                                      Container(
                                          width: size.width * 0.12,
                                          height: size.height * 0.074,
                                          alignment: Alignment.centerRight,
                                          margin:
                                              const EdgeInsets.only(right: 10),
                                          //color: Colors.blue,
                                          child: const Icon(
                                            Icons.arrow_forward_ios,
                                            size: 20,
                                            color: Colors.black38,
                                          ))
                                    ],
                                  ),
                                ),
                              ),
                            ),

                            //password textfield
                            Padding(
                              padding: const EdgeInsets.all(15),
                              child: Container(
                                width: size.width * 0.8,
                                height: size.height * 0.074,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: const Color.fromARGB(
                                            255, 117, 138, 214))),

                                //color: Colors.orange,
                                child: Row(
                                  children: [
                                    //textfield wifi
                                    Container(
                                      width: size.width * 0.6,
                                      height: size.height * 0.074,
                                      alignment: Alignment.centerLeft,
                                      //color: Colors.blue,
                                      padding: const EdgeInsets.only(left: 10),
                                      child: TextField(
                                        controller: passwordWifiController,
                                        obscureText: _isObscure,
                                        onChanged: (text) {
                                          setState(() {
                                            //for check controller
                                          });
                                        },
                                        enableSuggestions: false,
                                        autocorrect: false,
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          //labelText: 'WIFI Password',
                                          hintStyle: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500),
                                          hintText: 'Enter WIFI Password',
                                        ),
                                      ),
                                    ),
                                    const Spacer(),
                                    //see password
                                    Container(
                                      width: size.width * 0.12,
                                      height: size.height * 0.074,
                                      //color: Colors.orange,
                                      margin: const EdgeInsets.only(right: 10),
                                      alignment: Alignment.centerRight,
                                      child: IconButton(
                                          icon: Icon(_isObscure
                                              ? Icons.visibility_off
                                              : Icons.visibility),
                                          color: const Color.fromARGB(
                                              255, 199, 199, 199),
                                          onPressed: () {
                                            setState(() {
                                              _isObscure = !_isObscure;
                                            });
                                          }),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ]),
                        )),

                    //เว้นระยะห่าง
                    const Spacer(),

                    //bt
                    SizedBox(
                      width: size.width * 0.85,
                      height: size.height * 0.1,
                      //color: Colors.yellow,
                      child: Row(
                        children: [
                          //ปุ่มยกเลิก
                          Container(
                            width: size.width * 0.38,
                            height: size.height * 0.074,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: const Color.fromARGB(255, 189, 189, 189),
                            ),
                            child: TextButton(
                                style: ButtonStyle(
                                    shape: MaterialStateProperty.all<
                                            RoundedRectangleBorder>(
                                        RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ))),
                                child: const Text(
                                  'Cancel',
                                  style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w600,
                                      color: Color.fromARGB(255, 35, 35, 35)),
                                ),
                                onPressed: () {
                                  //cancel configure wifi
                                  //Navigator.of(context).pop();

                                  //reset token of device in localStorage (work in popup)
                                  //navigator replement to main page
                                  popup(
                                      'Do you want to cancel adding a device?',
                                      'back',
                                      'null');
                                }),
                          ),

                          //เว้นระยะห่าง
                          const Spacer(),

                          //ปุ่ม Connect มีการเช้คว่า ชื่อไวไฟ(ssid ) และ password wifi มันว่างไหม
                          if (ssid != null &&
                              passwordWifiController.text != '') ...{
                            //ไม่ว่าง กดได้
                            Container(
                              width: size.width * 0.38,
                              height: size.height * 0.074,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: const Color.fromARGB(255, 117, 138, 214),
                              ),
                              child: TextButton(
                                  style: ButtonStyle(
                                      shape: MaterialStateProperty.all<
                                              RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ))),
                                  child: const Text(
                                    'Connect',
                                    style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white),
                                  ),
                                  onPressed: () {
                                    //configure wifi
                                    //check ว่า passowrd wifi มันมีช่องว่างไหม
                                    //password ไม่ควรมีช่องว่าง
                                    if (checkPasswordSpace(
                                        passwordWifiController.text)) {
                                      //password have space
                                      popup('Invalid password format.', 'null',
                                          'null');
                                    } else {
                                      //ยินยันการ configure wifi
                                      popup(
                                          'Do you want to Configure device wifi with this ssid and password?',
                                          'move',
                                          passwordWifiController.text);
                                    }
                                  }),
                            )
                          } else ...{
                            //ว่าง  กดไม่ได้
                            Container(
                              width: size.width * 0.38,
                              height: size.height * 0.074,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: const Color.fromARGB(122, 117, 138, 214),
                              ),
                              child: TextButton(
                                  style: ButtonStyle(
                                      shape: MaterialStateProperty.all<
                                              RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ))),
                                  onPressed: null,
                                  child: const Text(
                                    'Connect',
                                    style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white),
                                  )),
                            )
                          }
                        ],
                      ),
                    )
                  ],
                ),
              ),
            } else if (page == "loading") ...{
              SizedBox(
                height: size.height * 0.8,
                width: size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    LoadingAnimationWidget.beat(
                      color: const Color.fromARGB(255, 117, 138, 214),
                      size: 100,
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: const Text('Connecting to the device...',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w600,
                          )),
                    )
                  ],
                ),
              )
            }
          ]),
        ),
      ),
    );
  }

  popupAlert(text, move, password) {
    //move meaning
    //back = come back to mainPage
    //move = move to next paeg
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          title: const Row(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Notification',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
            ],
          ),
          content: Text('   $text',
              style: const TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.w500,
                  color: Colors.black)),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                setState(() {
                  page = "sending";
                });
                Navigator.pop(context, 'cancel');
              },
              child: const Text('Ok',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                  )),
            ),
          ],
        ),
      ),
    );
  }

  popup(text, move, password) {
    //move meaning
    //back = come back to mainPage
    //move = move to next paeg
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          title: const Row(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Notification',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
            ],
          ),
          content: Text('   $text',
              style: const TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.w500,
                  color: Colors.black)),
          actions: <Widget>[
            if (text == 'Invalid password format.') ...{
              TextButton(
                onPressed: () {
                  Navigator.pop(context, 'cancel');
                },
                child: const Text('Ok',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w500,
                    )),
              ),
            } else ...{
              TextButton(
                onPressed: () {
                  Navigator.pop(context, 'cancel');
                },
                child: const Text('Cancel',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w500,
                    )),
              ),
              TextButton(
                onPressed: () => {
                  if (move == 'back')
                    {
                      //clear localStorage token
                      tokenClear(),
                      //go to main page
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const NavigationBottomBarWidget()))
                    }
                  else if (move == 'move')
                    {
                      //send ssid and password to node mcu
                      //send clientId,token,secert to node mcu
                      setState(() {
                        page = "loading";
                        configureWifi(
                            ssid, password); //cell token in this function
                      }),

                      Navigator.of(context).pop(),
                    }
                  else
                    {
                      setState(() {
                        page = "sending";
                      }),
                      Navigator.of(context).pop(),
                    }
                },
                child: const Text('Ok',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w500)),
              ),
            }
          ],
        ),
      ),
    );
  }
}
