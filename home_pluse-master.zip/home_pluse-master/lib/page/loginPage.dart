// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'dart:convert'; //libary สำหรับแปลง json ที่ได้มาจากเซิฟเวอร์เป็นภาษา dart
import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/reAuthEmailPage.dart';
import 'package:homeplus_phase1/page/registerPage.dart';
import 'package:homeplus_phase1/widget/navigationBottomBarWidget.dart';
import 'package:shared_preferences/shared_preferences.dart'; //libary สำหรับเรียกใช้ค่าใน local Storage
import 'package:http/http.dart' as http; //libary สำหรับการเรียกใช้ api
import 'package:homeplus_phase1/apiPath.dart' as globals;

import '../firebaseMessageProvider.dart';
import '../main.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  //url ของ api ที่ใช้ get urlBase
  String url = globals.apiPath;

  String? urlBase; //เป็น url api ที่ใช้ในทุกๆ หน้า

  //ตัวแปรสำหรับการรับค่าจาก Textfield
  TextEditingController usernameController =
      TextEditingController(); //ในตอนนี้เปลี่ยนเป็นรับ email แต่ไม่ได้เปลี่ยนชื่อตัวแปร
  TextEditingController passwordController = TextEditingController(); //password
  bool _isObscure = true; //ตัวแปรสำหรับดู password

  var userId; //for check login
  var cl; //ใช้สำหรับเช็ค login เหมือนกัน เก็บค่า userId
  var ub; //ใช้สำหรับรันฟังก์ชั่น geturlApi

  //API function----------------------------------------------------------------------------------------------
  //get api urlBase
  getUrlApi() async {
    print('[getUrlApi] Im in getUrlApi function');
    Uri myUri = Uri.parse('$url/version_smarthouseMobile');
    try {
      http.Response response = await http.post(
        myUri,
        headers: {
          "Content-Type":
              "application/x-www-form-urlencoded", //กำหนดชินดของ bodyที่เราจะส่งไปยังเซิฟเป็นชนิดไหน
        },
        encoding: Encoding.getByName(
            'utf-8'), //ไม่รู้เหมือนกันว่าคืออะไรแต่น่าจะเป็นการแปลงค่าที่เป็นภาษาไทยมั้ง
      );
      print('[getUrlApi] status Code : ${response.statusCode}');
      print('[getUrlApi] response body: ${response.body}');

      //หลังจากส่งค่าไปยังเซิฟแล้วถ้าสำเร็จจะได้รับ respons กลับมาเก็บไว้ในตัวแปร response
      //เรา decode response ที่รับกลับมาให่เป็นภาษา dart เพื่อที่เราจะสามารถใช้งานค่าเหล่านั้นได้
      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)

      //เช็คว่า api เป็น apiที่ใช้งานจริงหรือสำหรับการทดสอบ
      if (url.contains("api")) {
        //for real api working
        print('[getUrlApi] real api');
        urlBase = "${jsonResponse['data']['link']}";
      } else {
        //for local api
        urlBase = jsonResponse['data']['link'].toString();
        print('[getUrlApi] local api');
      }

      //บันทึก urlBase ลง localStorage เพราะต้องใช้ทุกหน้า
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString(
          //ทำการบันทึก url ลง localStorage
          'urlBase',
          urlBase.toString()); //set url to localstorage

      return jsonResponse['data']['link'].toString();
    } catch (e) {
      print('[getUrlApi] error: $e');
      return 'null';
    }
  }

  //Login
  loginApi(String username, String password) async {
    print('[loginApi] Im in loginApi function');
    print('[loginApi] urlBase: $urlBase');
    Uri myUri = Uri.parse('$urlBase/ValUser'); //กำหนด url ของ api
    try {
      //ใส่ try catch ป้องกันการ error ตอนเซิฟเน่าหรือเน็ตเราไม่ดี
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type":
                "application/x-www-form-urlencoded", //กำหนดชินดของ bodyที่เราจะส่งไปยังเซิฟเป็นชนิดไหน
          },
          encoding: Encoding.getByName(
              'utf-8'), //ไม่รู้เหมือนกันว่าคืออะไรแต่น่าจะเป็นการแปลงค่าที่เป็นภาษาไทยมั้ง
          body: {
            //body ที่เราต้องส่งไปยังเซิฟเวอร์ ค่าพวกนี้จะอิงตาม api
            "email": username,
            "userPassword": password,
          });
      print('[loginApi] status Code : ${response.statusCode}');
      print('[loginApi] response body: ${response.body}');

      //Navigator.pop(context, 'Cancel'); //close loading popup

      //หลังจากส่งค่าไปยังเซิฟแล้วถ้าสำเร็จจะได้รับ respons กลับมาเก็บไว้ในตัวแปร response
      //เรา decode response ที่รับกลับมาให่เป็นภาษา dart เพื่อที่เราจะสามารถใช้งานค่าเหล่านั้นได้
      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)
      if (jsonResponse['message'] == 'match user') {
        //เช้คว่าค่าที่รับมาในส่วนของ message มีค่าตามนี้รึป่าว
        //login finish now
        //ทำการบันทึก userId และ userName ลง localStorage
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString(
            //ทำการบันทึก userId ลง localStorage
            'userId',
            jsonResponse['data']['userid']
                .toString()); //set userId to localstorage
        prefs.setString(
            //ทำการบันทึก username ลง localStorage
            'userName',
            jsonResponse['data']
                ['userName']); //set username for show on profile page

        //หลังจากนั้นเรียกใช้ checHouseListApi เพื่อเช็คว่าบัญชีนี้ได้มีการสร้างบ้านไว้แล้วหรือยัง
        //เพราะการสร้างบัญชีครั้งแรก เราจะต้องสร้างบ้านให้ user 1 หลังโดยอัตโนมัติ
        checHouseListApi(jsonResponse['data']['userid'].toString(),
            jsonResponse['data']['userName']);

        //หลังจากเรียกใช้ checHouseListApi โปรแกรมจะมารันตรงนี้ต่อ จะแสดง popup ขึ้นมา
        //popup('Loading...', 'login');
      } else if (jsonResponse['message'] == 'please confirm email.') {
        //กรณียังไม่ได้ยืนยันอีเมล
        popup('Please confirm email.', 'close');
      } else if (jsonResponse['message'] == 'wrong email') {
        //กรณีอีเมลผิด
        popup('Email is incorrect!\nPlease try again.', 'close'); //wrong email,
      } else if (jsonResponse['message'] == 'wrong password') {
        //กรณีรหัสผ่านผิด
        popup('Password is incorrect!\nPlease try again.',
            'close'); //wrong  password,
      } else if (jsonResponse['message'] == 'provide not found' ||
          jsonResponse['message'] ==
              'dont found any user for email= $username') {
        ////กรณี not found account
        popup("Username or password is incorrect!\nPlease try again.",
            'close'); //wrong  password,
      } else {
        //กรณีที่ไม่ตรงกับเงื่อนไขใดๆ
        popup('Something is wrong!\nPlease try again.',
            'close'); //wrong code or can't connect to server.
      }
    } catch (e) {
      //กรณีเซิฟเน่าหรือเน็ตไม่ดี
      //login failed
      if (e.toString() == "Connection timed out") {
        //Navigator.pop(context, 'Cancel'); //close loading popup
        popup('Connection time out!\nPlease check your internet.',
            'reset'); //wrong code or can't connect to server.
      } else {
        print('[loginApi] error: $e');
        popup('Connection failed!\nPlease check your internet.',
            'reset'); //wrong code or can't connect to server.
      }
    }
  }

  //!ฟังก์ชั่นสำหรับเช็คว่าเรามีบ้านในบัญชีหรือไม่ ถ้าไม่มีบ้านในบัญชีจะทำการสร้างใหม่ให้
  checHouseListApi(userId, userName) async {
    print('[chkecHouseListApi] Im getHouseListApi function');
    //print('[getHouseListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/house'); //กำหนด url ของ api
    try {
      //ใส่ try catch ป้องกันการ error ตอนเซิฟเน่าหรือเน็ตเราไม่ดี
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type":
                "application/x-www-form-urlencoded", //กำหนดชินดของ bodyที่เราจะส่งไปยังเซิฟเป็นชนิดไหน
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            //body ที่เราต้องส่งไปยังเซิฟเวอร์ ค่าพวกนี้จะอิงตาม api
            "userid": userId,
          });

      print('[chkecHouseListApi] response body: ${response.body}');

      //หลังจากส่งค่าไปยังเซิฟแล้วถ้าสำเร็จจะได้รับ respons กลับมาเก็บไว้ในตัวแปร response
      //เรา decode response ที่รับกลับมาให่เป็นภาษา dart เพื่อที่เราจะสามารถใช้งานค่าเหล่านั้นได้
      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)
      print('[chkecHouseListApi] data: ${jsonResponse['data'].length}');

      //เช็คความยาวของ list data: data จะเป็น list ของบ้านที่มีทั้งหมด
      if (jsonResponse['data'].length == 0) {
        //ถ้าความยาวของ data = 0 จะเรียกใช้ ฟังก์ชั่นสำหรับสร้างบ้านหลังแรก
        buildFirstHouse(userId, userName);
      } else {
        //ถ้าความยาวของ data ไม่เท่ากับ 0 ก็จะขึ้น popup แจ้งเตือนว่า login เสร็จเรียบร้อย
        // ก่อนน login ต้องส่ง token สำหรับ notification ไปเก็บไว้ใน db ก่อน
        setToken();
      }
      print('[chkecHouseListApi] finsih!');
    } catch (e) {
      //อาจจะต้องมี popup ถ้าเกิดการ error (ยังไม่ได้ทำ)
      print('[chkecHouseListApi] error: $e');
      clearCookies();
      popup('Login failed.', 'close'); //login complete
    }
  }

  //set token for notification
  setToken() async {
    print('[setToken] Im setToken function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('tokenPhone');
    var userId = prefs.getString('userId');
    print('[setToken] token: $token');
    print('[setToken] userId: $userId');
    Uri myUri = Uri.parse('$urlBase/setToken');
    try {
      http.Response response = await http.put(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": userId.toString(), "token": token.toString(), "setStatus": "login"});

      print('[setToken] status Code : ${response.statusCode}');
      print('[setToken] response body : ${response.body}');

      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['message'].toString() == 'set token already!') {
        //show pop-up แสดงว่า login finish
        popup('Login complete.', 'move'); //login complete
        print('[setToken] login complete!');
        print('[setToken] finsih!');
      } else {
        //show pop-up
        print('[setToken] cant set token!');
        clearCookies();
        popup("Login failed, Can't set token.", 'close'); //login complete
      }
    } catch (e) {
      print('[setToken] error: $e');
      clearCookies();
      popup("Login failed, Can't set token.", 'close'); //login complete
    }
  }

  //ฟังก์ชั่นสำหรับการสร้างบ้านหลังแรกในบัญชี(จะมีการเรียกใช้ฟังก์ชั่นนี้ได้แค่กรณีที่ login ครั้งแรก)
  buildFirstHouse(uid, uname) async {
    print('[buildFirstHouse] Im in buildFirstHouse');
    Uri myUri = Uri.parse('$urlBase/addHouse'); //กำหนด url ของ api

    try {
      //ใส่ try catch ป้องกันการ error ตอนเซิฟเน่าหรือเน็ตเราไม่ดี
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type":
                "application/x-www-form-urlencoded", //กำหนดชินดของ bodyที่เราจะส่งไปยังเซิฟเป็นชนิดไหน
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "userid": uid,
            "houseName": "$uname's house"
          }); //body ที่เราต้องส่งไปยังเซิฟเวอร์ ค่าพวกนี้จะอิงตาม api

      print('[buildFirstHouse] status Code : ${response.statusCode}');
      print('[buildFirstHouse] res body: ${response.body}');

      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'].toString() == 'false') {
        setToken();
      } else {
        //show pop-up
        clearCookies();
        popup('Login failed.', 'close'); //login complete
      }

      print('[buildFirstHouse] finsih!');
    } catch (e) {
      //+อาจจะต้องมี popup ถ้าเกิดการ error (ยังไม่ได้ทำ)
      print('[buildFirstHouse] error: $e');
      clearCookies();
      popup('Login failed.', 'close'); //login complete
    }
  }

  //----------------------------------------------------------------------------------------------------------

  //localStorage function
  //check login
  checkLogin() async {
    print('[checkLogin] Im in  checkLogin function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userId =
        prefs.getString('userId'); //get ค่าของ userId ที่มีอยู่ใน local storage
    print('[checkLogin] userId: $userId');
    return userId; //return userId ออกไป
    //prefs.setString('accessToken', token);
  }

  //!ในกรณีที่ login ล้มเหลว ต้องลบ cookies ที่เคยบันทึกไปก่อนหน้านี้ก่อน
  clearCookies() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('userId'); //ลบค่าของ userId ที่มีใน local Storage
    prefs.remove('userName'); //ลบค่าของ userId ที่มีใน local Storage
  }

  //!!!ในกรณีนี้มีการเรียกใช้ textfield ใน futureBuilder ซึ่งมันจะมีปัญหาเกิดขึ้นคือ ไม่สามารถพิมได้มันจะรีหน้าแอปทุกครั้งที่เราพิมพ์
  //ดังนั้นจึงมีการเรียกใช้ function รับค่า userId ที่ initState()

  @override
  void initState() {
    //initState เป็นฟังก์ชั่นที่จะเริ่มต้นการทกำงานเมื่อมีการเปิดหน้าในไฟล์นี้ขั้นมา ไม่เกี่ยวกับการรีบิ้ว (รีบิ่วคือการรีหน้าแอปใหม่=setState)
    super.initState();
    //local notification
    NotificationListenerProvider()
        .getMessage(NavigationService.navigatorKey.currentContext);
    print('[LoginPage] start init State');

    ub = getUrlApi();
    //ให้ cl เท่ากับฟังก์ชั่น checkLogin เพื่อรับค่าที่ return ออกมา
    cl =
        checkLogin(); //this declare make we can use var function in FutureBuilder
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    print('in login page');
    return WillPopScope(
      onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
      child: Scaffold(
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          //get url base from api
          body: FutureBuilder(
              future: ub,
              builder: (BuildContext context, AsyncSnapshot<dynamic> s) {
                //มือถือมีเน็ต จะได้ urlbase จาก api แต่ถ้าไม่มีเน็ตจะได้ null แทน แต่ใน
                //futureBuilder จะถือว่าทำการ connectionState เรียบร้อยแล้ว
                if (s.connectionState == ConnectionState.done) {
                  print('urlBase: $urlBase');
                  //check login form cookies
                  return FutureBuilder(
                    future:
                        cl, //มีการเข้าถึงตัวแปร cl ที่ทำหน้าที่รับค่ามาจาก ฟังก์ชั่น checkLogin ก่อนที่จะสร้างหน้าแอป
                    builder: (BuildContext context,
                        AsyncSnapshot<dynamic> snapshot) {
                      //ค่า cl จะถูกเก็บไว้ใน snapshot
                      //เช้คว่า snapshot รับค่ามาจากฟังก์ชั่นแล้วหรือยัง
                      if (snapshot.connectionState == ConnectionState.done) {
                        //เช็คว่า userId เป็นค่าว่างหรือไม่ (userId ถูกกำหนดค่าในฟังก์ชั่น checkLogin)
                        if (userId == null) {
                          //ในกรณีที่เป็น null = ยังไม่ได้ login เพราะถ้า login ไปแล้ว userId จะถูกเก็บไว้ใน localStorage
                          //ซึ่งทุกครั้งที่เปิดหน้า login จะมีการเช็ค userId จาก localStorage ตลอด
                          return SingleChildScrollView(
                            //SingleChildScrollView ช่วยให้ไม่เกิด overflow เมื่อกดพิมพ์แล้วโชว์คีย์บอร์ด
                            child: Container(
                              width: size.width,
                              height: size.height,
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  top: 20, bottom: 40, right: 10, left: 10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  //เว้นว่าง
                                  SizedBox(
                                    height: size.height * 0.2,
                                  ),

                                  //Text "WELCOME TO iSmart Living Plus"
                                  Container(
                                    width: size.width,
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.only(left: 40),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          'WELCOME TO ',
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 120, 141, 219),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 48,
                                          ),
                                        ),
                                        Text(
                                          'iSmart Living Plus',
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 73, 82, 113),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 42,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  //เว้นว่าง
                                  SizedBox(height: 30),

                                  //username textfield
                                  Container(
                                    width: size.width,
                                    height: size.height * 0.07,
                                    //color: Colors.orange,
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.only(
                                        left: 40, right: 40, top: 10),
                                    child: TextField(
                                      controller: usernameController,
                                      //obscureText: true,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10.0),
                                        ),
                                        prefixIcon: const Icon(
                                          Icons.person,
                                          color: Colors.black,
                                        ),
                                        //labelText: 'รหัสยืนยัน',
                                        contentPadding:
                                            const EdgeInsets.only(left: 20),
                                        hintText: 'Email',
                                        hintStyle: const TextStyle(
                                            fontSize: 21,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.black26),
                                      ),
                                    ),
                                  ),

                                  //เว้นว่าง
                                  SizedBox(height: 5),

                                  //password textield
                                  Container(
                                    width: size.width,
                                    height: size.height * 0.07,
                                    //color: Colors.orange,
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.only(
                                        left: 40, right: 40, top: 10),
                                    child: TextField(
                                      controller: passwordController,
                                      obscureText: _isObscure,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10.0),
                                        ),
                                        prefixIcon: const Icon(
                                          Icons.lock,
                                          color: Colors.black,
                                        ),
                                        suffixIcon: IconButton(
                                            //มีไอคอนด้านหลัง สามารถกดได้เพื่อดู password
                                            icon: Icon(
                                                _isObscure //ตรงนี้ ถ้า _isObscure เป็นจริงจะแสดงไอคอน visibility_off ถ้าไม่ก็จะแสดงไอคอน visibility(ไม่แน่ใจอาจจะสลับกัน)
                                                    ? Icons.visibility_off
                                                    : Icons.visibility),
                                            onPressed: () {
                                              setState(() {
                                                _isObscure =
                                                    !_isObscure; //โดยจะมีการ setState ค่า _isObscure ใหม่ทุกครั้งที่กด
                                              });
                                            }),
                                        //labelText: 'รหัสยืนยัน',
                                        contentPadding:
                                            const EdgeInsets.only(left: 20),
                                        hintText: 'Password',
                                        hintStyle: const TextStyle(
                                            fontSize: 21,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.black26),
                                      ),
                                    ),
                                  ),

                                  //forget password and resend email
                                  Container(
                                    width: size.width,
                                    //color: Colors.red,
                                    padding: const EdgeInsets.only(
                                        left: 40, right: 40),
                                    //alignment: Alignment.centerRight,
                                    child: Row(
                                      children: [
                                        //ลืมรหัสผ่านยังไม่ทำ api เลยปิดไว้ก่อน แต่อาจจะได้ใช้ในอนาคต
                                        //ปุ่มสำหรับไปยังหน้า ลืมรหัสผ่าน
                                        // TextButton(
                                        //   onPressed: () {
                                        //     print('go to forget password page');
                                        //     Navigator.pushReplacement(
                                        //         context,
                                        //         MaterialPageRoute(
                                        //             builder: (context) =>
                                        //                 const ForgetPasswordPage()));
                                        //   },
                                        //   child: Text(
                                        //     'Forgot password',
                                        //     style: TextStyle(
                                        //       color: Color.fromARGB(255, 117, 138, 214),
                                        //       fontWeight: FontWeight.bold,
                                        //     ),
                                        //   ),
                                        // ),

                                        const Spacer(), //เว้นระยะห่าง

                                        //ปุ่มสำหรับไปยังหน้า Re email
                                        TextButton(
                                          onPressed: () {
                                            print('go to re send email page');
                                            Navigator.pushReplacement(
                                                //เปลี่ยนไปหน้า ReAuthEmailPage แบบ Navigator.pushReplacement (ไม่สามารถ Navigator.pop หรือกดปุ่มย้อนกลับของมือถือได้)
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        const ReAuthEmailPage()));
                                          },
                                          child: Text(
                                            'Resend confirm email',
                                            style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 117, 138, 214),
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  //เว้นว่าง
                                  SizedBox(height: 5),

                                  // Login button
                                  SizedBox(
                                    width: size.width * 0.3,
                                    height: size.height * 0.06,
                                    child: TextButton(
                                      style: TextButton.styleFrom(
                                        backgroundColor: const Color.fromARGB(
                                            255, 117, 138, 214),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        foregroundColor: Colors.white,
                                        padding: EdgeInsets.zero,
                                        textStyle:
                                            const TextStyle(fontSize: 20),
                                      ),
                                      onPressed: () {
                                        //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม

                                        //  sendNotification(
                                        //     title: 'test1',
                                        //     body: 'testinhq noti');

                                        print(
                                            'username: ${usernameController.text}, password: ${passwordController.text}');
                                        //ทำการเช็คว่าช่อง textfield ของ username กับ password ว่างอยู่ไหม?
                                        if (usernameController.text != '' &&
                                            passwordController.text != '') {
                                          popup('Loading...',
                                              'login'); //loading popup
                                          //ถ้าไม่่วางจะเรียกใช้ฟังก์ชั่น loginApi
                                          loginApi(usernameController.text,
                                              passwordController.text);
                                        } else {
                                          //ถ้าว่าง จะขึ้น popup แจ้งเตือนให้กรอกข้อมูลให้ครบ
                                          popup(
                                              'Please complete the information.',
                                              'null');
                                        }
                                        // Navigator.pushReplacement(
                                        //     context,
                                        //     MaterialPageRoute(
                                        //         builder: (context) =>
                                        //             const NavigationBottomBarWidget()));
                                      },
                                      child: Text(
                                        'Login',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'FCfont',
                                          fontSize: 24,
                                        ),
                                      ),
                                    ),
                                  ),

                                  //เว้นว่าง
                                  SizedBox(height: 20),

                                  //เว้นระยะห่าง
                                  Spacer(),

                                  //ยังไม่มีบัญชี? ลงทะเบียน
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        "Don't have an account? ",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      SizedBox(
                                        //width: 63, //old 50
                                        child: TextButton(
                                          style: TextButton.styleFrom(
                                              padding: EdgeInsets.zero,
                                              tapTargetSize:
                                                  MaterialTapTargetSize
                                                      .shrinkWrap,
                                              alignment: Alignment.centerLeft),
                                          onPressed: () {
                                            print('go to register page');
                                            Navigator.pushReplacement(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        const RegisterPage()));
                                          },
                                          child: Text(
                                            'Register here',
                                            style: TextStyle(
                                              decoration:
                                                  TextDecoration.underline,
                                              color: Color.fromARGB(
                                                  255, 117, 138, 214),
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        } else {
                          //ในกรณีที่ userId ไม่เท่ากับว่างจะทำการเรียกหน้า mainPage มาแสดงในไฟล์นี้
                          //เหมือนจะเป็นการ Navigator(เปลี่ยนหน้า) แต่ไม่ใช่ หน้า mainPage จะมาอยู่ใน  Widget build ของไฟล์นี้
                          //Login complete
                          return Navigator(
                            //key: navigatorKey,
                            //initialRoute: NestedScreenRoutes.root,
                            onGenerateRoute: (routeSettings) {
                              return MaterialPageRoute(
                                  builder: (context) =>
                                      NavigationBottomBarWidget());
                            },
                          );
                        }
                      } else {
                        //ในขณะที่ futurebuilder กำลังทำงานเพื่อ return ค่ามายัง snapshot ตัวแอปจะเข้ามาทำงานในส่วนนี้ก่อน
                        return Container(); //โปรแกรมจะไม่มีทางเข้ามาทำงานในส่วนนี้เพราะว่า cl จะไปเอาค่าจาก local storage มาใช้ได้ตลอด ไม่เหมือนกับการเรียก api
                      }
                    },
                  );
                } else {
                  //กรณีนี้อาจจะไม่เกิดขึ้น
                  //(OK)TODOLIST: show error message or version update message.(show connectFailed)
                  return connectFailed();
                }
              })),
    );
  }

  //แสดงตอนเชื่อมต่อล้มเหลว snapshot = null
  connectFailed() {
    //Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text(
            'Loading...',
            style: TextStyle(fontSize: 24),
            textAlign: TextAlign.center,
          ),
          // const SizedBox(
          //   height: 10,
          // ),
          // SizedBox(
          //   width: size.width * 0.3,
          //   height: size.height * 0.06,
          //   child: TextButton(
          //     style: TextButton.styleFrom(
          //       backgroundColor: const Color.fromARGB(255, 117, 138, 214),
          //       shape: RoundedRectangleBorder(
          //         borderRadius: BorderRadius.circular(10),
          //       ),
          //       foregroundColor: Colors.white,
          //       padding: EdgeInsets.zero,
          //       textStyle: const TextStyle(fontSize: 20),
          //     ),
          //     onPressed: () {
          //       setState(() {}); //กดปุ่มแล้วจะรีบิ้วใหม่
          //     },
          //     child: const Text(
          //       'Try again',
          //       style: TextStyle(
          //         color: Colors.white,
          //         fontWeight: FontWeight.bold,
          //         fontFamily: 'FCfont',
          //         fontSize: 24,
          //       ),
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }

  popup(text, move) {
    //กรณีที่ move = login จะแสดง popup อีกแบบซึ่งจะไม่มี ปุ่มกด(actions)
    if (move == 'login') {
      return showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => WillPopScope(
          onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
          child: AlertDialog(
            //title: const Text('Something is worng!'),
            contentPadding: const EdgeInsets.all(20),
            content: Container(
              //width: size.width,
              height: 80,
              alignment: Alignment.center,
              child: Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
            ),
          ),
        ),
      );
    } else {
      //move เท่ากับค่าอื่นจะแสดง popup ในส่วนนี้
      //การทำงานเหมือนกับ popup ในหน้าอื่นๆ
      return showDialog<String>(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => WillPopScope(
          onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
          child: AlertDialog(
            //title: const Text('Something is worng!'),
            contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
            content: Container(
              //width: size.width,
              height: 80,
              alignment: Alignment.center,
              child: Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
            ),
            actions: <Widget>[
              Container(
                //width: size.width,
                alignment: Alignment.center,
                child: TextButton(
                  onPressed: () {
                    //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                    //move = move เปลี่ยนหน้า
                    if (move == 'move') {
                      //move to other page : main page
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const NavigationBottomBarWidget()));
                    } else if (move == "reset") {
                      //not change but re-get url base.
                      Navigator.pop(context, 'Cancel'); //close noti popup
                      Navigator.pop(context, 'Cancel'); //close loading popup
                      setState(() {
                        ub = getUrlApi();
                      });
                    } else if (move == "close") {
                      //move != move ไม่เปลี่ยนหน้า
                      Navigator.pop(context, 'Cancel'); //close noti popup
                      Navigator.pop(context, 'Cancel'); //close loading popup
                    } else {
                      Navigator.pop(context, 'Cancel');
                    }
                  },
                  child: const Text(
                    'Ok',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 117, 138, 214)),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
  }
}
