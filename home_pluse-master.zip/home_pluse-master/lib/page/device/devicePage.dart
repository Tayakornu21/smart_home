import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:homeplus_phase1/cookiesValue.dart';
import 'package:homeplus_phase1/modelData/getDeviceControlModel.dart';
import 'package:homeplus_phase1/page/device/deviceDetailPage.dart';
import 'package:homeplus_phase1/page/device/socketEditNamePage.dart';
import 'package:homeplus_phase1/widget/navigationBottomBarWidget.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class DevicePage extends StatefulWidget {
  const DevicePage({super.key});

  @override
  State<DevicePage> createState() => _DevicePageState();
}

class _DevicePageState extends State<DevicePage> {
  late IO.Socket socket;
  String? socketName1;
  String? socketName2;
  String? socketName3;
  String? socketName4;
  bool status1 = false; //scoket 1
  bool status2 = false; //socket 2
  bool status3 = false; //socket 3
  bool status4 = false; //socket 4
  var deviceStatus;
  var countTimeStatus;
  var sw; //ใช้เช้คว่าอุปกรณ์ออนไลน์ไหม ถ้าออนไลน์จะสามารถ กดสวิตซ์ได้
  var serialNumberGloble;

  //api function ---------------------------------------------------------------
  //deviceControl api get data of device
  GetDeviceControlModel? deviceControl;
  Future<GetDeviceControlModel?> getDeviceControlApi() async {
    print('[getDeviceControlApi] Start getDeviceControlApi function');
    String tempSn = await getSerialNumber();
    String uid = await getUserId();
    //print('[getDeviceControlApi] uid: $uid');
    serialNumberGloble = tempSn;
    String urlBase = await getUrlBase();

    //print('[getHouseListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/deviceControl');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": uid, "serialNumber": tempSn});

      print('[getDeviceControlApi] status Code : ${response.statusCode}');
      print('[getDeviceControlApi] response body : ${response.body}');
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'] == false) {
        getSoketListApi(); //รับชื่อของพวก socket
        // print(response.body);
        // print(
        //     '[getDeviceControlApi] ClientID : ${jsonResponse['data']['clientID'].toString()}');
        // print(
        //     '[getDeviceControlApi] token : ${jsonResponse['data']['token'].toString()}');

        setCookie('clientIdSelectedDevice',
            jsonResponse['data']['clientID'].toString());

        clientID = jsonResponse['data']['clientID'].toString();
        token = jsonResponse['data']['token'].toString();

        //รับค่า Status ของอุปกรณ์ จาก netpie
        deviceStatus = await getStatusDevice(
            jsonResponse['data']['clientID'].toString(),
            jsonResponse['data']['token'].toString());

        print("deviceStatus: $deviceStatus");

        //รับค่า Status ของsocket จาก netpie
        //true คือ เอาค่าของ socket ใน netpie เก็บไว้ในตัวแปร status เรียบร้อยแล้ว
        var checkStatusSocket = false;

        if (deviceStatus == "Online") {
          checkStatusSocket = await getStatusSocket(
              jsonResponse['data']['clientID'].toString(),
              jsonResponse['data']['token'].toString());
        }

        //connect with socket io
        print('[getDeviceControlApi] Connect to socket io');
        print('[getDeviceControlApi] urlBase : $urlBase');
        print('[getDeviceControlApi] tempSn : $tempSn');

        var numPersonInHouse = await getAllPersonInHouse();
        print('[getDeviceControlApi]  numPersonInHouse : $numPersonInHouse');

        socket = IO.io(
            urlBase,
            //"http://10.58.41.29",
            IO.OptionBuilder()
                .setTransports(['websocket']) // for Flutter or Dart VM
                .setPath('/api/smartHouse/')
                .disableAutoConnect() // disable auto-connection
                //.setExtraHeaders({'Host':'smtp.office365.com','Upgrade': urlBase})
                .build()); // send serial number

        if (numPersonInHouse > 1) {
          //&& deviceStatus == 'Online'
          socket.connect();
          print('socket connect status: ${socket.connected}');
        }

        //check ว่า getStatusSocket ทำงานเสร็ตแล้วหรือยัง
        //เมื่อทำงานเสร็จเรียบร้อยแล้วจึงจะให้  ค่าของ deviceControl ที่จะต้องนำไปแสดงในหน้า ui เท่ากับค่าที่รับมาจาก api
        if (checkStatusSocket == true || deviceStatus == "Offline") {
          deviceControl = getDeviceControlModelFromJson(response.body);
        }

        _conncetSocket();
      }
      print('[getDeviceControlApi] finsih!');
      return deviceControl;
    } catch (e) {
      print('[getDeviceControlApi] error: $e');
      return null;
    }
  }

  getAllPersonInHouse() async {
    print('[getAllPersonInHouse] Im getAllPersonInHouse function');
    String temp = await getHouseId();
    String urlBase = await getUrlBase();
    //print('[getAllPersonInHouse] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/allPersonInHouse');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"houseid": temp});

      print('[getAllPersonInHouse] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        print(response.body);
        var jsonResponse = jsonDecode(response.body);
        print('[getAllPersonInHouse] finsih!');
        return jsonResponse['data'].length;
        //edit already
      } else {
        return false;
      }
    } catch (e) {
      print('[getAllPersonInHouse] error: $e');
      return false;
      //cant edit
      //maybe show popup
    }
    //return null;
  }

  //get Socket lsit
  getSoketListApi() async {
    print('[getSoketListApi] Im getSoketListApi function');
    String tempSn = await getSerialNumber();
    String urlBase = await getUrlBase();
    //print('[getHouseListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/subDevice');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "serialNumber": tempSn,
          });

      print('[getSoketListApi] status Code : ${response.statusCode}');
      print('[getSoketListApi] response body : ${response.body}');
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'] == false) {
        // print(response.body);
        // print(
        //     '[getSoketListApi] socket name 1 : ${jsonResponse['data'][0]['name'].toString()}');
        // print(
        //     '[getSoketListApi] socket name 2 : ${jsonResponse['data'][1]['name'].toString()}');
        // print(
        //     '[getSoketListApi] socket name 3 : ${jsonResponse['data'][2]['name'].toString()}');
        // print(
        //     '[getSoketListApi] socket name 4 : ${jsonResponse['data'][3]['name'].toString()}');

        //socket 1
        if (jsonResponse['data'][0]['name'].toString() == '') {
          socketName1 = 'Socket1';
        } else {
          socketName1 = jsonResponse['data'][0]['name'].toString();
        }

        //socket 2
        if (jsonResponse['data'][1]['name'].toString() == '') {
          socketName2 = 'Socket2';
        } else {
          socketName2 = jsonResponse['data'][1]['name'].toString();
        }

        //socket 3
        if (jsonResponse['data'][2]['name'].toString() == '') {
          socketName3 = 'Socket3';
        } else {
          socketName3 = jsonResponse['data'][2]['name'].toString();
        }

        //socket 4
        if (jsonResponse['data'][3]['name'].toString() == '') {
          socketName4 = 'Socket4';
        } else {
          socketName4 = jsonResponse['data'][3]['name'].toString();
        }
      } else {
        socketName1 = '-';
        socketName2 = '-';
        socketName3 = '-';
        socketName4 = '-';
      }
      print('[getSoketListApi] finsih!');
    } catch (e) {
      print('[getSoketListApi] error: $e');
      socketName1 = '-';
      socketName2 = '-';
      socketName3 = '-';
      socketName4 = '-';
    }
  }

  //get Status of device(Netpie api)
  getStatusDevice(cn, tk) async {
    //cn = clientId ,tk = token
    print('[getStatusDevice] Im in  getStatusDevice');

    String basicAuth = 'Device $cn:$tk';
    Uri myUri = Uri.parse('https://api.netpie.io/v2/device/status');
    try {
      http.Response r = await http
          .get(myUri, headers: <String, String>{'authorization': basicAuth});
      print('[getStatusDevice]  status code : ${r.statusCode}');
      print('[getStatusDevice] response body : ${r.body}');

      var jsonResponse = jsonDecode(r.body);
      if (jsonResponse['status'] == 0) {
        sw = true;
        return 'Offline';
      } else if (jsonResponse['status'] == 1) {
        sw = false;
        return 'Online';
      } else {
        sw = true;
        return '-';
      }
    } catch (e) {
      print('[getStatusDevice] error : $e');
      return '-';
    }
  }

  //get Status of each socket(Netpie api)
  getStatusSocket(cn, tk) async {
    //cn = clientId ,tk = token
    print('[getStatusSocket] Im in  getStatusSocket');

    String basicAuth = 'Device $cn:$tk';
    Uri myUri = Uri.parse('https://api.netpie.io/v2/device/shadow/data');
    try {
      http.Response r = await http
          .get(myUri, headers: <String, String>{'authorization': basicAuth});
      print('[getStatusSocket]  status code : ${r.statusCode}');
      print('[getStatusSocket] response body : ${r.body}');

      var jsonResponse = jsonDecode(r.body);

      //socket 1
      if (jsonResponse['data']['Relay1'] == 1) {
        status1 = true;
      } else {
        status1 = false;
      }
      //socket 2
      if (jsonResponse['data']['Relay2'] == 1) {
        status2 = true;
      } else {
        status2 = false;
      }

      //socket 3
      if (jsonResponse['data']['Relay3'] == 1) {
        status3 = true;
      } else {
        status3 = false;
      }

      //socket 4
      if (jsonResponse['data']['Relay4'] == 1) {
        status4 = true;
      } else {
        status4 = false;
      }

      //count time status
      if (jsonResponse['data']['CountTimeStatus'] != null) {
        countTimeStatus = jsonResponse['data']['CountTimeStatus'].toString();
      } else {
        countTimeStatus = "null";
      }

      return true;
    } catch (e) {
      print('[getStatusSocket] error : $e');
      return false;
    }
  }

//get temp of device (Netpie api)
  //use for get temp form netpie
  var clientID;
  var token;
  var tempFromNetpie;
  Future<String> getTempDevice() async {
    //cn = clientId ,tk = token
    print('[getDeviceTemp] Im in  getStatusSocket');
    print('[getDeviceTemp] clientID: $clientID');
    print('[getDeviceTemp] token: $token');

    String basicAuth = 'Device $clientID:$token';
    Uri myUri = Uri.parse('https://api.netpie.io/v2/device/shadow/data');
    try {
      http.Response r = await http
          .get(myUri, headers: <String, String>{'authorization': basicAuth});
      print('[getDeviceTemp]  status code : ${r.statusCode}');
      print('[getDeviceTemp] response body : ${r.body}');

      var jsonResponse = jsonDecode(r.body);

      //socket 1
      if (jsonResponse['data']['Temperature'].toString() != "nan") {
        return jsonResponse['data']['Temperature'].toString();
      } else {
        return "-";
      }
    } catch (e) {
      print('[getDeviceTemp] error : $e');
      return "err";
    }
  }

  Future<bool> sendDataToNetpie(
      String countTimeStatus, String myDuration) async {
    // String cn = await getCookie('clientIDAuto');
    // String tk = await getCookie('tokenAuto');

    int duraInt = 1000 * int.parse(myDuration);
    myDuration = duraInt.toString();

    String basicAuth = 'Device $clientID:$token';
    print(basicAuth);

    //change date time format
    // var time = DateFormat('yyyy-MM-dd HH:mm:ss').parse(timeClose.toString());
    // print('time:${time.toString()}');

    //remove .000 in time
    // String result = time.toString().substring(0, time.toString().indexOf('.'));
    // print(result);

    //change - to :
    // String newTime = result.replaceAll("-", ":");
    // print("newTime: $newTime");

    //time that send to netpiehave to be yyyy:MM:dd HH:mm:ss form.

    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=CountTime');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth},
        //add countTimestatus
        //o = Open
        //c= Close
        //i = idle
        body: countTimeStatus == "Open"
            ? "o$myDuration"
            : countTimeStatus == "Close"
                ? "c$myDuration"
                : "i$myDuration");

    print(r.statusCode);
    print(r.body);

    if (r.statusCode.toString() == "200") {
      return true;
    } else {
      return false;
    }
  }

//------------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //call localStorage data
  getSerialNumber() async {
    print('[getSerialNumber] Im in  getSerialNumber');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('serial').toString();
    //prefs.setString('accessToken', token);
  }

  getHouseId() async {
    print('[getHouseId] Im in  getHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('mainHouseid').toString();
    //prefs.setString('accessToken', token);
  }

  //get userid
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId').toString();
    //prefs.setString('accessToken', token);
  }
  //----------------------------------------------------------------------------

  // _sendsocketSerialNumber(sn) {
  //   print('sned sn to socketio for begin! ');
  //   socket.emit("serialNumber", {sn});
  // }

  //ส่งตัว socket ที่ และ ค่าที่เปลี่ยนไปยัง server เพื่อเปลี่ยนค่า status ของ socket ของอุปกรณ์นี้ใน account อื่นในกรณีที่มีการเพิ่มคนเข้ามาในบ้าน
  sendsocketStatus(sn, socketNum, status) {
    print('sned socketio!: $sn');
    socket.emit("ControlSocket", {
      'serialNumber': sn.toString(),
      'socketNum': socketNum,
      'status': status
    }); //ส่ง socket ตัวที่เท่าไหร่แล้วค่า status
  }

  //check socket io connection
  _conncetSocket() {
    socket.onConnect((data) => print('Connection established!')); //connected
    socket.onConnectError((data) => print('Connection Error: $data')); //error
    socket.onDisconnect(
        (data) => print('Socket.IO server disconnected! $data')); // disconnect
  }

  // @override
  // void initState() {
  //   //socket.disconnect();
  //   super.initState();
  // }

  Stream<dynamic> deviceTemp() async* {
    while (deviceStatus == "Online") {
      String temp = await getTempDevice();
      yield temp;
      await Future.delayed(const Duration(seconds: 10));
    }
  }

  @override
  void dispose() {
    removeCookie('clientIdSelectedDevice');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false,
      child: Container(
        width: size.width,
        height: size.height,
        color: Colors.white,
        child: FutureBuilder(
            future: getDeviceControlApi(),
            builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                if (snapshot.data != null) {
                  return Scaffold(
                    backgroundColor: Colors.white,
                    appBar: AppBar(
                      leading: IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: Colors.black,
                        onPressed: () async {
                          // if (socket.connected) {
                          //   socket.disconnect();
                          // }
                          socket.disconnect();
                          Navigator.of(context).pushReplacement(
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const NavigationBottomBarWidget()));
                        },
                      ),
                      actions: <Widget>[
                        IconButton(
                            icon: const Icon(
                              Icons.edit,
                              color: Colors.black,
                            ),
                            onPressed: () {
                              print('go to detail device page');
                              Navigator.of(context)
                                  .pushReplacement(MaterialPageRoute(
                                      builder: (context) => DeviceDetailPage(
                                            deviceName:
                                                snapshot.data.data.deviceName,
                                            roomName: snapshot.data.data.room,
                                            serialNumber:
                                                snapshot.data.data.serialNumber,
                                          )));
                              // Navigator.of(context)
                              //     .push(MaterialPageRoute(
                              //         builder: (context) => DeviceDetailPage(
                              //               deviceName:
                              //                   snapshot.data.data.deviceName,
                              //               roomName: snapshot.data.data.room,
                              //               serialNumber:
                              //                   snapshot.data.data.serialNumber,
                              //             )))
                              //     .then((value) => {
                              //           setState(
                              //               () {}) //re-build when come back to this page
                              //         });
                              // Navigator.push(
                              //     context,
                              //     MaterialPageRoute(
                              //         builder: (context) => DeviceDetailPage(
                              //               deviceName:
                              //                   snapshot.data.data.deviceName,
                              //               roomName: snapshot.data.data.room,
                              //               serialNumber:
                              //                   snapshot.data.data.serialNumber,
                              //             ))).then((value) {
                              //   setState(() {});
                              // });
                            })
                      ],
                      toolbarHeight: size.height * 0.075,
                      backgroundColor: Colors.white,
                      centerTitle: true,
                      elevation: 0, //remove shadow
                      title: Text(snapshot.data.data.deviceName,
                          style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w600,
                              color: Colors.black)),
                      iconTheme: const IconThemeData(
                          color: Color.fromARGB(255, 69, 47, 139)),
                    ),
                    body: Container(
                      width: size.width,
                      height: size.height,
                      color: Colors.white,
                      padding:
                          const EdgeInsets.only(left: 30, right: 30, top: 10),
                      child: Column(children: [
                        const SizedBox(
                          height: 20,
                        ),
                        //device status
                        Row(
                          children: [
                            const Text(
                              'Status',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black),
                            ),
                            const Spacer(),
                            if (deviceStatus == 'Online') ...{
                              Text(deviceStatus,
                                  style: const TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.green)),
                            } else ...{
                              Text(deviceStatus,
                                  style: const TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.grey)),
                            }
                          ],
                        ),
                        const SizedBox(
                          height: 18,
                        ),
                        //device location
                        Row(
                          children: [
                            const Text(
                              'Device location',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black),
                            ),
                            const Spacer(),
                            Container(
                              width: size.width * 0.4,
                              alignment: Alignment.centerRight,
                              child: Text(snapshot.data.data.room,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.black38)),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 18,
                        ),

                        
                        //temp device
                        Row(
                          children: [
                            const Text(
                              'Temperature',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black),
                            ),
                            const Spacer(),
                            StreamBuilder(
                                stream: deviceTemp(), 
                                builder: (BuildContext context,
                                    AsyncSnapshot<dynamic> ss) {
                                  if (ss.hasError) {
                                    return const Text("err",
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600,
                                            color: Color.fromARGB(
                                                95, 224, 36, 36)));
                                  } else {
                                    if (ss.connectionState ==
                                        ConnectionState.active) {
                                      return Text("${ss.data} °C",
                                          style: const TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black38));
                                    } else if (ss.connectionState ==
                                        ConnectionState.waiting) {
                                      return const Text("000",
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black38));
                                    } else if (ss.connectionState ==
                                        ConnectionState.none) {
                                      return const Text("none",
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black54));
                                    } else {
                                      return const Text("offline",
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black38));
                                    }
                                  }
                                })
                          ],
                        ),

                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          width: size.width,
                          height: 2,
                          color: Colors.black12,
                        ),
                        const SizedBox(
                          height: 5,
                        ),

                        //socket edit
                        Row(
                          children: [
                            const Text(
                              'Socket',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black),
                            ),
                            const Spacer(),
                            TextButton(
                                style: TextButton.styleFrom(
                                  padding: EdgeInsets.zero,
                                ),
                                onPressed: () {
                                  print('go to socket edit name page');
                                  Navigator.of(context).pushReplacement(
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              SocketEditNamePage(
                                                sN1: socketName1,
                                                sN2: socketName2,
                                                sN3: socketName3,
                                                sN4: socketName4,
                                              )));
                                  // Navigator.push(
                                  //     context,
                                  //     MaterialPageRoute(
                                  //         builder: (context) =>
                                  //             SocketEditNamePage(
                                  //               sN1: socketName1,
                                  //               sN2: socketName2,
                                  //               sN3: socketName3,
                                  //               sN4: socketName4,
                                  //             ))).then((value) {
                                  //   setState(() {});
                                  // });
                                },
                                child: const Row(
                                  children: [
                                    Text('Edit name socket.',
                                        style: TextStyle(
                                            //decoration: TextDecoration.underline,
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.black38)),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Icon(Icons.edit_outlined,
                                        color: Colors.black38)
                                  ],
                                ))
                          ],
                        ),

                        const SizedBox(
                          height: 50,
                        ),

                        if (countTimeStatus != "Open" &&
                            countTimeStatus != "Close") ...{
                          //control device
                          //ต้องทำการ statefulbuild ในส่วนของ contral device
                          //เพราะว่าเราต้อง setState ตัว Switch ที่ใช้ควบคุมอุปกรณ์ทุกครั้ง
                          //แต่เราจะ setState ทั้งหน้าไม่ได้เพราะเรามีการใช้ futurebuilder อยุ่
                          StatefulBuilder(
                              builder: (BuildContext context, setState) {
                            //รับค่าจาก socketio ฝั่ง server
                            String? tempData; //เก็บ socket ตัวที่จาก socket io
                            bool?
                                tempStatus; //เก็บ  status ของ socket จาก socket io

                            //int iii = 0;
                            int oneRound =
                                0; //เนื่องจากการทำงานของ socket.on มันจะทำวนลูปมากขึ้นเรื่อยๆ เลยต้องดักให้มันทำงานแค่ครั้งเดียว

                            //when socket io connect
                            socket.on(
                                serialNumberGloble,
                                (data) => {
                                      print('SOCKET ON!'),
                                      //print('data from socket io : ${data}'), //{socketNum: 1}
                                      //print('data from socket io : ${data["socketNum"]}'), //1
                                      //print('Serial number from socket io: ${data["serialNumber"]}'),

                                      tempData = data["socketNum"],
                                      tempStatus = data["status"],
                                      if (data["serialNumber"] ==
                                          serialNumberGloble)
                                        {
                                          print('correct sn'),
                                          if (oneRound == 0)
                                            {
                                              if (data["socketNum"] == "1")
                                                {
                                                  //print("status1 before: $status1"),
                                                  print('change status 1 !'),
                                                  status1 = tempStatus!,
                                                  //print("status1 after: $status1"),
                                                  tempData == null,
                                                  oneRound++,
                                                }
                                              else if (data["socketNum"] == "2")
                                                {
                                                  print('change status 2 !'),
                                                  status2 = tempStatus!,
                                                  //print("status1 after: $status1"),
                                                  tempData == null,
                                                  oneRound++,
                                                }
                                              else if (data["socketNum"] == "3")
                                                {
                                                  print('change status 3 !'),
                                                  status3 = tempStatus!,
                                                  //print("status1 after: $status1"),
                                                  tempData == null,
                                                  oneRound++,
                                                }
                                              else if (data["socketNum"] == "4")
                                                {
                                                  print('change status 4 !'),
                                                  status4 = tempStatus!,
                                                  //print("status1 after: $status1"),
                                                  tempData == null,
                                                  oneRound++,
                                                },
                                              print(
                                                  '================================'),
                                              //mounted เป็นการเช็คว่า widget ของเราได้ติดตั้งแล้วหรือยัง หากไม่ได้ ติดตั้งจะไม่สามารถใช้ setState ได้
                                              // StatefulBuilder เป็น หนึ่งใน widget และไม่สามารถ setstate ได้ถ้าไม่เช็ค mounted
                                              /*ตรงนี้ ไม่แน่ใจเหมือนกันว่าการทำงานจริงๆ มันคือยัง แต่ปัญหาที่เคยเจอคือ 
                                               เมื่อเรากดออกจากหน้าอุปกรณ์แล้วเช้ามาใหม่ จะไม่สามารถ setState ได้ (แต่ครั้งแรกที่เข้ามาหน้าอุปกรณ์สามารถ setState ได้)*/
                                              //สรปุคือมันแก้ได้โดยเช็ค mounted
                                              if (mounted)
                                                {
                                                  print('mounted!'),
                                                  setState(() => {})
                                                }
                                              else
                                                {print('not mounted!')}
                                            },
                                        }
                                      else
                                        {
                                          print('wrong sn'),
                                        }
                                    });

                            return Container(
                              width: size.width,
                              height: size.height * 0.35,
                              //color: Colors.yellow,
                              padding: EdgeInsets.only(
                                  left: size.width * 0.01,
                                  right: size.width * 0.01),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      //Socket 1
                                      Container(
                                        width: size.width * 0.35,
                                        height: size.height * 0.15,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          color: const Color.fromARGB(
                                              255, 223, 225, 227),
                                        ),
                                        child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                width: size.width * 0.28,
                                                alignment: Alignment.center,
                                                //color: Colors.red,
                                                child: Text(
                                                  socketName1 ?? 'Socket 1',
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: const TextStyle(
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: Colors.black),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              FlutterSwitch(
                                                width: 70,
                                                height: 35,
                                                valueFontSize: 15.0,
                                                toggleSize: 25.0,
                                                value: status1,
                                                borderRadius: 30.0,
                                                padding: 8.0,
                                                showOnOff: true,
                                                activeColor: Color.fromARGB(
                                                    255, 117, 138, 214),
                                                disabled: sw,
                                                onToggle: (val) {
                                                  setState(() {
                                                    status1 = val;
                                                    sendsocketStatus(
                                                        serialNumberGloble,
                                                        "1",
                                                        val);
                                                    if (status1 == true) {
                                                      print('socket 1 :on');
                                                      sendHTTPNETPIERelay1On(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    } else if (status1 ==
                                                        false) {
                                                      print('socket 1 :off');
                                                      sendHTTPNETPIERelay1Off(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    }
                                                  });

                                                  // setState(() {

                                                  // });
                                                },
                                              ),
                                            ]),
                                      ),
                                      const Spacer(),
                                      //Socket 2
                                      Container(
                                        width: size.width * 0.35,
                                        height: size.height * 0.15,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          color: const Color.fromARGB(
                                              255, 223, 225, 227),
                                        ),
                                        child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                width: size.width * 0.28,
                                                alignment: Alignment.center,
                                                //color: Colors.red,
                                                child: Text(
                                                  socketName2 ?? 'Socket 2',
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: const TextStyle(
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: Colors.black),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              FlutterSwitch(
                                                width: 70,
                                                height: 35,
                                                valueFontSize: 15.0,
                                                toggleSize: 25.0,
                                                value: status2,
                                                borderRadius: 30.0,
                                                padding: 8.0,
                                                showOnOff: true,
                                                activeColor: Color.fromARGB(
                                                    255, 117, 138, 214),
                                                disabled: sw,
                                                onToggle: (val) {
                                                  setState(() {
                                                    status2 = val;

                                                    sendsocketStatus(
                                                        serialNumberGloble,
                                                        "2",
                                                        val);
                                                    if (status2 == true) {
                                                      print('socket 2 :on');
                                                      sendHTTPNETPIERelay2On(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    } else if (status2 ==
                                                        false) {
                                                      print('socket 2 :off');
                                                      sendHTTPNETPIERelay2Off(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    }
                                                  });
                                                },
                                              ),
                                            ]),
                                      )
                                    ],
                                  ),
                                  const Spacer(),
                                  Row(
                                    children: [
                                      //Socket 3
                                      Container(
                                        width: size.width * 0.35,
                                        height: size.height * 0.15,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          color: const Color.fromARGB(
                                              255, 223, 225, 227),
                                        ),
                                        child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                width: size.width * 0.28,
                                                alignment: Alignment.center,
                                                //color: Colors.red,
                                                child: Text(
                                                  socketName3 ?? 'Socket 3',
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: const TextStyle(
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: Colors.black),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              FlutterSwitch(
                                                width: 70,
                                                height: 35,
                                                valueFontSize: 15.0,
                                                toggleSize: 25.0,
                                                value: status3,
                                                borderRadius: 30.0,
                                                padding: 8.0,
                                                showOnOff: true,
                                                activeColor: Color.fromARGB(
                                                    255, 117, 138, 214),
                                                disabled: sw,
                                                onToggle: (val) {
                                                  setState(() {
                                                    status3 = val;

                                                    sendsocketStatus(
                                                        serialNumberGloble,
                                                        "3",
                                                        val);
                                                    if (status3 == true) {
                                                      print('socket 3 :on');
                                                      sendHTTPNETPIERelay3On(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    } else if (status3 ==
                                                        false) {
                                                      print('socket 3 :off');
                                                      sendHTTPNETPIERelay3Off(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    }
                                                  });
                                                },
                                              ),
                                            ]),
                                      ),
                                      const Spacer(),
                                      //Socket 4
                                      Container(
                                        width: size.width * 0.35,
                                        height: size.height * 0.15,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          color: const Color.fromARGB(
                                              255, 223, 225, 227),
                                        ),
                                        child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                width: size.width * 0.28,
                                                alignment: Alignment.center,
                                                //color: Colors.red,
                                                child: Text(
                                                  socketName4 ?? 'Socket 4',
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.center,
                                                  style: const TextStyle(
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: Colors.black),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              FlutterSwitch(
                                                width: 70,
                                                height: 35,
                                                valueFontSize: 15.0,
                                                toggleSize: 25.0,
                                                value: status4,
                                                borderRadius: 30.0,
                                                padding: 8.0,
                                                showOnOff: true,
                                                activeColor: Color.fromARGB(
                                                    255, 117, 138, 214),
                                                disabled: sw,
                                                onToggle: (val) {
                                                  setState(() {
                                                    status4 = val;

                                                    sendsocketStatus(
                                                        serialNumberGloble,
                                                        "4",
                                                        val);
                                                    if (status4 == true) {
                                                      print('socket 4 :on');
                                                      sendHTTPNETPIERelay4On(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    } else if (status4 ==
                                                        false) {
                                                      print('socket 4 :off');
                                                      sendHTTPNETPIERelay4Off(
                                                          snapshot.data.data
                                                              .clientId,
                                                          snapshot
                                                              .data.data.token);
                                                    }
                                                  });
                                                },
                                              ),
                                            ]),
                                      )
                                    ],
                                  )
                                ],
                              ),
                            );
                          })
                        } else ...{
                          //device is automation count time mode
                          Container(
                              width: size.width,
                              height: size.height * 0.35,
                              //color: Colors.yellow,
                              padding: EdgeInsets.only(
                                  left: size.width * 0.01,
                                  right: size.width * 0.01),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text('This device is automation mode.',
                                      style: TextStyle(
                                          fontSize: 28, color: Colors.black38),
                                      textAlign: TextAlign.center),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  SizedBox(
                                    width: size.width * 0.3,
                                    height: size.height * 0.06,
                                    child: TextButton(
                                      style: TextButton.styleFrom(
                                        backgroundColor: const Color.fromARGB(
                                            255, 117, 138, 214),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        foregroundColor: Colors.white,
                                        padding: EdgeInsets.zero,
                                        textStyle:
                                            const TextStyle(fontSize: 20),
                                      ),
                                      onPressed: () async {
                                        var x =
                                            await sendDataToNetpie('idle', "0");
                                        if (x) {
                                          setState(() {});
                                        } else {
                                          popup("Can't stop counting time.");
                                        }
                                      },
                                      child: const Text(
                                        'Cancel',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'FCfont',
                                          fontSize: 24,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              )),
                        }
                      ]),
                    ),
                  );
                } else {
                  return connectFailed();
                }
              } else {
                return loadingBox();
              }
            }),
      ),
    );
  }

  //popup
  popup(text) {
    return showDialog<String>(
      barrierDismissible: false,
      //barrierColor: move == "timeout" ? null : Colors.black54,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false,
        child: AlertDialog(
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context, 'Ok');
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Connection failed!',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width * 0.3,
            height: size.height * 0.06,
            child: TextButton(
              style: TextButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                foregroundColor: Colors.white,
                padding: EdgeInsets.zero,
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {});
              },
              child: const Text(
                'Try again',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'FCfont',
                  fontSize: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          DefaultTextStyle(
            style: TextStyle(
                fontSize: 24, fontFamily: 'FCfont', color: Colors.black),
            child: Card(
              shadowColor: Colors.transparent,
              elevation: 0,
              child: Text(
                'Loading...',
                textAlign: TextAlign.center,
              ),
            ),
          )
        ],
      ),
    );
  }

//control device function-------------------------------------------------------
  void sendHTTPNETPIERelay1On(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    // String basicAuth = 'Basic ' +
    //     convert.base64Encode(convert.utf8.encode('$username:$password'));
    String basicAuth = 'Device $username:$password';

    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay1');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: "R01_ON");

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay1Off(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    // String basicAuth = 'Basic ' +
    //     convert.base64Encode(convert.utf8.encode('$username:$password'));
    String basicAuth = 'Device $username:$password';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay1');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: "R01_OFF");

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay2On(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    String basicAuth =
        'Basic ${convert.base64Encode(convert.utf8.encode('$username:$password'))}';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay2');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R02_ON');

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay2Off(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    String basicAuth =
        'Basic ${convert.base64Encode(convert.utf8.encode('$username:$password'))}';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay2');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R02_OFF');

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay3On(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    String basicAuth =
        'Basic ${convert.base64Encode(convert.utf8.encode('$username:$password'))}';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay3');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R03_ON');

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay3Off(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    String basicAuth =
        'Basic ${convert.base64Encode(convert.utf8.encode('$username:$password'))}';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay3');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R03_OFF');

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay4On(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    String basicAuth =
        'Basic ${convert.base64Encode(convert.utf8.encode('$username:$password'))}';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay4');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R04_ON');

    print(r.statusCode);
    print(r.body);
  }

  void sendHTTPNETPIERelay4Off(cn, tk) async {
    String username = cn; //'73403a5e-39d9-4d6f-94e2-5ff69a0a2ff0'; //clientId
    String password = tk; //'dW2yPnrwg9ksdK3pA9YoMc5CmL71NPFP'; //username
    String basicAuth =
        'Basic ${convert.base64Encode(convert.utf8.encode('$username:$password'))}';
    print(basicAuth);
    Uri myUri =
        Uri.parse('https://api.netpie.io/v2/device/message?topic=Relay4');

    http.Response r = await http.put(myUri,
        headers: <String, String>{'authorization': basicAuth}, body: 'R04_OFF');

    print(r.statusCode);
    print(r.body);
  }
//------------------------------------------------------------------------------
}
