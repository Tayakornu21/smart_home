import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import 'devicePage.dart';

class SocketEditNamePage extends StatefulWidget {
  const SocketEditNamePage({super.key, this.sN1, this.sN2, this.sN3, this.sN4});

  final sN1;
  final sN2;
  final sN3;
  final sN4;
  @override
  State<SocketEditNamePage> createState() => _SocketEditNamePageState();
}

class _SocketEditNamePageState extends State<SocketEditNamePage> {
  // String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";

  String? socket1;
  TextEditingController socket1Controller = TextEditingController();

  String? socket2;
  TextEditingController socket2Controller = TextEditingController();

  String? socket3;
  TextEditingController socket3Controller = TextEditingController();

  String? socket4;
  TextEditingController socket4Controller = TextEditingController();

  //api function ---------------------------------------------------------------
  //edit socket name
  editNameSocketApi(index, name) async {
    print('[editNameSocketApi] Im editNameSocketApi function');
    String tempSn = await getSerialNumber();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/UpdateSubDevbice');

    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            'serialNumber': tempSn,
            "indexSubDevice": index,
            "name": name
          });

      print('[editNameSocketApi] status Code : ${response.statusCode}');
      print('[editNameSocketApi] body : ${response.body}');
      if (response.statusCode == 200) {
        return true;
      } else {
        popup("Can't change the name!\nSomething is wrong.", 'null');
        return false;
      }
    } catch (e) {
      print('[editNameDeviceApi] error: $e');
      popup("Can't change the name!\nConnection failed.", 'null');
      return false;
    }
  }

  //----------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //call localStorage data
  getSerialNumber() async {
    print('[getSerialNumber] Im in  getSerialNumber');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //print('[getUserId] userId: $userId');
    return prefs.getString('serial').toString();
    //prefs.setString('accessToken', token);
  }

  //----------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => const DevicePage()))
            },
          ),
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow
          title: const Text('Socket edit name',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black)),
          iconTheme:
              const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: Container(
          width: size.width,
          height: size.height * 0.85,
          color: Colors.white,
          padding: const EdgeInsets.only(bottom: 10),
          child: Column(children: [
            //socket
            // Container(
            //   width: size.width * 0.9,
            //   padding: const EdgeInsets.only(left: 10),
            //   child: const Text(
            //     'Socket',
            //     style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
            //   ),
            // ),

            //-------------------------Socket 1----------------------------//
            Container(
              width: size.width * 0.9,
              height: size.height * 0.06,
              //color: Colors.orange,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(children: [
                const Text('Socket 1',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                const Spacer(),
                TextButton(
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.zero,
                  ),
                  onPressed: () {
                    socket1Controller.clear();
                    //popup สำหรับแก้ไขชื่อ socket ที่ 1
                    showModalBottomSheet(
                        isDismissible: false,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(25.0))),
                        backgroundColor: Colors.white,
                        context: context,
                        isScrollControlled: true,
                        builder: (BuildContext context) {
                          return StatefulBuilder(
                              builder: (BuildContext context, setState) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width,
                                      height: size.height * 0.08,
                                      //color: Colors.red,
                                      alignment: Alignment.center,
                                      child: const Text(
                                        'Edit socket 1 name',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width * 0.9,
                                      height: size.height * 0.08,
                                      alignment: Alignment.center,
                                      //margin: const EdgeInsets.only(top: 15),
                                      decoration: BoxDecoration(
                                        color: Colors.black12,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      padding: const EdgeInsets.only(
                                          left: 20, right: 20),
                                      child: TextField(
                                        controller: socket1Controller,
                                        onChanged: (text) {
                                          setState(() {
                                            //for check controller
                                          });
                                        },
                                        //enableSuggestions: false,
                                        //autocorrect: false,
                                        decoration: const InputDecoration(
                                          hintStyle: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600),
                                          hintText: 'New socket 1 name',
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          bottom: MediaQuery.of(context)
                                              .viewInsets
                                              .bottom),
                                      child: Container(
                                        width: size.width * 0.9,
                                        height: size.height * 0.08,
                                        alignment: Alignment.center,
                                        //color: Colors.yellowAccent,
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: size.width * 0.38,
                                              height: size.height * 0.07,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                color: const Color.fromARGB(
                                                    255, 189, 189, 189),
                                              ),
                                              child: TextButton(
                                                  style: ButtonStyle(
                                                      shape: MaterialStateProperty.all<
                                                              RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ))),
                                                  child: const Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: Color.fromARGB(
                                                            255, 35, 35, 35)),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  }),
                                            ),
                                            const Spacer(),
                                            if (socket1Controller.text !=
                                                '') ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      255, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () async {
                                                      //setstate
                                                      var c =
                                                          await editNameSocketApi(
                                                              '1',
                                                              socket1Controller
                                                                  .text);

                                                      if (c) {
                                                        setState(() {
                                                          socket1 =
                                                              socket1Controller
                                                                  .text;
                                                        });
                                                      }

                                                      socket1Controller
                                                          .clear(); //เปิด pop-up ใหม่จะรีค่า deviceNameController

                                                      //close popup
                                                      Navigator.of(context)
                                                          .pop();
                                                    }),
                                              ),
                                            } else ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      122, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () {
                                                      //notting
                                                    }),
                                              ),
                                            }
                                          ],
                                        ),
                                      )),
                                  const SizedBox(height: 10),
                                ],
                              ),
                            );
                          });
                        });
                  },
                  child: Row(
                    children: [
                      Container(
                          width: size.width * 0.5,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(left: 5),
                          //color: Colors.yellow,
                          child: Text(
                            socket1 ?? widget.sN1,
                            style: const TextStyle(
                                color: Colors.black38,
                                fontSize: 24,
                                fontWeight: FontWeight.w600),
                          )),
                      //const Spacer(),
                      Container(
                          width: size.width * 0.045,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          //color: Colors.blue,
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: Colors.black,
                          ))
                    ],
                  ),
                )
              ]),
            ),
            //--------------------------------------------------------------//

            //-------------------------Socket 2----------------------------//
            Container(
              width: size.width * 0.9,
              height: size.height * 0.06,
              //color: Colors.orange,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(children: [
                const Text('Socket 2',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                const Spacer(),
                TextButton(
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.zero,
                  ),
                  onPressed: () {
                    socket2Controller.clear();
                    //popup สำหรับแก้ไขชื่อ socket ที่ 2
                    showModalBottomSheet(
                        isDismissible: false,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(25.0))),
                        backgroundColor: Colors.white,
                        context: context,
                        isScrollControlled: true,
                        builder: (BuildContext context) {
                          return StatefulBuilder(
                              builder: (BuildContext context, setState) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width,
                                      height: size.height * 0.08,
                                      //color: Colors.red,
                                      alignment: Alignment.center,
                                      child: const Text(
                                        'Edit socket 2 name',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width * 0.9,
                                      height: size.height * 0.08,
                                      alignment: Alignment.center,
                                      //margin: const EdgeInsets.only(top: 15),
                                      decoration: BoxDecoration(
                                        color: Colors.black12,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      padding: const EdgeInsets.only(
                                          left: 20, right: 20),
                                      child: TextField(
                                        controller: socket2Controller,
                                        onChanged: (text) {
                                          setState(() {
                                            //for check controller
                                          });
                                        },
                                        //enableSuggestions: false,
                                        //autocorrect: false,
                                        decoration: const InputDecoration(
                                          hintStyle: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600),
                                          hintText: 'New socket 2 name',
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          bottom: MediaQuery.of(context)
                                              .viewInsets
                                              .bottom),
                                      child: Container(
                                        width: size.width * 0.9,
                                        height: size.height * 0.08,
                                        alignment: Alignment.center,
                                        //color: Colors.yellowAccent,
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: size.width * 0.38,
                                              height: size.height * 0.07,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                color: const Color.fromARGB(
                                                    255, 189, 189, 189),
                                              ),
                                              child: TextButton(
                                                  style: ButtonStyle(
                                                      shape: MaterialStateProperty.all<
                                                              RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ))),
                                                  child: const Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: Color.fromARGB(
                                                            255, 35, 35, 35)),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  }),
                                            ),
                                            const Spacer(),
                                            if (socket2Controller.text !=
                                                '') ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      255, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () async {
                                                      //setstate
                                                      var c =
                                                          await editNameSocketApi(
                                                              '2',
                                                              socket2Controller
                                                                  .text);
                                                      if (c) {
                                                        setState(() {
                                                          socket2 =
                                                              socket2Controller
                                                                  .text;
                                                        });
                                                      }

                                                      socket2Controller
                                                          .clear(); //เปิด pop-up ใหม่จะรีค่า deviceNameController

                                                      //close popup
                                                      Navigator.of(context)
                                                          .pop();
                                                    }),
                                              ),
                                            } else ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      122, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () {
                                                      //notting
                                                    }),
                                              ),
                                            }
                                          ],
                                        ),
                                      )),
                                  const SizedBox(height: 10),
                                ],
                              ),
                            );
                          });
                        });
                  },
                  child: Row(
                    children: [
                      Container(
                          width: size.width * 0.5,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(left: 5),
                          //color: Colors.yellow,
                          child: Text(
                            socket2 ?? widget.sN2,
                            style: const TextStyle(
                                color: Colors.black38,
                                fontSize: 24,
                                fontWeight: FontWeight.w600),
                          )),
                      //const Spacer(),
                      Container(
                          width: size.width * 0.045,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          //color: Colors.blue,
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: Colors.black,
                          ))
                    ],
                  ),
                )
              ]),
            ),
            //--------------------------------------------------------------//

            //-------------------------Socket 3----------------------------//
            Container(
              width: size.width * 0.9,
              height: size.height * 0.06,
              //color: Colors.orange,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(children: [
                const Text('Socket 3',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                const Spacer(),
                TextButton(
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.zero,
                  ),
                  onPressed: () {
                    socket3Controller.clear();
                    //popup สำหรับแก้ไขชื่อ socket ที่ 3
                    showModalBottomSheet(
                        isDismissible: false,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(25.0))),
                        backgroundColor: Colors.white,
                        context: context,
                        isScrollControlled: true,
                        builder: (BuildContext context) {
                          return StatefulBuilder(
                              builder: (BuildContext context, setState) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width,
                                      height: size.height * 0.08,
                                      //color: Colors.red,
                                      alignment: Alignment.center,
                                      child: const Text(
                                        'Edit socket 3 name',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width * 0.9,
                                      height: size.height * 0.08,
                                      alignment: Alignment.center,
                                      //margin: const EdgeInsets.only(top: 15),
                                      decoration: BoxDecoration(
                                        color: Colors.black12,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      padding: const EdgeInsets.only(
                                          left: 20, right: 20),
                                      child: TextField(
                                        controller: socket3Controller,
                                        onChanged: (text) {
                                          setState(() {
                                            //for check controller
                                          });
                                        },
                                        //enableSuggestions: false,
                                        //autocorrect: false,
                                        decoration: const InputDecoration(
                                          hintStyle: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600),
                                          hintText: 'New socket 3 name',
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          bottom: MediaQuery.of(context)
                                              .viewInsets
                                              .bottom),
                                      child: Container(
                                        width: size.width * 0.9,
                                        height: size.height * 0.08,
                                        alignment: Alignment.center,
                                        //color: Colors.yellowAccent,
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: size.width * 0.38,
                                              height: size.height * 0.07,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                color: const Color.fromARGB(
                                                    255, 189, 189, 189),
                                              ),
                                              child: TextButton(
                                                  style: ButtonStyle(
                                                      shape: MaterialStateProperty.all<
                                                              RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ))),
                                                  child: const Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: Color.fromARGB(
                                                            255, 35, 35, 35)),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  }),
                                            ),
                                            const Spacer(),
                                            if (socket3Controller.text !=
                                                '') ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      255, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () async {
                                                      //setstate
                                                      var c =
                                                          await editNameSocketApi(
                                                              '3',
                                                              socket3Controller
                                                                  .text);
                                                      if (c) {
                                                        setState(() {
                                                          socket3 =
                                                              socket3Controller
                                                                  .text;
                                                        });
                                                      }
                                                      socket3Controller
                                                          .clear(); //เปิด pop-up ใหม่จะรีค่า deviceNameController

                                                      //close popup
                                                      Navigator.of(context)
                                                          .pop();
                                                    }),
                                              ),
                                            } else ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      122, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () {
                                                      //notting
                                                    }),
                                              ),
                                            }
                                          ],
                                        ),
                                      )),
                                  const SizedBox(height: 10),
                                ],
                              ),
                            );
                          });
                        });
                  },
                  child: Row(
                    children: [
                      Container(
                          width: size.width * 0.5,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(left: 5),
                          //color: Colors.yellow,
                          child: Text(
                            socket3 ?? widget.sN3,
                            style: const TextStyle(
                                color: Colors.black38,
                                fontSize: 24,
                                fontWeight: FontWeight.w600),
                          )),
                      //const Spacer(),
                      Container(
                          width: size.width * 0.045,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          //color: Colors.blue,
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: Colors.black,
                          ))
                    ],
                  ),
                )
              ]),
            ),
            //--------------------------------------------------------------//

            //-------------------------Socket 4----------------------------//
            Container(
              width: size.width * 0.9,
              height: size.height * 0.06,
              //color: Colors.orange,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(children: [
                const Text('Socket 4',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                const Spacer(),
                TextButton(
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.zero,
                  ),
                  onPressed: () {
                    socket4Controller.clear();
                    //popup สำหรับแก้ไขชื่อ socket ที่ 4
                    showModalBottomSheet(
                        isDismissible: false,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(25.0))),
                        backgroundColor: Colors.white,
                        context: context,
                        isScrollControlled: true,
                        builder: (BuildContext context) {
                          return StatefulBuilder(
                              builder: (BuildContext context, setState) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width,
                                      height: size.height * 0.08,
                                      //color: Colors.red,
                                      alignment: Alignment.center,
                                      child: const Text(
                                        'Edit socket 4 name',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width * 0.9,
                                      height: size.height * 0.08,
                                      alignment: Alignment.center,
                                      //margin: const EdgeInsets.only(top: 15),
                                      decoration: BoxDecoration(
                                        color: Colors.black12,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      padding: const EdgeInsets.only(
                                          left: 20, right: 20),
                                      child: TextField(
                                        controller: socket4Controller,
                                        onChanged: (text) {
                                          setState(() {
                                            //for check controller
                                          });
                                        },
                                        //enableSuggestions: false,
                                        //autocorrect: false,
                                        decoration: const InputDecoration(
                                          hintStyle: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600),
                                          hintText: 'New socket 4 name',
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          bottom: MediaQuery.of(context)
                                              .viewInsets
                                              .bottom),
                                      child: Container(
                                        width: size.width * 0.9,
                                        height: size.height * 0.08,
                                        alignment: Alignment.center,
                                        //color: Colors.yellowAccent,
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: size.width * 0.38,
                                              height: size.height * 0.07,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                color: const Color.fromARGB(
                                                    255, 189, 189, 189),
                                              ),
                                              child: TextButton(
                                                  style: ButtonStyle(
                                                      shape: MaterialStateProperty.all<
                                                              RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ))),
                                                  child: const Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: Color.fromARGB(
                                                            255, 35, 35, 35)),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  }),
                                            ),
                                            const Spacer(),
                                            if (socket4Controller.text !=
                                                '') ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      255, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () async {
                                                      //setstate
                                                      var c =
                                                          await editNameSocketApi(
                                                              '4',
                                                              socket4Controller
                                                                  .text);
                                                      if (c) {
                                                        setState(() {
                                                          socket4 =
                                                              socket4Controller
                                                                  .text;
                                                        });
                                                      }
                                                      socket4Controller
                                                          .clear(); //เปิด pop-up ใหม่จะรีค่า deviceNameController

                                                      //close popup
                                                      Navigator.of(context)
                                                          .pop();
                                                    }),
                                              ),
                                            } else ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      122, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () {
                                                      //notting
                                                    }),
                                              ),
                                            }
                                          ],
                                        ),
                                      )),
                                  const SizedBox(height: 10),
                                ],
                              ),
                            );
                          });
                        });
                  },
                  child: Row(
                    children: [
                      Container(
                          width: size.width * 0.5,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(left: 5),
                          //color: Colors.yellow,
                          child: Text(
                            socket4 ?? widget.sN4,
                            style: const TextStyle(
                                color: Colors.black38,
                                fontSize: 24,
                                fontWeight: FontWeight.w600),
                          )),
                      //const Spacer(),
                      Container(
                          width: size.width * 0.045,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          //color: Colors.blue,
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: Colors.black,
                          ))
                    ],
                  ),
                )
              ]),
            ),
            //--------------------------------------------------------------//
          ]),
        ));
  }

  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24, fontWeight: FontWeight.w600, color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  if (move == 'move') {
                    //move to other page : main page
                    // Navigator.pushReplacement(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) =>
                    //             const NavigationBottomBarWidget()));
                  } else {
                    Navigator.pop(context, 'Cancel');
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
