import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/widget/navigationBottomBarWidget.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'devicePage.dart';

class DeviceDetailPage extends StatefulWidget {
  const DeviceDetailPage({
    super.key,
    required this.deviceName,
    required this.roomName,
    required this.serialNumber,
  });

  final String deviceName;
  final String roomName;
  final String serialNumber;
  @override
  State<DeviceDetailPage> createState() => _DeviceDetailPageState();
}

class _DeviceDetailPageState extends State<DeviceDetailPage> {
  //String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";
  //String? oldName; //keep old device name
  String? nameDevice;
  TextEditingController deviceNameController = TextEditingController();
  String? selectRoom;
  TextEditingController roomNameController = TextEditingController();
  var roomList = [
    'Bedroom',
    'Bathroom',
    'Shower room',
    'Kitchen',
    'Living room',
    "Eating room",
    "Children's room",
    'Work room',
    'Office',
    'Balcony',
    'Garden',
  ];

  //api function----------------------------------------------------------------
  //edit name device
  editNameDeviceApi(oldName, newName, sn) async {
    //sn = serial number
    print('[editNameDeviceApi] Im editNameDeviceApi function');
    // print('[editNameDeviceApi] oldName: $oldName');
    // print('[editNameDeviceApi] newName: $newName');
    // print('[editNameDeviceApi] sn: $sn');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/updateDeviceName');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            'old_deviceName': oldName,
            "new_deviceName": newName,
            "serialNumber": sn
          });

      print('[editNameDeviceApi] status Code : ${response.statusCode}');
      print('[editNameDeviceApi] body : ${response.body}');

      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)

      if (jsonResponse['error'] == false) {
        return true;
      } else {
        if (jsonResponse['message'] ==
            "Data too long for column 'deviceName' at row 1") {
          popup("Can't change the name of device!\nThe name is too long.",
              'null'); //wrong status code
        } else {
          popup("Can't change the name of device!\nSomething Wrong.", 'null');
        }

        return false;
      }
    } catch (e) {
      print('[editNameDeviceApi] error: $e');
      popup("Can't change the name of device!\nConnection failed.", 'null');
      return false;
    }
  }

  //delete device api
  delDeviceApi(sn) async {
    print('[delDeviceApi] Im delDeviceApi function');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/delDevice');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "serialNumber": sn,
          });

      print('[delDeviceApi] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        //clear serial localstorage
        clearSerialNumber();
        print('[delDeviceApi] finsih!');
        popup('Deleted', 'move');
        //deleted
      } else {
        //cant deleted
        popup("Can't deleted!\nSomething is wrong.", 'null');
        //maybe show pop up
      }
    } catch (e) {
      print('[delDeviceApi] error: $e');
      popup("Can't deleted!\nConnection failed.", 'null');
      //cant deleted
      //maybe show pop up
    }
  }

  //edit room device
  editRoomDeviceApi(newRoom, sn) async {
    //sn = serial number
    print('[editRoomDeviceApi] Im editRoomDeviceApi function');
    // print('[editNameDeviceApi] oldName: $oldName');
    print('[editRoomDeviceApi] newRoom: $newRoom');
    print('[editRoomDeviceApi] sn: $sn');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/updateDeviceRoom');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"new_room": newRoom, "serialNumber": sn});

      print('[editRoomDeviceApi] status Code : ${response.statusCode}');
      print('[editRoomDeviceApi] body : ${response.body}');
      if (response.statusCode == 200) {
        return true;
      } else {
        popup("Can't change the room!\nSomething is wrong.", 'null');
        return false;
      }
    } catch (e) {
      print('[editRoomDeviceApi] error: $e');
      popup("Can't change the room!\nConnection failed.", 'null');
      return false;
    }
  }

  //----------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //ลบ Serialnumber ออกจาก Local Storage
  clearSerialNumber() async {
    print('[clearSerialNumber] Im clearSerialNumber function');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('serial');
    print('[clearSerialNumber] finish!');
  }

  //----------------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => {
            Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => const DevicePage()))
          },
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow
        title: Container(
          width: size.width * 0.65,
          alignment: Alignment.center,
          child: Text(nameDevice ?? widget.deviceName,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black)),
        ),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: Container(
        width: size.width,
        height: size.height * 0.85,
        color: Colors.white,
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            //name device bt
            Container(
              width: size.width * 0.9,
              height: size.height * 0.08,
              //color: Colors.orange,
              alignment: Alignment.center,
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.only(left: 10),
              child: Row(children: [
                const Text('Name',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                const Spacer(),
                TextButton(
                  onPressed: () {
                    deviceNameController.clear();
                    //popup สำหรับแก้ไขชื่ออุปกรณ์
                    showModalBottomSheet(
                        isDismissible: false,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(25.0))),
                        backgroundColor: Colors.white,
                        context: context,
                        isScrollControlled: true,
                        builder: (BuildContext context) {
                          return StatefulBuilder(
                              builder: (BuildContext context, setState) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width,
                                      height: size.height * 0.08,
                                      //color: Colors.red,
                                      alignment: Alignment.center,
                                      child: const Text(
                                        'Edit device name',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width * 0.9,
                                      height: size.height * 0.08,
                                      alignment: Alignment.center,
                                      //margin: const EdgeInsets.only(top: 15),
                                      decoration: BoxDecoration(
                                        color: Colors.black12,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      padding: const EdgeInsets.only(
                                          left: 20, right: 20),
                                      child: TextField(
                                        controller: deviceNameController,
                                        onChanged: (text) {
                                          setState(() {
                                            //for check controller
                                          });
                                        },
                                        //enableSuggestions: false,
                                        //autocorrect: false,
                                        decoration: const InputDecoration(
                                          hintStyle: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600),
                                          hintText: 'New device name',
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          bottom: MediaQuery.of(context)
                                              .viewInsets
                                              .bottom),
                                      child: Container(
                                        width: size.width * 0.9,
                                        height: size.height * 0.08,
                                        alignment: Alignment.center,
                                        //color: Colors.yellowAccent,
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: size.width * 0.38,
                                              height: size.height * 0.07,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                color: const Color.fromARGB(
                                                    255, 189, 189, 189),
                                              ),
                                              child: TextButton(
                                                  style: ButtonStyle(
                                                      shape: MaterialStateProperty.all<
                                                              RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ))),
                                                  child: const Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: Color.fromARGB(
                                                            255, 35, 35, 35)),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  }),
                                            ),
                                            const Spacer(),
                                            if (deviceNameController.text !=
                                                '') ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      255, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () async {
                                                      //setstate
                                                      //เช้คว่า่สามารถเปลี่ยนชื่อได้จริงไหมถ้าได้จริงก้จะเปลี่ยน
                                                      var c = await editNameDeviceApi(
                                                          nameDevice ??
                                                              widget.deviceName,
                                                          deviceNameController
                                                              .text,
                                                          widget.serialNumber);
                                                      if (c) {
                                                        setState(() {
                                                          nameDevice =
                                                              deviceNameController
                                                                  .text;
                                                        });
                                                      }

                                                      deviceNameController
                                                          .clear(); //เปิด pop-up ใหม่จะรีค่า deviceNameController

                                                      //close popup
                                                      Navigator.of(context)
                                                          .pop();
                                                    }),
                                              ),
                                            } else ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      122, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () {
                                                      //notting
                                                    }),
                                              ),
                                            }
                                          ],
                                        ),
                                      )),
                                  const SizedBox(height: 10),
                                ],
                              ),
                            );
                          });
                        }).then((value) => {setState(() {})});
                  },
                  child: Row(
                    children: [
                      Container(
                          width: size.width * 0.6,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(left: 5),
                          //color: Colors.yellow,
                          child: Text(
                            nameDevice ?? widget.deviceName, //ชื่ออุปกรณ์
                            style: const TextStyle(
                                color: Colors.black38,
                                fontSize: 24,
                                fontWeight: FontWeight.w600),
                          )),
                      //const Spacer(),
                      Container(
                          width: size.width * 0.055,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          //color: Colors.blue,
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: Colors.black,
                          ))
                    ],
                  ),
                )
              ]),
            ),

            //เส้นดำ
            Container(
              width: size.width * 0.9,
              height: 2,
              color: Colors.black12,
            ),

            //Room bt
            Container(
              width: size.width * 0.9,
              height: size.height * 0.08,
              //color: Colors.orange,
              alignment: Alignment.center,
              margin: const EdgeInsets.only(top: 10),
              padding: const EdgeInsets.only(left: 10),
              child: Row(
                children: [
                  const Text('Room',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  //for select room bt
                  TextButton(
                    onPressed: () {
                      roomNameController.clear();
                      //popup สำหรับแก้ไขห้องของอุปกรณ์
                      showDialog<String>(
                          context: context,
                          builder: (BuildContext context) => AlertDialog(
                              shape: const RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10))),
                              contentPadding: const EdgeInsets.only(bottom: 10),
                              title: Column(
                                children: [
                                  Row(
                                    children: [
                                      //back bt
                                      Container(
                                        width: 35,
                                        alignment: Alignment.centerLeft,
                                        child: TextButton(
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                          child: const Icon(
                                            Icons.arrow_back,
                                            size: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                      const Spacer(),
                                      const Text(
                                        'Select room',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600),
                                      ),
                                      const Spacer(),

                                      //ok bt
                                      Container(
                                        width: 35,
                                        alignment: Alignment.centerLeft,
                                        child: TextButton(
                                          onPressed: () {
                                            if (roomNameController.text != '') {
                                              setState(() {
                                                selectRoom =
                                                    roomNameController.text;
                                                editRoomDeviceApi(
                                                    roomNameController.text,
                                                    widget.serialNumber);
                                              });
                                            }

                                            Navigator.of(context).pop();
                                          },
                                          child: const Icon(
                                            Icons.check,
                                            size: 20,
                                            color: Colors.black,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  Container(
                                    width: size.width * 0.9,
                                    height: size.height * 0.06,
                                    alignment: Alignment.centerLeft,
                                    margin: const EdgeInsets.only(top: 15),
                                    decoration: BoxDecoration(
                                      color: Colors.black12,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    padding: const EdgeInsets.only(left: 10),
                                    child: TextField(
                                      maxLength: 30,
                                      controller: roomNameController,
                                      enableSuggestions: false,
                                      autocorrect: false,
                                      decoration: const InputDecoration(
                                        counterText: '',
                                        hintStyle: TextStyle(
                                            color: Colors.black38,
                                            fontSize: 21,
                                            fontWeight: FontWeight.w600),
                                        hintText: 'Room name',
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Container(
                                    width: size.width * 0.8,
                                    height: 2,
                                    color: Colors.black45,
                                  ),
                                ],
                              ),
                              content: Container(
                                width: size.width,
                                //height: size.height*0.5,
                                padding: const EdgeInsets.all(10),
                                //color: Colors.yellow,
                                child: Stack(
                                  children: [
                                    Container(
                                        padding:
                                            const EdgeInsets.only(left: 15),
                                        child: const Text(
                                          'Recommended room',
                                          style: TextStyle(
                                              fontSize: 21,
                                              color: Colors.black38),
                                        )),
                                    Container(
                                      margin: const EdgeInsets.only(top: 20),
                                      child: ListView.builder(
                                          shrinkWrap: true,
                                          itemCount: roomList.length,
                                          itemBuilder: (context, i) =>
                                              Container(
                                                width: size.width,
                                                height: size.height * 0.05,
                                                alignment: Alignment.centerLeft,
                                                padding: const EdgeInsets.only(
                                                    left: 15),
                                                child: TextButton(
                                                  style: TextButton.styleFrom(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  onPressed: () {
                                                    setState(() {
                                                      selectRoom = roomList[i]
                                                          .toString();
                                                      editRoomDeviceApi(
                                                          selectRoom,
                                                          widget.serialNumber);
                                                    });

                                                    Navigator.of(context).pop();
                                                  },
                                                  child: SizedBox(
                                                    width:size.width,
                                                    child: Text(
                                                      roomList[i],
                                                      textAlign: TextAlign.left,
                                                      style: const TextStyle(
                                                          fontSize: 21,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                ),
                                              )),
                                    ),
                                  ],
                                ),
                              )));
                    },
                    child: Row(
                      children: [
                        Container(
                            width: size.width * 0.6,
                            height: size.height * 0.074,
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(left: 5),
                            //color: Colors.yellow,
                            child: Text(
                              selectRoom ?? widget.roomName,
                              style: const TextStyle(
                                  color: Colors.black38,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600),
                            )),
                        //const Spacer(),
                        Container(
                            width: size.width * 0.055,
                            height: size.height * 0.074,
                            alignment: Alignment.centerRight,
                            //color: Colors.blue,
                            child: const Icon(
                              Icons.arrow_forward_ios,
                              size: 15,
                              color: Colors.black,
                            ))
                      ],
                    ),
                  )
                ],
              ),
            ),

            //เว้นว่าง
            const SizedBox(
              height: 30,
            ),

            //เว้นระยะห่าง
            const Spacer(),

            //deleted device bt
            Container(
              width: size.width * 0.8,
              height: size.height * 0.07,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Color.fromARGB(255, 223, 223, 223)),
              child: TextButton(
                  style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ))),
                  onPressed: () {
                    print('delete this house!');
                    popup_check();
                  },
                  child: const Text(
                    'Delete device',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Colors.red),
                  )),
            )
          ],
        ),
      ),
    );
  }

  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  if (move == 'move') {
                    //move to other page : main page
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const NavigationBottomBarWidget()));
                  } else {
                    Navigator.pop(context, 'Cancel');
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  popup_check() {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: const Text(
              'Do you want to delete this device?',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  //width: size.width,
                  alignment: Alignment.center,
                  child: TextButton(
                    onPressed: () {
                      //noting happen
                    },
                    child: const Text(
                      'Cancel',
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: Color.fromARGB(255, 117, 138, 214)),
                    ),
                  ),
                ),
                Container(
                  //width: size.width,
                  alignment: Alignment.center,
                  child: TextButton(
                    onPressed: () {
                      Navigator.pop(context, 'Cancel');
                      delDeviceApi(widget.serialNumber);
                    },
                    child: const Text(
                      'Ok',
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: Color.fromARGB(255, 117, 138, 214)),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}





// TextButton(
//               onPressed: () {
//                 deviceNameController.clear;
//                 showModalBottomSheet(
//                     isDismissible: false,
//                     shape: const RoundedRectangleBorder(
//                         borderRadius:
//                             BorderRadius.vertical(top: Radius.circular(25.0))),
//                     backgroundColor: Colors.white,
//                     context: context,
//                     isScrollControlled: true,
//                     builder: (BuildContext context) {
//                       return StatefulBuilder(
//                           builder: (BuildContext context, setState) {
//                         return Padding(
//                           padding: const EdgeInsets.symmetric(horizontal: 10),
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.center,
//                             mainAxisSize: MainAxisSize.min,
//                             children: <Widget>[
//                               Padding(
//                                 padding: const EdgeInsets.symmetric(
//                                     horizontal: 12.0),
//                                 child: Container(
//                                   width: size.width,
//                                   height: size.height * 0.08,
//                                   //color: Colors.red,
//                                   alignment: Alignment.center,
//                                   child: const Text(
//                                     'Edit device name',
//                                     style: TextStyle(
//                                         fontSize: 24,
//                                         fontWeight: FontWeight.w600),
//                                   ),
//                                 ),
//                               ),
//                               const SizedBox(
//                                 height: 10,
//                               ),
//                               Padding(
//                                 padding: const EdgeInsets.symmetric(
//                                     horizontal: 12.0),
//                                 child: Container(
//                                   width: size.width * 0.9,
//                                   height: size.height * 0.08,
//                                   alignment: Alignment.center,
//                                   //margin: const EdgeInsets.only(top: 15),
//                                   decoration: BoxDecoration(
//                                     color: Colors.black12,
//                                     borderRadius: BorderRadius.circular(20),
//                                   ),
//                                   padding: const EdgeInsets.only(
//                                       left: 20, right: 20),
//                                   child: TextField(
//                                     controller: deviceNameController,
//                                     onChanged: (text) {
//                                       setState(() {
//                                         //for check controller
//                                       });
//                                     },
//                                     //enableSuggestions: false,
//                                     //autocorrect: false,
//                                     decoration: const InputDecoration(
//                                       hintStyle: TextStyle(
//                                           color: Colors.black38,
//                                           fontSize: 24,
//                                           fontWeight: FontWeight.w600),
//                                       hintText: 'New device name',
//                                       border: InputBorder.none,
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                               const SizedBox(height: 10),
//                               Padding(
//                                   padding: EdgeInsets.only(
//                                       bottom: MediaQuery.of(context)
//                                           .viewInsets
//                                           .bottom),
//                                   child: Container(
//                                     width: size.width * 0.9,
//                                     height: size.height * 0.08,
//                                     alignment: Alignment.center,
//                                     //color: Colors.yellowAccent,
//                                     padding: const EdgeInsets.only(
//                                         left: 10, right: 10),
//                                     child: Row(
//                                       children: [
//                                         Container(
//                                           width: size.width * 0.38,
//                                           height: size.height * 0.07,
//                                           decoration: BoxDecoration(
//                                             borderRadius:
//                                                 BorderRadius.circular(20),
//                                             color: const Color.fromARGB(
//                                                 255, 189, 189, 189),
//                                           ),
//                                           child: TextButton(
//                                               style: ButtonStyle(
//                                                   shape: MaterialStateProperty
//                                                       .all<RoundedRectangleBorder>(
//                                                           RoundedRectangleBorder(
//                                                 borderRadius:
//                                                     BorderRadius.circular(20),
//                                               ))),
//                                               child: const Text(
//                                                 'Cancel',
//                                                 style: TextStyle(
//                                                     fontSize: 24,
//                                                     fontWeight: FontWeight.w600,
//                                                     color: Color.fromARGB(
//                                                         255, 35, 35, 35)),
//                                               ),
//                                               onPressed: () {
//                                                 Navigator.of(context).pop();
//                                               }),
//                                         ),
//                                         const Spacer(),
//                                         if (deviceNameController.text !=
//                                             '') ...{
//                                           Container(
//                                             width: size.width * 0.38,
//                                             height: size.height * 0.07,
//                                             decoration: BoxDecoration(
//                                               borderRadius:
//                                                   BorderRadius.circular(20),
//                                               color: const Color.fromARGB(
//                                                   255, 117, 138, 214),
//                                             ),
//                                             child: TextButton(
//                                                 style: ButtonStyle(
//                                                     shape: MaterialStateProperty
//                                                         .all<RoundedRectangleBorder>(
//                                                             RoundedRectangleBorder(
//                                                   borderRadius:
//                                                       BorderRadius.circular(20),
//                                                 ))),
//                                                 child: const Text(
//                                                   'Ok',
//                                                   style: TextStyle(
//                                                       fontSize: 24,
//                                                       fontWeight:
//                                                           FontWeight.w600,
//                                                       color: Colors.white),
//                                                 ),
//                                                 onPressed: () {
//                                                   //setstate
//                                                   setState(() {
//                                                     nameDevice =
//                                                         deviceNameController
//                                                             .text;
//                                                   });
//                                                   deviceNameController
//                                                       .clear(); //เปิด pop-up ใหม่จะรีค่า deviceNameController

//                                                   //close popup
//                                                   Navigator.of(context).pop();
//                                                 }),
//                                           ),
//                                         } else ...{
//                                           Container(
//                                             width: size.width * 0.38,
//                                             height: size.height * 0.07,
//                                             decoration: BoxDecoration(
//                                               borderRadius:
//                                                   BorderRadius.circular(20),
//                                               color: const Color.fromARGB(
//                                                   122, 117, 138, 214),
//                                             ),
//                                             child: TextButton(
//                                                 style: ButtonStyle(
//                                                     shape: MaterialStateProperty
//                                                         .all<RoundedRectangleBorder>(
//                                                             RoundedRectangleBorder(
//                                                   borderRadius:
//                                                       BorderRadius.circular(20),
//                                                 ))),
//                                                 child: const Text(
//                                                   'Ok',
//                                                   style: TextStyle(
//                                                       fontSize: 24,
//                                                       fontWeight:
//                                                           FontWeight.w600,
//                                                       color: Colors.white),
//                                                 ),
//                                                 onPressed: () {
//                                                   //notting
//                                                 }),
//                                           ),
//                                         }
//                                       ],
//                                     ),
//                                   )),
//                               const SizedBox(height: 10),
//                             ],
//                           ),
//                         );
//                       });
//                     });
//               },
//               child: Container(
//                 width: size.width * 0.9,
//                 height: size.height * 0.08,
//                 //color: Colors.orange,
//                 padding: const EdgeInsets.only(left: 10),
//                 alignment: Alignment.center,
//                 child: Row(children: [
//                   const Text('Name',
//                       style: TextStyle(
//                           fontSize: 24,
//                           fontWeight: FontWeight.w600,
//                           color: Colors.black)),
//                   const Spacer(),
//                   Text(nameDevice ?? 'Smart Plug',
//                       style: const TextStyle(
//                           fontSize: 24,
//                           fontWeight: FontWeight.w600,
//                           color: Colors.black38)),
//                   const SizedBox(
//                     width: 2,
//                   ),
//                   const Icon(
//                     Icons.arrow_forward_ios,
//                     size: 15,
//                     color: Colors.black,
//                   )
//                 ]),
//               ),
//             ),