import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/loginPage.dart';
import 'package:homeplus_phase1/page/profile/aboutPage.dart';
import 'package:homeplus_phase1/page/profile/changePasswordPage.dart';
import 'package:homeplus_phase1/page/profile/editProfilePage.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart'; //libary สำหรับเรียกใช้ค่าใน local Storage
import 'package:http/http.dart' as http; //libary สำหรับการเรียกใช้ api

//libary shared_preferences เป็นเหมือน ไลบารี่ที่ใช้เก็บค่าหรือเรียกใช้ค่าต่างๆ ใน local Storage มาใช้งาน

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  //ฟังก์ชั่นสำหรับเครีย local Storage หลัวจากกด  logout
  //ส่วนนี้เกี่ยวกับ user
  logoutClear(context) async {
    print('[logoutClear] start!');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var userId = prefs.getString('userId');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/setToken');
    try {
      http.Response response = await http.put(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": userId, "token": "", "setStatus": "logout"});

      print('[setToken] status Code : ${response.statusCode}');
      print('[setToken] response body : ${response.body}');

      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['message'].toString() == 'set token already!') {
        prefs.remove('userId'); //ลบค่าของ userId ที่มีใน local Storage
        //prefs.remove('demo'); //for demo
        prefs.remove('userName'); //ลบค่าของ userName ที่มีใน local Storage
        prefs.remove('goOutStatus'); //bg service check
        //prefs.remove('urlBase');

        //cookie for auto func
        prefs.remove('serialNumberAuto');
        prefs.remove('clientIDAuto');
        prefs.remove('tokenAuto');
        prefs.remove('numDeviceInHouse');
        prefs.remove('cancelAuto'); //checkการกดยกเลิกการทำงาน ฟังก์ชั่นอัตโนมัติ ถ้ากดยกเลิกเองจะไม่แสดงข้อมูลแจ้งเตือน

        //cookie for manageHouse
        prefs.remove('ownHouseUid');

        mainFirstHouseClear();
        //--------------------

        //หลังจากนั้น Navigator.pushReplacement ไปยังหน้า login (ไม่สามารถ navigator.pop หรือกดย้อนกลับมาได้)
        //go to login page
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => const LoginPage()));
      } else {
        //show pop-up
        popup('logout failed!\nSomething wrong.');
      }
    } catch (e) {
      print('[logoutClear] error: $e');
      //clear loading popup

      //show pop-up
      popup("Can't logout!\nConnection failed.");
    }
  }

  //ฟังก์ชั่นสำหรับเครีย local Storage หลัวจากกด  logout
  //ส่วนนี้จะเป็นส่วนเกี่ยวกับการจัดบ้าน
  mainFirstHouseClear() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //mainHouse หริอ mainNameHouse คือบ้่านที่เราเลือกให้แสดงในหน้า main page
    prefs.remove('mainHouseid'); //ลบค่าของ mainHouseid ที่มีใน local Storage
    prefs
        .remove('mainNameHouse'); //ลบค่าของ mainNameHouse ที่มีใน local Storage
    prefs.remove('mainHouseLat');
    prefs.remove('mainHouseLong');
  }

  //get username สำหรับการนำมาแสดงในหน้า profile page
  var userName;
  getUserName() async {
    print('[getUserName] Im in  getUserName');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userName = prefs
        .getString('userName'); //get ค่าของ userName ที่มีอยู่ใน local storage
    //print('[getUserId] userId: $userId');
    return userName.toString(); //return username ที่รับมาจาก local storage
  }

  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return FutureBuilder(
      // futureBuilder จะทำงานในฟัง์กชั่นที่เราต้องการก่อนจึงจะเริ่มสร้างหน้าแอป
      future:
          getUserName(), //จะเริ่มทำงานจากฟังก์ชั่นนีก่อนที่จะสร้างหน้าแอป ค่าที่ถูก return มาจากฟังก์ชั้นจะถูกเก็บไว้ใน snapshot
      builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
        //ค่าที่ถูก return มาจากฟังก์ชั้นจะถูกเก็บไว้ใน snapshot
        //เช้คว่า snapshot รับค่ามาจากฟังก์ชั่นแล้วหรือยัง
        if (snapshot.connectionState == ConnectionState.done) {
          //เมื่อ snapshot ได้รับค่าจากฟังก์ชั่น(ในกรณีคือรับ username มาจาก ฟังก์ชั่น)
          return Column(
            children: [
              //text "WELCOME" และ username
              Container(
                width: size.width,
                height: 150,
                //color: Colors.red,
                padding: const EdgeInsets.only(left: 30, right: 30, top: 55),
                alignment: Alignment.centerLeft,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'WELCOME',
                        style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      ),
                      Text(
                        snapshot
                            .data, //snapshot.data คือค่าที่รับมาจากฟังก์ชั่น ในที่นี้คือ username
                        style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      )
                    ]),
              ),

              //edit profile bt
              Container(
                width: size.width,
                height: 65,
                //color: Colors.red,
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10),
                          topLeft: Radius.circular(10)),
                    ),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                    //ทำการเปลี่ยนหน้าไปยังหน้า EditProfilePage
                    //ในที่นี้ใช้ Navigator.push ซึงหมายความว่าเราสามารถกดย้อนกลับมายังหน้านี้ได้ (สามารถ Navigator.pop กลับมาได้)
                    Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const EditProfilePage()))
                        .then((value) {
                      //ในส่วนของ then เมื่อเรา Navigator.pop หรือกดย้อนกลับมายังหน้านี้ จะทำการรีบิ้วหนึ่งรอบ
                      setState(() {});
                    });
                  },
                  child: Row(children: const [
                    Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      'Edit profile',
                      style: TextStyle(color: Colors.black),
                    ),
                    Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.black,
                    ),
                  ]),
                ),
              ),

              //change password bt
              Container(
                width: size.width,
                height: 65,
                //color: Colors.red,
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                    // shape: RoundedRectangleBorder(
                    //   borderRadius: BorderRadius.circular(10),
                    // ),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                    //ทำการเปลี่ยนหน้าไปยังหน้า ChangePasswordPage
                    //ในที่นี้ใช้ Navigator.push ซึงหมายความว่าเราสามารถกดย้อนกลับมายังหน้านี้ได้ (สามารถ Navigator.pop กลับมาได้)
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const ChangePasswordPage())).then((value) {
                      //ในส่วนของ then เมื่อเรา Navigator.pop หรือกดย้อนกลับมายังหน้านี้ จะทำการรีบิ้วหนึ่งรอบ
                      setState(() {});
                    });
                  },
                  child: Row(children: const [
                    Icon(
                      Icons.lock,
                      color: Colors.black,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      'Change password',
                      style: TextStyle(color: Colors.black),
                    ),
                    Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.black,
                    ),
                  ]),
                ),
              ),

              //Notification setting bt
              // Container(
              //   width: size.width,
              //   height: 65,
              //   //color: Colors.red,
              //   padding: const EdgeInsets.only(left: 20, right: 20),
              //   child: TextButton(
              //     style: TextButton.styleFrom(
              //       backgroundColor: const Color.fromARGB(255, 255, 255, 255),
              //       // shape: RoundedRectangleBorder(
              //       //   borderRadius: BorderRadius.circular(10),
              //       // ),
              //       foregroundColor: Colors.white,
              //       padding: const EdgeInsets.only(left: 20, right: 20),
              //       textStyle: const TextStyle(fontSize: 20),
              //     ),
              //     onPressed: () {
              //       //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
              //       //ทำการเปลี่ยนหน้าไปยังหน้า NotificationSettingPage
              //       //ในที่นี้ใช้ Navigator.push ซึงหมายความว่าเราสามารถกดย้อนกลับมายังหน้านี้ได้ (สามารถ Navigator.pop กลับมาได้)
              //       Navigator.push(
              //           context,
              //           MaterialPageRoute(
              //               builder: (context) =>
              //                   const NotificationSettingPage())).then((value) {
              //         //ในส่วนของ then เมื่อเรา Navigator.pop หรือกดย้อนกลับมายังหน้านี้ จะทำการรีบิ้วหนึ่งรอบ
              //         setState(() {});
              //       });
              //     },
              //     child: Row(children: const [
              //       Icon(
              //         Icons.notifications,
              //         color: Colors.black,
              //       ),
              //       SizedBox(
              //         width: 10,
              //       ),
              //       Text(
              //         'Notification setting',
              //         style: TextStyle(color: Colors.black),
              //       ),
              //       Spacer(),
              //       Icon(
              //         Icons.arrow_forward_ios_rounded,
              //         color: Colors.black,
              //       ),
              //     ]),
              //   ),
              // ),

              //access location bt
              Container(
                width: size.width,
                height: 65,
                //color: Colors.red,
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                    // shape: RoundedRectangleBorder(
                    //   borderRadius: BorderRadius.circular(10),
                    // ),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    openAppSettings();
                  },
                  child: const Row(children: [
                    Icon(
                      Icons.location_city,
                      color: Colors.black,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      'Location accession',
                      style: TextStyle(color: Colors.black),
                    ),
                    Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.black,
                    ),
                  ]),
                ),
              ),

              //about bt
              Container(
                width: size.width,
                height: 65,
                //color: Colors.red,
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10)),
                    ),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                    //ทำการเปลี่ยนหน้าไปยังหน้า AboutPage
                    //ในที่นี้ใช้ Navigator.push ซึงหมายความว่าเราสามารถกดย้อนกลับมายังหน้านี้ได้ (สามารถ Navigator.pop กลับมาได้)
                    Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const AboutPage()))
                        .then((value) {
                      //ในส่วนของ then เมื่อเรา Navigator.pop หรือกดย้อนกลับมายังหน้านี้ จะทำการรีบิ้วหนึ่งรอบ
                      setState(() {});
                    });
                  },
                  child: Row(children: const [
                    Icon(
                      Icons.phone_android,
                      color: Colors.black,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      'About',
                      style: TextStyle(color: Colors.black),
                    ),
                    Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.black,
                    ),
                  ]),
                ),
              ),

              //เว้นว่าง
              const SizedBox(
                height: 40,
              ),

              //logout bt
              Container(
                width: size.width,
                height: 65,
                //color: Colors.red,
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 255, 255),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                    //show pop up
                    showDialog<String>(
                      barrierDismissible: false,
                      context: context,
                      builder: (BuildContext context) => WillPopScope(
                        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
                        child: AlertDialog(
                          //title: const Text('Something is worng!'),
                          contentPadding: const EdgeInsets.only(
                              left: 20, right: 20, top: 20),
                          content: Container(
                            //width: size.width,
                            height: 80,
                            alignment: Alignment.center,
                            child: const Text(
                              'Confirm Logout?',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black),
                            ),
                          ),
                          actions: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                  //width: size.width,
                                  alignment: Alignment.center,
                                  child: TextButton(
                                    onPressed: () {
                                      Navigator.pop(context, 'Cancel');
                                    },
                                    child: const Text(
                                      'Cancel',
                                      style: TextStyle(
                                          fontSize: 24,
                                          fontWeight: FontWeight.w600,
                                          color: Color.fromARGB(
                                              255, 117, 138, 214)),
                                    ),
                                  ),
                                ),
                                Container(
                                  //width: size.width,
                                  alignment: Alignment.center,
                                  child: TextButton(
                                    onPressed: () {
                                      //ทำการเครีย localStorage
                                      loadingPopup(context);
                                      logoutClear(context);
                                      Navigator.pop(context, 'Cancel');
                                    },
                                    child: const Text(
                                      'Ok',
                                      style: TextStyle(
                                          fontSize: 24,
                                          fontWeight: FontWeight.w600,
                                          color: Color.fromARGB(
                                              255, 117, 138, 214)),
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  },
                  child: const Row(children: [
                    Icon(
                      Icons.logout,
                      color: Colors.black,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      'Logout',
                      style: TextStyle(color: Colors.black),
                    ),
                  ]),
                ),
              ),
            ],
          );
        } else {
          //ในขณะที่ futurebuilder กำลังทำงานเพื่อ return ค่ามายัง snapshot ตัวแอปจะเข้ามาทำงานในส่วนนี้ก่อน
          //ทำการ สร้าง loadingBox ขึ้นมาในขณะที่รอค่า snapshot
          return loadingBox();
        }
      },
    );
  }

  popup(text) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  //clear loading popup
                  Navigator.pop(context, 'Cancel');

                  //clear  popup
                  Navigator.pop(context, 'Cancel');
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //สำหรับ loading
  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(), //ตรงนี้เป็นตัวหมุนๆ ตอนกำลังโหลด
          SizedBox(height: 5),
          Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Loading...',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }

  loadingPopup(context) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.all(20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: const Text(
              'Loading...',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
        ),
      ),
    );
  }
}
