import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/loginPage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class ChangePasswordPage extends StatefulWidget {
  const ChangePasswordPage({super.key});

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  String url = "http://203.154.158.166/api";
  TextEditingController oldPasswordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  //show the password or not
  bool _isObscure0 = true; //old pass
  bool _isObscure = true; //new pass
  bool _isObscure2 = true; //confirm pass

  //Api function ------------------------------------------------------------------
  //change password api
  changePasswordApi(oldPass, newPass) async {
    String temp = await getUserId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/UpdateUserPass');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "userid": temp,
            "olduserPass": oldPass,
            "newUserPass": newPass //not sure
          });

      print('[changePasswordApi] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        print('[changePasswordApi] response.body: ${response.body}');
        print('[changePasswordApi] finsih!');
        //show pupup and go to login page
        //หลังจากเปลี่ยน password เสร็จจะทำการ logoutเพื่อให้ login ใหม่อีกครั้ง
        //ดังน้นจึงต้องเครีย localStorage
        logoutClear();
        mainFirstHouseClear();
        //จากนั้นเปลี่ยนไปยังหน้า login
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => const LoginPage()));
        popup('Change password is complete!\nPlease login again.',
            "null"); //แสดง popup แจ้งให้ทำการ login ใมห่
      } else {
        //old pass is incorrect will return 403 status code
        popup('Old password is incorrect.', 'null');
      }
    } catch (e) {
      //+เพิ่มpopup บอกว่ามันerror ไม่สามารถเปลี่ยน password ได้
      print('[changePasswordApi] error: $e');
    }
  }
  //----------------------------------------------------------------------------

  //localStorage function
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  logoutClear() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('userId');
    prefs.remove('demo'); //for demo
    prefs.remove('userName');
    prefs.remove('urlBase');
  }

  mainFirstHouseClear() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('mainHouseid');
    prefs.remove('mainNameHouse');
  }

  var userId;
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userId = prefs.getString('userId');
    //print('[getUserId] userId: $userId');
    return userId.toString();
    //prefs.setString('accessToken', token);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.of(context).pop(),
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow
        title: const Text('Change password',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: SingleChildScrollView(
          child: SizedBox(
        width: size.width,
        height: size.height * 0.85,
        //color: Colors.red,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //เว้นว่าง
            const SizedBox(
              height: 30,
            ),

            //old password
            //text "Old password"
            Container(
              padding: const EdgeInsets.only(left: 40, right: 40),
              child: const Text(
                'Old password',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
                textAlign: TextAlign.left,
              ),
            ),
            //text field old password
            Container(
              width: size.width,
              height: size.height * 0.08,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(
                  left: 40, right: 40, top: 10, bottom: 10),
              child: TextField(
                controller: oldPasswordController,
                obscureText: _isObscure0,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                      icon: Icon(_isObscure0
                          ? Icons.visibility_off
                          : Icons.visibility),
                      onPressed: () {
                        setState(() {
                          _isObscure0 = !_isObscure0;
                        });
                      }),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  prefixIcon: const Icon(
                    Icons.lock,
                    color: Colors.black,
                  ),
                  contentPadding: const EdgeInsets.only(left: 20),
                  hintText: 'Old password',
                  hintStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.black26),
                ),
              ),
            ),

            //เว้นว่าง
            const SizedBox(
              height: 30,
            ),

            //new password
            //text "New password"
            Container(
              padding: const EdgeInsets.only(left: 40, right: 40),
              child: const Text(
                'New password',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
                textAlign: TextAlign.left,
              ),
            ),
            //textfield new password
            Container(
              width: size.width,
              height: size.height * 0.08,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(
                  left: 40, right: 40, top: 10, bottom: 10),
              child: TextField(
                controller: newPasswordController,
                obscureText: _isObscure,
                decoration: InputDecoration(
                  //this button is used to toggle the password visibility
                  suffixIcon: IconButton(
                      icon: Icon(
                          _isObscure ? Icons.visibility_off : Icons.visibility),
                      onPressed: () {
                        setState(() {
                          _isObscure = !_isObscure;
                        });
                      }),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  prefixIcon: const Icon(
                    Icons.lock,
                    color: Colors.black,
                  ),
                  contentPadding: const EdgeInsets.only(left: 20),
                  hintText: 'New password',
                  hintStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.black26),
                ),
              ),
            ),

            //textfiled Confirm Password
            Container(
              width: size.width,
              height: size.height * 0.08,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(
                  left: 40, right: 40, top: 10, bottom: 10),
              child: TextField(
                controller: confirmPasswordController,
                obscureText: _isObscure2,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                      icon: Icon(_isObscure2
                          ? Icons.visibility_off
                          : Icons.visibility),
                      onPressed: () {
                        setState(() {
                          _isObscure2 = !_isObscure2;
                        });
                      }),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  prefixIcon: const Icon(
                    Icons.lock,
                    color: Colors.black,
                  ),
                  contentPadding: const EdgeInsets.only(left: 20),
                  hintText: 'Confirm Password',
                  hintStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.black26),
                ),
              ),
            ),

            //เว้นระะยะห่าง
            const Spacer(),

            //ปุ่ม
            Container(
              width: size.width,
              height: size.height * 0.06,
              alignment: Alignment.center,
              // color: Colors.yellow,
              child: SizedBox(
                width: size.width * 0.3,
                height: size.height * 0.06,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.zero,
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    //เช้คว่า textfield ทั้งหมด กรอกครบหรือไม่
                    if (oldPasswordController.text != '' &&
                        newPasswordController.text != '' &&
                        confirmPasswordController.text != '') {
                      //เช้คว่า new password กับ confirm password เหมือนกันไหม
                      if (newPasswordController.text ==
                          confirmPasswordController.text) {
                        //เช้คว่า newpassword กับ oldpassword เหมือนกันหรือไม่
                        if (oldPasswordController.text !=
                            newPasswordController.text) {
                          //call api change password and logout
                          //สร้าง popup ยืนยันว่าจะเปลี่ยน password
                          showDialog<String>(
                            barrierDismissible: false,
                            context: context,
                            builder: (BuildContext context) => AlertDialog(
                              //title: const Text('Something is worng!'),
                              contentPadding: const EdgeInsets.only(
                                  left: 20, right: 20, top: 20),
                              content: Container(
                                //width: size.width,
                                height: 80,
                                alignment: Alignment.center,
                                child: const Text(
                                  'Do you want to change your password?',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.black),
                                ),
                              ),
                              actions: <Widget>[
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Container(
                                      //width: size.width,
                                      alignment: Alignment.center,
                                      child: TextButton(
                                        onPressed: () {
                                          Navigator.pop(context, 'Cancel');
                                        },
                                        child: const Text(
                                          'Cancel',
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600,
                                              color: Color.fromARGB(
                                                  255, 117, 138, 214)),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      //width: size.width,
                                      alignment: Alignment.center,
                                      child: TextButton(
                                        onPressed: () {
                                          //call api change email.com
                                          changePasswordApi(
                                              oldPasswordController.text,
                                              newPasswordController.text);
                                          Navigator.pop(context, 'ok');
                                        },
                                        child: const Text(
                                          'Ok',
                                          style: TextStyle(
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600,
                                              color: Color.fromARGB(
                                                  255, 117, 138, 214)),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          );
                        } else {
                          popup("Old password and new password is the same.",
                              'null');
                        }
                      } else {
                        popup("Password don't match.", 'null');
                      }
                    } else {
                      popup('Please complete the information.', 'null');
                    }
                    // Navigator.pushReplacement(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) =>
                    //             const NavigationBottomBarWidget()));
                  },
                  child: const Text(
                    'Change',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'FCfont',
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      )),
    );
  }

  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  if (move == 'move') {
                    //move to other page : main page
                    logoutClear();
                    mainFirstHouseClear();
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginPage()));
                  } else {
                    Navigator.pop(context, 'Cancel');
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
