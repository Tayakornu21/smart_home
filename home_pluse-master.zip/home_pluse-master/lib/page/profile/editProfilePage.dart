import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/loginPage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  //String url = "http://203.154.158.166/api";
  String? email;
  TextEditingController userNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  //Api function----------------------------------------------------------------
  //api change username
  changeUsernameApi(newUsername) async {
    String temp = await getUserId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/UpdateUsername');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "userid": temp,
            "userName": newUsername,
          });

      //print('[getHouseListApi] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        print('[changeUsernameApi] response.body: ${response.body}');
        //set new username to localstorage
        //หลังจากเปลี่ยน username ใหม่ก้จะบันทึก username ใหม่ลง local storage
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString('userName', newUsername.toString());
        //+เพิ่มpopup บอกว่าแก้ไข username เสร้จเรียบร้อย
        print('[changeUsernameApi] finsih!');
      }
    } catch (e) {
      //+เพิ่มpopup บอกว่ามันerror ไม่สามารถแก้ไข unsername ได้
      print('[changeUsernameApi] error: $e');
    }
  }

  //api check gmail and auto logout(ยังไม่ได้ทำ)

  //----------------------------------------------------------------------------

//localStorage function--------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //clear local storage
  logoutClear() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('userId');
    //prefs.remove('demo'); //for demo
    prefs.remove('userName');
    prefs.remove('urlBase');
  }

  mainFirstHouseClear() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('mainHouseid');
    prefs.remove('mainNameHouse');
  }

  //get userId for change username
  var userId; //check login
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userId = prefs.getString('userId');
    //print('[getUserId] userId: $userId');
    return userId.toString();
    //prefs.setString('accessToken', token);
  }

  //get gmail and username form localstorage
  //get username
  var userName; //check login
  var tempUn;
  getUserName() async {
    print('[getUserName] Im in  getUserName');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userName = prefs.getString('userName');
    //print('[getUserId] userId: $userId');
    return userName.toString();
    //prefs.setString('accessToken', token);
  }

  //============================================================================

  var un; //username
  @override
  void initState() {
    super.initState();
    un = getUserName();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.of(context).pop(),
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow
        title: const Text('Edit profile',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: SingleChildScrollView(
        child: Container(
            width: size.width,
            height: size.height * 0.8,
            child: FutureBuilder(
              future: un, //ทำฟังก์ชั่นนี้ก่อนจะสร้างหน้าแอปในส่วนของ builder
              builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  return Column(
                    children: [
                      //username
                      Container(
                        width: size.width * 0.9,
                        height: size.height * 0.07,
                        //color: Colors.orange,
                        padding: const EdgeInsets.only(left: 10),
                        alignment: Alignment.center,
                        child: Row(
                          children: [
                            const Text('Username',
                                style: TextStyle(
                                    fontSize: 24, fontWeight: FontWeight.w600)),
                            const Spacer(),
                            TextButton(
                              onPressed: () {
                                userNameController
                                    .clear(); //เครีย userNameController ก่อนจะได้ไม่มีค่าค้างไว้หลังจากเราเปิด ป้อปอัพสำหรับใส่ชื้่อใหม่ของ username
                                //เปิดป้อปอัพสำหรับการใส่ username ใหม่
                                showModalBottomSheet(
                                    isDismissible: false,
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.vertical(
                                            top: Radius.circular(25.0))),
                                    backgroundColor: Colors.white,
                                    context: context,
                                    isScrollControlled: true,
                                    builder: (BuildContext context) {
                                      return StatefulBuilder(builder:
                                          (BuildContext context, setState) {
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            children: <Widget>[
                                              //text "New username"
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 12.0),
                                                child: Container(
                                                  width: size.width,
                                                  height: size.height * 0.08,
                                                  //color: Colors.red,
                                                  alignment: Alignment.center,
                                                  child: const Text(
                                                    'New username',
                                                    style: TextStyle(
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600),
                                                  ),
                                                ),
                                              ),

                                              //เว้นว่าง
                                              const SizedBox(
                                                height: 10,
                                              ),

                                              //textfield สำหรับกรอก username ใหม่
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 12.0),
                                                child: Container(
                                                  width: size.width * 0.9,
                                                  height: size.height * 0.08,
                                                  alignment: Alignment.center,
                                                  //margin: const EdgeInsets.only(top: 15),
                                                  decoration: BoxDecoration(
                                                    color: Colors.black12,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ),
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 20, right: 20),
                                                  child: TextField(
                                                    maxLength: 30,
                                                    controller:
                                                        userNameController, //อาจจะไม่ได้ใช้
                                                    onChanged: (text) {
                                                      setState(() {
                                                        //for check controller
                                                      });
                                                    },
                                                    enableSuggestions: false,
                                                    autocorrect: false,
                                                    decoration:
                                                        const InputDecoration(
                                                      counterText: '',
                                                      hintStyle: TextStyle(
                                                          color: Colors.black38,
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600),
                                                      hintText: 'New username',
                                                      border: InputBorder.none,
                                                    ),
                                                  ),
                                                ),
                                              ),

                                              //เว้นว่าง
                                              const SizedBox(height: 10),

                                              //ปุ่ม
                                              Padding(
                                                  padding: EdgeInsets.only(
                                                      bottom:
                                                          MediaQuery.of(context)
                                                              .viewInsets
                                                              .bottom),
                                                  child: Container(
                                                    width: size.width * 0.9,
                                                    height: size.height * 0.08,
                                                    alignment: Alignment.center,
                                                    //color: Colors.yellowAccent,
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 10,
                                                            right: 10),
                                                    child: Row(
                                                      children: [
                                                        //ปุ่มยกเลิก
                                                        Container(
                                                          width:
                                                              size.width * 0.38,
                                                          height: size.height *
                                                              0.07,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20),
                                                            color: const Color
                                                                    .fromARGB(
                                                                255,
                                                                189,
                                                                189,
                                                                189),
                                                          ),
                                                          child: TextButton(
                                                              style:
                                                                  ButtonStyle(
                                                                      shape: MaterialStateProperty.all<
                                                                              RoundedRectangleBorder>(
                                                                          RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            20),
                                                              ))),
                                                              child: const Text(
                                                                'Cancel',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        24,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                    color: Color
                                                                        .fromARGB(
                                                                            255,
                                                                            35,
                                                                            35,
                                                                            35)),
                                                              ),
                                                              onPressed: () {
                                                                Navigator.of(
                                                                        context)
                                                                    .pop(); //ปิด popup เปลี่ยนชื่อusername
                                                              }),
                                                        ),

                                                        //เว้นระยะห่าง
                                                        const Spacer(),

                                                        //ปุ่มตกลง จะมีการเช็คว่า textfield ได้กรอกอะไรเข้าไปหรือยัง
                                                        //ถ้ากรอกแล้วจะสามารถกดปุ่มตกลงได้
                                                        if (userNameController
                                                                .text !=
                                                            '') ...{
                                                          //ปุ่มที่กดได้
                                                          Container(
                                                            width: size.width *
                                                                0.38,
                                                            height:
                                                                size.height *
                                                                    0.07,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          20),
                                                              color: const Color
                                                                      .fromARGB(
                                                                  255,
                                                                  117,
                                                                  138,
                                                                  214),
                                                            ),
                                                            child: TextButton(
                                                                style:
                                                                    ButtonStyle(
                                                                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                                                            RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              20),
                                                                ))),
                                                                child:
                                                                    const Text(
                                                                  'Ok',
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          24,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      color: Colors
                                                                          .white),
                                                                ),
                                                                onPressed: () {
                                                                  //setstate
                                                                  setState(() {
                                                                    //ให้ tempUn = username ใหม่ที่กรอกเข้าไป
                                                                    //เพราะว่าเราจะใช้ tempUn Username ในหน้านี้
                                                                    tempUn =
                                                                        userNameController
                                                                            .text;
                                                                    //call api change username function
                                                                    //set new username to local storage too
                                                                    //เรียกใช้ function เปลี่ยน username
                                                                    changeUsernameApi(
                                                                        tempUn);
                                                                  });

                                                                  //close popup
                                                                  Navigator.of(
                                                                          context)
                                                                      .pop();
                                                                }),
                                                          ),
                                                        } else ...{
                                                          //ปุ่มที่กดไม่ได้
                                                          Container(
                                                            width: size.width *
                                                                0.38,
                                                            height:
                                                                size.height *
                                                                    0.07,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          20),
                                                              color: const Color
                                                                      .fromARGB(
                                                                  122,
                                                                  117,
                                                                  138,
                                                                  214),
                                                            ),
                                                            child: TextButton(
                                                                style:
                                                                    ButtonStyle(
                                                                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                                                            RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              20),
                                                                ))),
                                                                child:
                                                                    const Text(
                                                                  'Ok',
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          24,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      color: Colors
                                                                          .white),
                                                                ),
                                                                onPressed: () {
                                                                  //notting
                                                                }),
                                                          ),
                                                        }
                                                      ],
                                                    ),
                                                  )),

                                              //เว้นว่าง
                                              const SizedBox(height: 10),
                                            ],
                                          ),
                                        );
                                      });
                                    }).then((value) {
                                  setState(
                                      () {}); //รีบิ้วหนึ่งครั้งหลังจากปิด popupu นี้
                                });
                              },
                              child: Row(
                                children: [
                                  Container(
                                      width: size.width * 0.5,
                                      height: size.height * 0.074,
                                      alignment: Alignment.centerRight,
                                      padding: const EdgeInsets.only(left: 5),
                                      //color: Colors.yellow,
                                      child: Text(
                                        //เห็นได้ว่าเราจะให้แสดง tempUn แต่ถ้า tempUn เป็นค่าว่างจะให้แสดง userName ที่รับมาจาก localStorage แทน
                                        //ซึ่งค่า tempUn จะเกิดขึ้นได้เมื่อเรามีการเปลี่ยน username ใหม่
                                        tempUn ?? userName,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                            color: Colors.black38,
                                            fontSize: 24),
                                      )),
                                  //const Spacer(),
                                  Container(
                                      width: size.width * 0.055,
                                      height: size.height * 0.074,
                                      alignment: Alignment.centerRight,
                                      //color: Colors.blue,
                                      child: const Icon(
                                        Icons.arrow_forward_ios,
                                        size: 15,
                                        color: Colors.black,
                                      ))
                                ],
                              ),
                            )
                          ],
                        ),
                      ),

                      //ส่วนของการเปลี่ยน email (ยังหาข้อสรุปไม่ได้มันอาจจะเกิด error ถ้าเปลี่ยน eamil)
                      // //email
                      // Container(
                      //   width: size.width * 0.9,
                      //   height: size.height * 0.07,
                      //   //color: Colors.orange,
                      //   padding: const EdgeInsets.only(left: 10),
                      //   alignment: Alignment.center,
                      //   child: Row(
                      //     children: [
                      //       const Text('Email',
                      //           style: TextStyle(
                      //               fontSize: 24, fontWeight: FontWeight.w600)),
                      //       const Spacer(),
                      //       TextButton(
                      //         onPressed: () {
                      //           emailController.clear();
                      //           showModalBottomSheet(
                      //               isDismissible: false,
                      //               shape: const RoundedRectangleBorder(
                      //                   borderRadius: BorderRadius.vertical(
                      //                       top: Radius.circular(25.0))),
                      //               backgroundColor: Colors.white,
                      //               context: context,
                      //               isScrollControlled: true,
                      //               builder: (BuildContext context) {
                      //                 return StatefulBuilder(builder:
                      //                     (BuildContext context, setState) {
                      //                   return Padding(
                      //                     padding: const EdgeInsets.symmetric(
                      //                         horizontal: 10),
                      //                     child: Column(
                      //                       crossAxisAlignment:
                      //                           CrossAxisAlignment.center,
                      //                       mainAxisSize: MainAxisSize.min,
                      //                       children: <Widget>[
                      //                         Padding(
                      //                           padding:
                      //                               const EdgeInsets.symmetric(
                      //                                   horizontal: 12.0),
                      //                           child: Container(
                      //                             width: size.width,
                      //                             height: size.height * 0.08,
                      //                             //color: Colors.red,
                      //                             alignment: Alignment.center,
                      //                             child: const Text(
                      //                               'New email',
                      //                               style: TextStyle(
                      //                                   fontSize: 24,
                      //                                   fontWeight:
                      //                                       FontWeight.w600),
                      //                             ),
                      //                           ),
                      //                         ),
                      //                         const SizedBox(
                      //                           height: 10,
                      //                         ),
                      //                         Padding(
                      //                           padding:
                      //                               const EdgeInsets.symmetric(
                      //                                   horizontal: 12.0),
                      //                           child: Container(
                      //                             width: size.width * 0.9,
                      //                             height: size.height * 0.08,
                      //                             alignment: Alignment.center,
                      //                             //margin: const EdgeInsets.only(top: 15),
                      //                             decoration: BoxDecoration(
                      //                               color: Colors.black12,
                      //                               borderRadius:
                      //                                   BorderRadius.circular(
                      //                                       20),
                      //                             ),
                      //                             padding:
                      //                                 const EdgeInsets.only(
                      //                                     left: 20, right: 20),
                      //                             child: TextField(
                      //                               controller:
                      //                                   emailController, //อาจจะไม่ได้ใช้
                      //                               onChanged: (text) {
                      //                                 setState(() {
                      //                                   //for check controller
                      //                                 });
                      //                               },
                      //                               enableSuggestions: false,
                      //                               autocorrect: false,
                      //                               decoration:
                      //                                   const InputDecoration(
                      //                                 hintStyle: TextStyle(
                      //                                     color: Colors.black38,
                      //                                     fontSize: 24,
                      //                                     fontWeight:
                      //                                         FontWeight.w600),
                      //                                 hintText: 'New email',
                      //                                 border: InputBorder.none,
                      //                               ),
                      //                             ),
                      //                           ),
                      //                         ),
                      //                         const SizedBox(height: 10),
                      //                         Padding(
                      //                             padding: EdgeInsets.only(
                      //                                 bottom:
                      //                                     MediaQuery.of(context)
                      //                                         .viewInsets
                      //                                         .bottom),
                      //                             child: Container(
                      //                               width: size.width * 0.9,
                      //                               height: size.height * 0.08,
                      //                               alignment: Alignment.center,
                      //                               //color: Colors.yellowAccent,
                      //                               padding:
                      //                                   const EdgeInsets.only(
                      //                                       left: 10,
                      //                                       right: 10),
                      //                               child: Row(
                      //                                 children: [
                      //                                   Container(
                      //                                     width:
                      //                                         size.width * 0.38,
                      //                                     height: size.height *
                      //                                         0.07,
                      //                                     decoration:
                      //                                         BoxDecoration(
                      //                                       borderRadius:
                      //                                           BorderRadius
                      //                                               .circular(
                      //                                                   20),
                      //                                       color: const Color
                      //                                               .fromARGB(
                      //                                           255,
                      //                                           189,
                      //                                           189,
                      //                                           189),
                      //                                     ),
                      //                                     child: TextButton(
                      //                                         style:
                      //                                             ButtonStyle(
                      //                                                 shape: MaterialStateProperty.all<
                      //                                                         RoundedRectangleBorder>(
                      //                                                     RoundedRectangleBorder(
                      //                                           borderRadius:
                      //                                               BorderRadius
                      //                                                   .circular(
                      //                                                       20),
                      //                                         ))),
                      //                                         child: const Text(
                      //                                           'Cancel',
                      //                                           style: TextStyle(
                      //                                               fontSize:
                      //                                                   24,
                      //                                               fontWeight:
                      //                                                   FontWeight
                      //                                                       .w600,
                      //                                               color: Color
                      //                                                   .fromARGB(
                      //                                                       255,
                      //                                                       35,
                      //                                                       35,
                      //                                                       35)),
                      //                                         ),
                      //                                         onPressed: () {
                      //                                           Navigator.of(
                      //                                                   context)
                      //                                               .pop();
                      //                                         }),
                      //                                   ),
                      //                                   const Spacer(),

                      //                                   if (emailController
                      //                                           .text !=
                      //                                       '') ...{
                      //                                     Container(
                      //                                       width: size.width *
                      //                                           0.38,
                      //                                       height:
                      //                                           size.height *
                      //                                               0.07,
                      //                                       decoration:
                      //                                           BoxDecoration(
                      //                                         borderRadius:
                      //                                             BorderRadius
                      //                                                 .circular(
                      //                                                     20),
                      //                                         color: const Color
                      //                                                 .fromARGB(
                      //                                             255,
                      //                                             117,
                      //                                             138,
                      //                                             214),
                      //                                       ),
                      //                                       child: TextButton(
                      //                                           style:
                      //                                               ButtonStyle(
                      //                                                   shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      //                                                       RoundedRectangleBorder(
                      //                                             borderRadius:
                      //                                                 BorderRadius
                      //                                                     .circular(
                      //                                                         20),
                      //                                           ))),
                      //                                           child:
                      //                                               const Text(
                      //                                             'Ok',
                      //                                             style: TextStyle(
                      //                                                 fontSize:
                      //                                                     24,
                      //                                                 fontWeight:
                      //                                                     FontWeight
                      //                                                         .w600,
                      //                                                 color: Colors
                      //                                                     .white),
                      //                                           ),
                      //                                           onPressed: () {
                      //                                             //setstate
                      //                                             //show popup confirm change email
                      //                                             //call api change email function
                      //                                             //logout
                      //                                             if (!RegExp(
                      //                                                     r'\S+@\S+\.\S+')
                      //                                                 .hasMatch(
                      //                                                     emailController
                      //                                                         .text)) {
                      //                                               //ที่อยู่อีเมลไม่ถูกต้อง
                      //                                               popup(
                      //                                                   'Invalid email address\nPlease try again.',
                      //                                                   'null');
                      //                                             } else {
                      //                                               showDialog<
                      //                                                   String>(
                      //                                                 barrierDismissible:
                      //                                                     false,
                      //                                                 context:
                      //                                                     context,
                      //                                                 builder: (BuildContext
                      //                                                         context) =>
                      //                                                     AlertDialog(
                      //                                                   //title: const Text('Something is worng!'),
                      //                                                   contentPadding: const EdgeInsets.only(
                      //                                                       left:
                      //                                                           20,
                      //                                                       right:
                      //                                                           20,
                      //                                                       top:
                      //                                                           20),
                      //                                                   content:
                      //                                                       Container(
                      //                                                     //width: size.width,
                      //                                                     height:
                      //                                                         80,
                      //                                                     alignment:
                      //                                                         Alignment.center,
                      //                                                     child:
                      //                                                         const Text(
                      //                                                       'Do you want to change your email?',
                      //                                                       textAlign:
                      //                                                           TextAlign.center,
                      //                                                       style: TextStyle(
                      //                                                           fontSize: 24,
                      //                                                           fontWeight: FontWeight.w600,
                      //                                                           color: Colors.black),
                      //                                                     ),
                      //                                                   ),
                      //                                                   actions: <
                      //                                                       Widget>[
                      //                                                     Row(
                      //                                                       mainAxisAlignment:
                      //                                                           MainAxisAlignment.end,
                      //                                                       children: [
                      //                                                         Container(
                      //                                                           //width: size.width,
                      //                                                           alignment: Alignment.center,
                      //                                                           child: TextButton(
                      //                                                             onPressed: () {
                      //                                                               Navigator.pop(context, 'Cancel');
                      //                                                             },
                      //                                                             child: const Text(
                      //                                                               'Cancel',
                      //                                                               style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Color.fromARGB(255, 117, 138, 214)),
                      //                                                             ),
                      //                                                           ),
                      //                                                         ),
                      //                                                         Container(
                      //                                                           //width: size.width,
                      //                                                           alignment: Alignment.center,
                      //                                                           child: TextButton(
                      //                                                             onPressed: () {
                      //                                                               //call api change email.com
                      //                                                               Navigator.pop(context, 'ok');
                      //                                                             },
                      //                                                             child: const Text(
                      //                                                               'Ok',
                      //                                                               style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Color.fromARGB(255, 117, 138, 214)),
                      //                                                             ),
                      //                                                           ),
                      //                                                         ),
                      //                                                       ],
                      //                                                     )
                      //                                                   ],
                      //                                                 ),
                      //                                               );

                      //                                               // //close popup
                      //                                               // Navigator.of(
                      //                                               //       context)
                      //                                               //   .pop();
                      //                                             }

                      //                                           }),
                      //                                     ),
                      //                                   } else ...{
                      //                                     Container(
                      //                                       width: size.width *
                      //                                           0.38,
                      //                                       height:
                      //                                           size.height *
                      //                                               0.07,
                      //                                       decoration:
                      //                                           BoxDecoration(
                      //                                         borderRadius:
                      //                                             BorderRadius
                      //                                                 .circular(
                      //                                                     20),
                      //                                         color: const Color
                      //                                                 .fromARGB(
                      //                                             122,
                      //                                             117,
                      //                                             138,
                      //                                             214),
                      //                                       ),
                      //                                       child: TextButton(
                      //                                           style:
                      //                                               ButtonStyle(
                      //                                                   shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      //                                                       RoundedRectangleBorder(
                      //                                             borderRadius:
                      //                                                 BorderRadius
                      //                                                     .circular(
                      //                                                         20),
                      //                                           ))),
                      //                                           child:
                      //                                               const Text(
                      //                                             'Ok',
                      //                                             style: TextStyle(
                      //                                                 fontSize:
                      //                                                     24,
                      //                                                 fontWeight:
                      //                                                     FontWeight
                      //                                                         .w600,
                      //                                                 color: Colors
                      //                                                     .white),
                      //                                           ),
                      //                                           onPressed: () {
                      //                                             //notting
                      //                                           }),
                      //                                     ),
                      //                                   }
                      //                                 ],
                      //                               ),
                      //                             )),
                      //                         const SizedBox(height: 10),
                      //                       ],
                      //                     ),
                      //                   );
                      //                 });
                      //               });
                      //         },
                      //         child: Row(
                      //           children: [
                      //             Container(
                      //                 width: size.width * 0.5,
                      //                 height: size.height * 0.074,
                      //                 alignment: Alignment.centerRight,
                      //                 padding: const EdgeInsets.only(left: 5),
                      //                 //color: Colors.yellow,
                      //                 child: Text(
                      //                   email ?? 'email@gmail.com',
                      //                   overflow: TextOverflow.ellipsis,
                      //                   style: const TextStyle(
                      //                       color: Colors.black38,
                      //                       fontSize: 24),
                      //                 )),
                      //             //const Spacer(),
                      //             Container(
                      //                 width: size.width * 0.055,
                      //                 height: size.height * 0.074,
                      //                 alignment: Alignment.centerRight,
                      //                 //color: Colors.blue,
                      //                 child: const Icon(
                      //                   Icons.arrow_forward_ios,
                      //                   size: 15,
                      //                   color: Colors.black,
                      //                 ))
                      //           ],
                      //         ),
                      //       )
                      //     ],
                      //   ),
                      // ),
                    ],
                  );
                } else {
                  return loadingBox();
                }
              },
            )),
      ),
    );
  }

  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Loading...',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }

  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  if (move == 'move') {
                    //move to other page : main page
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginPage()));
                  } else {
                    Navigator.pop(context, 'Cancel');
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
