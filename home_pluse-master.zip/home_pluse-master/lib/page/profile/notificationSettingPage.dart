import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';

class NotificationSettingPage extends StatefulWidget {
  const NotificationSettingPage({super.key});

  @override
  State<NotificationSettingPage> createState() =>
      _NotificationSettingPageState();
}

class _NotificationSettingPageState extends State<NotificationSettingPage> {
  bool status1 = false;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.of(context).pop(),
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow
        title: const Text('Notificaition setting',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: SizedBox(
        width: size.width,
        height: size.height * 0.8,
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Container(
              width: size.width,
              height: size.height * 0.08,
              //color: Colors.red,
              padding: const EdgeInsets.only(left: 40,right: 40),
              alignment: Alignment.center,
              child: Row(
                children: [
                  const Text(
                    'Notification',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Colors.black),
                  ),
                  const Spacer(),
                  FlutterSwitch(
                    width: 70,
                    height: 30,
                    valueFontSize: 15.0,
                    toggleSize: 25.0,
                    value: status1,
                    borderRadius: 30.0,
                    padding: 8.0,
                    showOnOff: true,
                    activeColor: Color.fromARGB(255, 117, 138, 214),
                    onToggle: (val) {
                      setState(() {
                        status1 = val;
                        if (status1 == true) {
                          print('noti :on');
                          //_sendHTTP_NETPIE_Relay1_On();
                        } else if (status1 == false) {
                          print('noti :off');
                          //_sendHTTP_NETPIE_Relay1_Off();
                        }
                      });
                    },
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
