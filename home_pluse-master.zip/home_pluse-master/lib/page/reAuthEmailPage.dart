import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/loginPage.dart';
import 'package:shared_preferences/shared_preferences.dart';

//ไฟล์นี้จะเป็นการส่ง Re email ยินยันอีเมล เนื่องจากตอนเราสมัครเสร็จเราจะต้องยืนยันอีเมลก่อนจึงจะสามารถใช้งานได้
//โดยปกติหลังจากสมัครเสร็จจะมีอีเมลยืนยันส่งไปยังอีเมลที่สมัครโดยอัตโนมัติอยู่แล้ว
//แต่หน้านี้จะเป็นรีส่งอีเมลยืนยันอีกครั้งในกรณีที่หาอีเมลยินยันครั้งแรกไม่เจอหรือเกิด error อะไรขึ่้น
class ReAuthEmailPage extends StatefulWidget {
  const ReAuthEmailPage({super.key});

  @override
  State<ReAuthEmailPage> createState() => _ReAuthEmailPageState();
}

class _ReAuthEmailPageState extends State<ReAuthEmailPage> {
  //String url = "http://203.154.158.166/api"; //url ของ api
  //String url = "http://10.58.248.116:3000";

  //ตัวแปรสำหรับการรับค่าจาก Textfield
  TextEditingController gmailController = TextEditingController(); //email

  //API function
  resendEmail(email) async {
    print('[resendEmail] Im in resendEmail function');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/ReAuthenEmail'); //ประกาศตัวแปร url
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type":
                "application/x-www-form-urlencoded", //ชนิดของ body ที่จะส่งไป
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "email": email, //body ที่ส่งไปคือ email
          });
      print('[resendEmail] status Code : ${response.statusCode}');
      print('[resendEmail] response body: ${response.body}');

      //เรา decode response ที่รับกลับมาให่เป็นภาษา dart เพื่อที่เราจะสามารถใช้งานค่าเหล่านั้นได้
      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)
      if (jsonResponse['error'] == false) {
        //เช้คว่าค่าที่รับมาในส่วนของ error มีค่าตามนี้รึป่าว
        //re senc email complete จะแสดง popup และกลับไปยังหน้า login
        popup('The confirmation email was sent successfully.', 'move');
      } else {
        //กรณี error = true จะแสดง popup แจ้งเตือน
        popup('Resend failed!\nPlease try again.', 'null');
      }
    } catch (e) {
      print('[resendEmail] error : $e');
      //กรณีจะเกิดขึ่นได้เมื่อเซิฟเวอร์ล้มหรือไม่ก็เน็ตของเราไม่ดี
      popup('Something is wrong!\nPlease try again.', 'null');
    }
  }

  //localStorage function
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        const LoginPage())), //appBar show back bt for come back to login page
          ),
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow of appbar
          iconTheme:
              const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: Container(
          width: size.width,
          height: size.height,
          color: Colors.white,
          child: Column(
              // mainAxisAlignment: MainAxisAlignment.start,
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //เว้นช่องว่าง
                SizedBox(
                  width: size.width,
                  height: size.height * 0.12,
                  //color: Colors.red,
                ),

                //text "Resend confirm email"
                Container(
                    width: size.width,
                    height: size.height * 0.08,
                    //color: Colors.yellow,
                    alignment: Alignment.center,
                    child: const Text(
                      'Resend confirm email',
                      style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w600,
                          color: Color.fromARGB(255, 117, 138, 214)),
                    )),

                //text "Enter your registered email address."
                Container(
                    width: size.width,
                    height: size.height * 0.05,
                    //color: Colors.yellow,
                    alignment: Alignment.topCenter,
                    child: const Text(
                      'Enter your registered email address.',
                      style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w600,
                          color: Colors.black38),
                    )),

                //textfield gmail
                Container(
                  width: size.width,
                  height: size.height * 0.08,
                  //color: Colors.orange,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.only(
                      left: 40, right: 40, top: 10, bottom: 10),
                  child: TextField(
                    controller:
                        gmailController, //ค่าที่พิมเข้าไปใน textfield gmail จะถูกเก็บเข้ามาในตัวแปร gmailController
                    //obscureText: true,
                    onChanged: (e) {
                      //onChanged ทุกครั้งที่มีการพิมพ์อะไรเข้าไปใน textfield นี้จะมีการ setState(รีบิ้ว)
                      //ส่วนนี้ใช้สำหรับปุ่มกด ถ้ามีค่าใน textfield นี้จะสามารถกดปุ้มได้ ถ้าไม่มีค่าอะไรก็จะไม่สามารถกดปุ่มได้
                      setState(() {});
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      prefixIcon: const Icon(
                        Icons.email,
                        color: Colors.black,
                      ),
                      contentPadding: const EdgeInsets.only(left: 20),
                      hintText: 'Gmail',
                      hintStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black26),
                    ),
                  ),
                ),

                //เว้นช่องว่าง
                SizedBox(
                  width: size.width,
                  height: 20,
                  //color: Colors.red,
                ),

                //bt Send
                //เริ่มต้นจะทำการเช็คว่า textfield gmail มีค่าอะไรไหม
                //นี่เป็นเหตุผลว่าทำไมต้อง setState ทุกครั้งที่ค่าใน textfield เปลี่ยนเพราะไม่งั้นค่า gmailController.text ก็จะว่างตลอด
                if (gmailController.text != '') ...{
                  //กรณีค่า gmailController.text ไม่ว่าง (สามารถกดปุ่มได้)
                  Container(
                    width: size.width * 0.3,
                    height: size.height * 0.06,
                    //color: Colors.red,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        backgroundColor: const Color.fromARGB(
                            255, 117, 138, 214), //สีปุ่มก็จะเข้ม
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.zero,
                        textStyle: const TextStyle(fontSize: 20),
                      ),
                      onPressed: () {
                        //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                        print('gmail: ${gmailController.text}');
                        //reAuthEmail api call
                        //ตรวจสอบว่า อีเมลที่กรอกเข้ามามีรูปแบบของอีกเมลถูกต้องหรือไม่
                        if (!RegExp(r'\S+@\S+\.\S+')
                            .hasMatch(gmailController.text)) {
                          //ที่อยู่อีเมลไม่ถูกต้อง แสดง popup แจ้งเตือน
                          popup('Invalid email address\nPlease try again.',
                              'null');
                        } else {
                          //ที่อยู่อีเมลถูกต้อง เรียกใช้ ฟังก์ชั่น api โดยส่งค่า gmailController.text ไปยัง ฟังก์ชั่น api
                          resendEmail(gmailController.text
                              .toString()); // .toString เพื่อความชัวว่าเราส่ง string ไป
                        }
                      },
                      child: const Text(
                        'Send',
                        style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                    ),
                  )
                } else ...{
                  //กรณีค่า gmailController.text ว่าง (ไม่สามารถกดปุ่มได้)
                  Container(
                    width: size.width * 0.3,
                    height: size.height * 0.06,
                    //color: Colors.red,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        backgroundColor: const Color.fromARGB(122, 117, 138,
                            214), //ความเข้มของสีปุ่มจะลดลงครึ่งหนึ่ง
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.zero,
                        textStyle: const TextStyle(fontSize: 20),
                      ),
                      onPressed: null, //ไม่สามารถกดปุ่มได้
                      child: const Text(
                        'Send',
                        style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                    ),
                  )
                }
              ]),
        ),
      ),
    );
  }

  //function popup
  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false, //ไม่สามารถกดข้างนอก popup เพื่อออกจาก popup
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //content เป็นส่วนของเนื้อหา popup
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text, //นำ text ที่รับมา มาแสดงที่นี่
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            //actions เป็นส่วนของปุ่มใน popup สามารถมีหลายปุ่มได้
            //ปุ่ม ok ใน popup มีหน้าที่การทำงานต่างกันไปตามค่า move ที่รับมา
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  ////ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                  ///ถ้าค่า move = move จะให้ pushReplacement(เปลี่ยนหน้า) ไปยังหน้า login ในกรณ๊จะเกิดขึ้นได้เมื่อส่ง Re email สำเร็จ
                  if (move == 'move') {
                    //move to other page : main page
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginPage()));
                  } else {
                    //ถ้าค่า move เป็นค่าอื่นนอกเหนือจากเงื่อนไขที่ตั้งไว้จะทำการปิด popup เฉยๆ ไม่ได้เปลั้ยนไปหน้าไหน
                    Navigator.pop(context,
                        'Cancel'); //กลับไปยังหน้าก่อนหน้า ในกรณ๊นี้จะเป็นการปิด popup
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
