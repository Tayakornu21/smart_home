import 'dart:convert'; //libary สำหรับแปลง json ที่ได้มาจากเซิฟเวอร์เป็นภาษา dart
import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/loginPage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart'; //libary สำหรับการเรียกใช้ api

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  String url = "http://203.154.158.166/api"; //url ของ api
  // String url = "http://10.58.248.116:3000";

  //ตัวแปรสำหรับการรับค่าจาก Textfield
  TextEditingController gmailController = TextEditingController(); //email
  TextEditingController usernameController = TextEditingController(); //username
  TextEditingController passwordController = TextEditingController(); //password
  TextEditingController confirmPasswordController =
      TextEditingController(); //confirm password

  //show the password or not สำหรับเช้คว่าเรากดดู password รึเปล่า
  bool _isObscure = true; //pass
  bool _isObscure2 = true; //confirm pass

  //API function----------------------------------------------------------------
  registerAPI(String username, String password, String email) async {
    print('[registerAPI] Im in registerAPI function');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/RegisterUser'); //กำหนด url ของ api
    try {
      //ใส่ try catch ป้องกันการ error ตอนเซิฟเน่าหรือเน็ตเราไม่ดี
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type":
                "application/x-www-form-urlencoded", //ดูว่าbodyที่เราส่งไปยังเซิฟเป็นชนิดไหน
          },
          encoding: Encoding.getByName(
              'utf-8'), //ไม่รู้เหมือนกันว่าคืออะไรแต่น่าจะเป็นการแปลงค่าที่เป็นภาษาไทยมั้ง
          body: {
            //body ที่เราต้องส่งไปยังเซิฟเวอร์ ค่าพวกนี้จะอิงตาม api
            "username": username,
            "userPassword": password,
            "email": email
          });

      print('[registerAPI] res body: ${response.body}');
      //หลังจากส่งค่าไปยังเซิฟแล้วถ้าสำเร็จจะได้รับ respons กลับมาเก็บไว้ในตัวแปร response
      //เรา decode response ที่รับกลับมาให่เป็นภาษา dart เพื่อที่เราจะสามารถใช้งานค่าเหล่านั้นได้
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['message'].toString() ==
          'add email to db complete await email confirm') {
        //เช้คว่าค่าที่รับมาในส่วนของ message มีค่าตามนี้รึป่าว
        print("[registerAPI] message: ${jsonResponse['message']}");
        //register finish

        //auto build first house (ไม่ใช้แล้ว)
        // buildFirstHouse(
        //     jsonResponse['data']['userid'].toString(), username.toString());
        //reAuthenEmail(email);

        //popup
        //แสดง pop up ขึ่นมาว่าา Registration complete และส่ง move ไปเพื่อให้รู้ว่าเราสามารถเปลี่ยนหน้าได้ เงื่อนไขในส่วนนีจะอยู่ที่ฟังก์ชั่น popup
        popup('Registration complete', 'move'); //register complete
      } else {
        //ในกรณีที่ message มีค่าไม่ตรงที่เรากำหนดไว้ในเงื่อนไข ก็จะให้แสดง pop up ที่มีข้อความว่า Duplicate Email!\nPlease try again.
        // \n เป็นการขึ้นบรรทัดใหม่ใน Text
        //และเราจะส่ง null ไปเพื่อบอกว่าเราจะไม่มีการเปลี่ยนหน้า
        popup('Duplicate Email!\nPlease try again.', 'null');
      }
    } catch (e) {
      //register failed
      print('[registerAPI]error: $e');
      //กรณีจะเกิดขึ่นได้เมื่อเซิฟเวอร์ล้มหรือไม่ก็เน็ตของเราไม่ดี
      popup('Something is wrong!\nPlease try again.',
          'null'); //wrong code or can't connect to server.

    }
  }
  //----------------------------------------------------------------------------

  
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        const LoginPage())), //appBar show back bt for come back to login page
          ),
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow
          iconTheme:
              const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: SingleChildScrollView(
          //SingleChildScrollView ช่วยให้ไม่เกิด overflow เมื่อกดพิมพ์แล้วโชว์คีย์บอร์ด
          child: Container(
            width: size.width,
            height: size.height * 0.8,
            color: Colors.white,
            child: Column(children: [
              //เว้นช่องว่าง
              SizedBox(
                width: size.width,
                height: size.height * 0.12,
              ),

              //Text Register
              Container(
                  width: size.width,
                  height: size.height * 0.08,
                  alignment: Alignment.center,
                  child: const Text(
                    'Register',
                    style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 117, 138, 214)),
                  )),

              //Textfield Gmail
              Container(
                width: size.width,
                height: size.height * 0.08,
                alignment: Alignment.center,
                padding: const EdgeInsets.only(
                    left: 40, right: 40, top: 10, bottom: 10),
                child: TextField(
                  controller:
                      gmailController, //ค่าที่พิมเข้าไปใน textfield gmail จะถูกเก็บเข้ามาในตัวแปร gmailController
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    prefixIcon: const Icon(
                      //มี icon อยุ่ด้านหน้า
                      Icons.email,
                      color: Colors.black,
                    ),
                    contentPadding: const EdgeInsets.only(left: 20),
                    hintText: 'Gmail',
                    hintStyle: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black26),
                  ),
                ),
              ),

              //Textfield Username
              Container(
                width: size.width,
                height: size.height * 0.08,
                alignment: Alignment.center,
                padding: const EdgeInsets.only(
                    left: 40, right: 40, top: 10, bottom: 10),
                child: TextField(
                  controller: usernameController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    prefixIcon: const Icon(
                      Icons.person,
                      color: Colors.black,
                    ),
                    contentPadding: const EdgeInsets.only(left: 20),
                    hintText: 'Username',
                    hintStyle: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black26),
                  ),
                ),
              ),

              //Textfield Password
              Container(
                width: size.width,
                height: size.height * 0.08,
                alignment: Alignment.center,
                padding: const EdgeInsets.only(
                    left: 40, right: 40, top: 10, bottom: 10),
                child: TextField(
                  controller: passwordController,
                  obscureText: _isObscure,
                  decoration: InputDecoration(
                    //this button is used to toggle the password visibility
                    suffixIcon: IconButton(
                        //มีไอคอนด้านหลัง สามารถกดได้เพื่อดู password
                        icon: Icon(
                            _isObscure //ตรงนี้ ถ้า _isObscure เป็นจริงจะแสดงไอคอน visibility_off ถ้าไม่ก็จะแสดงไอคอน visibility(ไม่แน่ใจอาจจะสลับกัน)
                                ? Icons.visibility_off
                                : Icons.visibility),
                        onPressed: () {
                          setState(() {
                            _isObscure =
                                !_isObscure; //โดยจะมีการ setState ค่า _isObscure ใหม่ทุกครั้งที่กด
                          });
                        }),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    prefixIcon: const Icon(
                      Icons.lock,
                      color: Colors.black,
                    ),
                    contentPadding: const EdgeInsets.only(left: 20),
                    hintText: 'Password',
                    hintStyle: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black26),
                  ),
                ),
              ),

              //Textfield Confirm Password การทำงานเหมือนกับ Textfield Password
              Container(
                width: size.width,
                height: size.height * 0.08,
                alignment: Alignment.center,
                padding: const EdgeInsets.only(
                    left: 40, right: 40, top: 10, bottom: 10),
                child: TextField(
                  controller: confirmPasswordController,
                  obscureText: _isObscure2,
                  decoration: InputDecoration(
                    suffixIcon: IconButton(
                        icon: Icon(_isObscure2
                            ? Icons.visibility_off
                            : Icons.visibility),
                        onPressed: () {
                          setState(() {
                            _isObscure2 = !_isObscure2;
                          });
                        }),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    prefixIcon: const Icon(
                      Icons.lock,
                      color: Colors.black,
                    ),
                    contentPadding: const EdgeInsets.only(left: 20),
                    hintText: 'Confirm Password',
                    hintStyle: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black26),
                  ),
                ),
              ),

              //เว้นช่องว่าง
              SizedBox(
                width: size.width,
                height: 20,
              ),

              //button Register
              SizedBox(
                width: size.width * 0.3,
                height: size.height * 0.06,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(10), //ปรับความมนของขอบ
                    ),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.zero,
                    textStyle: const TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    //ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                    print(
                        'Gmail: ${gmailController.text}, Username: ${usernameController.text}, Password: ${passwordController.text}, Confirm Password: ${confirmPasswordController.text}');
                    //เริ่มต้นเราจะเช้คว่าค่า textfield ทั้งหมดถูกป้อนข้อมูลครบถ้วนแล้วหรือยัง
                    if (gmailController.text != '' &&
                        usernameController.text != '' &&
                        passwordController.text != '' &&
                        confirmPasswordController.text != '') {
                      //ตรวจสอบว่า อีเมลที่กรอกเข้ามามีรูปแบบของอีกเมลถูกต้องหรือไม่
                      if (!RegExp(r'\S+@\S+\.\S+')
                          .hasMatch(gmailController.text)) {
                        //ที่อยู่อีเมลไม่ถูกต้อง แสดง popup แจ้งเตือน
                        popup(
                            'Invalid email address\nPlease try again.', 'null');
                      } else {
                        //ที่อยู่อีเมลถูกต้อง ต่อไปเป็นการเช้คว่า password กับ confirm password ตรงกันหรือไม่
                        if (passwordController.text ==
                            confirmPasswordController.text) {
                          //print('Register!!');
                          //password กับ confirm password ตรงกัน ทำการเรียกใช้ฟังก์ชั่น registerAPI
                          //โดยจะส่งค่า ที่รับมาจาก textfield ทั้งหมดไปยังฟังก์ชั่น
                          //usernameController.text = String  ต้องมี .text ไม่งั้นมันจะไม่ใช่ String
                          registerAPI(usernameController.text,
                              passwordController.text, gmailController.text);
                        } else {
                          // password กับ confirm password ไม่ตรงกัน แสดง popup แจ้งเตือน
                          popup("Password don't match.", 'null');
                        }
                      }
                    } else {
                      //กรอกข้อมูลไม่ครบ แสดง popup แจ้งเตือน กรุุณากรอกข้อมูลให้ครอบ
                      popup('Please complete the information.', 'null');
                    }
                  },
                  child: const Text(
                    'Register',
                    style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'FCfont',
                        color: Colors.white),
                  ),
                ),
              )
            ]),
          ),
        ),
      ),
    );
  }

  //function popup
  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false, //ไม่สามารถกดข้างนอก popup เพื่อออกจาก popup
      context: context,
      builder: (BuildContext context) => WillPopScope(
         onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //content เป็นส่วนของเนื้อหา popup
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text, //นำ text ที่รับมา มาแสดงที่นี่
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24, fontWeight: FontWeight.w600, color: Colors.black),
            ),
          ),
          actions: <Widget>[
            //actions เป็นส่วนของปุ่มใน popup สามารถมีหลายปุ่มได้
            //ปุ่ม ok ใน popup มีหน้าที่การทำงานต่างกันไปตามค่า move ที่รับมา
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  ////ใน onPressed จะทำงานเหมือนเราทำการกดปุ่ม
                  ///ถ้าค่า move = move จะให้ pushReplacement(เปลี่ยนหน้า) ไปยังหน้า login ในกรณ๊จะเกิดขึ้นได้เมื่อลงทะเบียนสำเร็จ
                  if (move == 'move') {
                    //move to other page : main page
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginPage()));
                  } else {
                    //ถ้าค่า move เป็นค่าอื่นนอกเหนือจากเงื่อนไขที่ตั้งไว้จะทำการปิด popup เฉยๆ ไม่ได้เปลั้ยนไปหน้าไหน
                    Navigator.pop(context,
                        'Cancel'); //กลับไปยังหน้าก่อนหน้า ในกรณ๊นี้จะเป็นการปิด popup
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
