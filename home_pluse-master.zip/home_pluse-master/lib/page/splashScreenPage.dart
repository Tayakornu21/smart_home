import 'dart:async';
import 'package:flutter/material.dart';
//import 'package:homeplus_phase1/firebaseMessageProvider.dart';
import 'package:homeplus_phase1/page/loginPage.dart';

//ไฟล์นี้ไม่มีอะไรมากเป็นแค่หน้าที่ขึ้นมาตอนเข้าแอปครั้งแรก
class SplashScreenPage extends StatefulWidget {
  const SplashScreenPage({Key? key}) : super(key: key);

  @override
  State<SplashScreenPage> createState() => _SplashScreenPageState();
}

class _SplashScreenPageState extends State<SplashScreenPage> {

  
  @override
  void initState() {
    //initState เป็นฟังก์ชั่นที่จะเริ่มต้นการทกำงานเมื่อมีการเปิดหน้าในไฟล์นี้ขั้นมา ไม่เกี่ยวกับการรีบิ้ว (รีบิ่วคือการรีหน้าแอปใหม่=setState)
    super.initState();
    
    

    Timer(
        //จับเวลา 3 วิหลังจากนั้นจะทำงานตามที่เราเขียนโค้ดไว้
        const Duration(seconds: 3),
        () => Navigator.pushReplacement(
            context, //pushReplacement เป็นคำสั่งเปลี่ยนหน้าที่เราไม่สามารถ Navitor.pop กลับมาได้ หรือไม่สามารถย้อนกลับมาหน้านี้ได้
            MaterialPageRoute(
                builder: (context) =>
                    const LoginPage()))); //เมื่อครบสามวิแล้วให้เปลีี่ยนหน้าไปยังหน้า Login
  }

  //ระหว่างที่รอสามวินาทีก็จะทำการบิ้วหน้านี้ขึ้นมา
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        body: Container(
      //กำหนดขอบเขตของ Container ตัวนี้ที่ทำหน้าที่เป็น body ในหน้านี้
      width:
          size.width, //ความกว้างของ Container มีขนาดเท่ากับความกว้างของจอมือถือ
      height:
          size.height, //ความยาวของ Container มีขนาดเท่ากับความยาวของจอมือถือ
      color: Colors.white, //กำหนดสี
      child: Column(
          //เนื่องจากเราต้องการให้สิ่งที่อยู่ใน Container เรียงกันลงมาจึงต้องใช้ Column
          mainAxisAlignment: MainAxisAlignment
              .center, //กำหนดให้อะไรก็ตามที่อยู่ใน Columm อยู่ตรงกลางในแนวนอน
          crossAxisAlignment: CrossAxisAlignment
              .center, //กำหนดให้อะไรก็ตามที่อยู่ใน Columm อยู่ตรงกลางในแนวตั้ง (อาจจำสลับกับอันบน)
          children: [
            //ของที่อยู่ใน Column
            //เรียกรูปภาพในไฟล์ assets/images/SSIcon.png
            Image.asset(
              'assets/images/SSIcon.png',
              alignment: Alignment.center, //ให้ภาพอยู่ตรวงกลาง
            ),
            Row(
              //สร้าง Row ขึ้นมาเพราะว่าเรามี Text ที่้ตองการให้มันเรียงติดกันในแนวนอน
              //คำสั่งตรงนี้เหมือนกับ Column
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: const [
                Text(
                  'iSmart Living Plus',
                  style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 73, 82, 113)),
                  // color: Color.fromARGB(255, 117, 138, 214)),
                ),
                //แต่เนื่องจากเรามีการเปลี่ยนชื่อแอปเลยต้องคอมเม้นในส่วนนี้ทิ้งไป ดังนั้นก็ไม่จำเป็นต้องใช้ Row แล้วก็ได้ แต่ไม่ได้ลบออกเพราะทิ้งไว้ก็ไม่มีปัญหาอะไร
                // Text(
                //   'Living Plus',
                //   style: TextStyle(
                //       fontSize: 52,
                //       fontWeight: FontWeight.w600,
                //       color: Color.fromARGB(255, 73, 82, 113)),
                // )
              ],
            )
          ]),
    ));
  }
}


// Container(
//         padding: const EdgeInsets.all(20),
//         margin: const EdgeInsets.only(top: 20),
//         width: size.width,
//         height: size.height,
//         decoration: const BoxDecoration(
//             gradient: LinearGradient(
//                 begin: Alignment.topCenter,
//                 end: Alignment.bottomCenter,
//                 colors: [
//               Color.fromARGB(0, 255, 255, 255),
//               Color.fromARGB(0, 255, 191, 226),
//               Color.fromARGB(255, 197, 227, 252),
//             ],
//                 stops: [
//               0.55,
//               0.5,
//               1,
//             ])),
//         child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: [
//               Image.asset(
//                 'assets/images/SSIcon.png',
//                 alignment: Alignment.center,
//               )
//             ]),
//       ),