import 'package:flutter/material.dart';


//ไฟล์นี้ไม่มีอะไรเลย มีแค่หน้า UI เปล่าๆ
class NotificationPage extends StatefulWidget {
  const NotificationPage({Key? key}) : super(key: key);

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Container(
      width: size.width,
      height: size.height,
      //color: Colors.white,
      color: const Color.fromARGB(255, 243, 243, 243),
      alignment: Alignment.center,
      child: Column(
        children: [
          //App bar
          // Container(
          //   width: size.width,
          //   height: size.height * 0.082,
          //   //color: Colors.yellow,
          //   //padding: const EdgeInsets.only(left: 20, right: 10, top: 20),
          //   alignment: Alignment.bottomCenter,
          //   child: const Text(
          //     'Notification',
          //     style: TextStyle(
          //         fontSize: 26,
          //         color: Colors.black,
          //         fontWeight: FontWeight.w600),
          //   ),
          // ),
          Container(
            width: size.width,
            height: size.height * 0.89, //*old *0.765
            //color: Colors.red,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: const [
                  Icon(
                    Icons.message,
                    size: 100,
                    color: Colors.black38,
                  ),
                  Text("Don't have any notificaiton.",
                      style: TextStyle(
                          fontSize: 24,
                          color: Colors.black38,
                          fontWeight: FontWeight.w600))
                ]),
          )
        ],
      ),
      //bottomNavigationBar:  NavigationBottomBarWidget(),
    );
  }
}
