// ignore_for_file: avoid_print

import 'dart:convert'; //libary สำหรับแปลง json ที่ได้มาจากเซิฟเวอร์เป็นภาษา dart

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/cookiesValue.dart';
import 'package:homeplus_phase1/modelData/getDeviceListModel.dart';
import 'package:homeplus_phase1/page/addDevice/sendSerialPage.dart';
import 'package:homeplus_phase1/page/device/devicePage.dart';
import 'package:homeplus_phase1/page/manageHouse/manageHouseMainPage.dart';
import 'package:shared_preferences/shared_preferences.dart'; //libary สำหรับเรียกใช้ค่าใน local Storage
import 'package:http/http.dart' as http; //libary สำหรับการเรียกใช้ api
import '../modelData/getHouseListModel.dart';

import '../checkToken.dart';
import 'device/newDevicePage.dart';

//หน้าหลักของแอปพลิเคชั่น
//โค้ดค่อนข้างซับซ้อน

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  //String url = "http://203.154.158.166/api"; //url ของ api
  //String url = "http://10.58.248.116:3000";

  //ตัวแปรสำหรับการเลือกบ้าน
  String? dropdownvalue; //keep house select value.

  //Api function-------------------------------------------------------------------
  //get user data form server before
  //get house list
  var myHouseList; // list ข้อมูลของ mainHouse ใช้ check mianHouse อยู่ใน list ของบ้านที่รับมาจาก api หรือไม่
  GetHouseListModel?
      houseList; //กำหนเตัวแปรที่มีชนิดตัวแปรเป็น model ข้อมูลที่รับมาจาก api
  //เนื่องจากข้อมูลที่รับมาจากเซิฟเวอร์มีความซับซ้อนเลยต้องใช้ model ข้อมูลเข้ามาช่วย
  Future<GetHouseListModel?> getHouseListApi() async {
    print('[getHouseListApi] Im getHouseListApi function');
    var ct = await checkToken(context); // function from checkToken file.
    String temp = await getUserId(); //get userId มาเก็บไว้ใน tempv
    String urlBase = await getUrlBase();
    houseidGolble = await getHouseId();
    //print('[getHouseListApi] urlBase: $urlBase');
    Uri myUri = Uri.parse('$urlBase/house'); //กำหนด url ของ api
    try {
      if (ct == "ok") {
        http.Response response = await http.post(myUri,
            headers: {
              "Content-Type":
                  "application/x-www-form-urlencoded", //ดูว่าbodyที่เราส่งไปยังเซิฟเป็นชนิดไหน
            },
            encoding: Encoding.getByName('utf-8'),
            body: {
              "userid": temp
                  .toString(), //body ที่เราต้องส่งไปยังเซิฟเวอร์ ค่าพวกนี้จะอิงตาม api
            });

        print('[getHouseListApi] body : ${response.body}');

        //หลังจากส่งค่าไปยังเซิฟแล้วถ้าสำเร็จจะได้รับ respons กลับมาเก็บไว้ในตัวแปร response
        //เรา decode response ที่รับกลับมาให่เป็นภาษา dart เพื่อที่เราจะสามารถใช้งานค่าเหล่านั้นได้
        var jsonResponse = jsonDecode(response.body);
        if (jsonResponse['error'] == false) {
          myHouseList = jsonResponse['data'].toList();
          //ถ้่าไม่เกิด error อะไร จะให้นำค่าที่ได้มาจากเซิฟเวอร์ มาเก็บไว้ในตัว houseList
          //getHouseListModelFromJson เป็นฟังก์ชั่นแปลง Json form เป็น dart form ของไฟล์ model ข้อมูลของ GetHouseListModel
          houseList = getHouseListModelFromJson(response.body);
        }
        print('[getHouseListApi] finsih!');
        return houseList; //หลังจากนั้น return houseList
      } else {
        throw Exception(ct);
      }
    } catch (e) {
      print('[getHouseListApi] error: $e');
      return null; //หาก error ก็จะส่งค่า null แทน
    }
  }

  //การทำงานของฟังก์ชั่นนี้เหมือนกับ ฟังก์์ชั่น getHouseListApi แต่ในส่วนนี้เป็นของอุปกรณ์
  GetDeviceListModel? deviceList;
  Future<GetDeviceListModel?> getDeviceListApi() async {
    print('[getDeviceListApi] Im getDeviceListApi function');
    String temp = await getUserId();
    String hid = await getHouseId(); //get houseId current.
    String urlBase = await getUrlBase();
    print('[getDeviceListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/myDevices');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": temp, "houseid": hid});

      print('[getDeviceListApi] status Code : ${response.statusCode}');
      print('[getDeviceListApi] response body : ${response.body}');
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'].toString() == 'false') {
        deviceList = getDeviceListModelFromJson(response.body);
        print('[getDeviceListApi] finsih!');
      } else {}
      return deviceList; //return null if error happened
    } catch (e) {
      print('[getDeviceListApi] error: $e');
      return null;
    }
  }

  //-------------------------------------------------------------------------------

  //localStorage function
  //store first house to localstorage and send it to server for get data of the house.
  //รับค่า urlBase จาก localStorage
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //รับค่า userId จาก localStorage ใช้ในการรับ list ของ house
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId').toString();
    //prefs.setString('accessToken', token);
  }

  //check main House
  //Main house = current house
  var mainNameHouse; //check mainHouse
  //รับค่า mainNameHouse จาก localStorage
  checkFirstHouse() async {
    print('[checkFirstHouse] Im in  checkFirstHouse');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    mainNameHouse = prefs.getString('mainNameHouse');
    print('[checkFirstHouse] mainNameHouse: $mainNameHouse');
    return mainNameHouse;
    //prefs.setString('accessToken', token);
  }

  //for get list of device
  //รับค่า mainHouseid จาก localStorage ใช้รับ list ของอุปกรณ์
  var houseidGolble; //ใช้ check ว่า houseid ที่เป็น mainHoueid มีอยู่ใน List ของ house ที่รับมาจาก api หรือไม่
  getHouseId() async {
    print('[getHouseId] Im in  getHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    houseidGolble = prefs.getString('mainHouseid');
    //print('[getHouseId] mainNameHouse: $mainNameHouse');
    return houseidGolble.toString();
    //prefs.setString('accessToken', token);
  }

  //set house id
  //if main house is null -> main house(current house) will be the frist house of houseList form Api.
  //บันทึก mainHouseid และ mainNameHouse ลง localStorage
  setFirstHouse(houseid, nameHouse, lat, long) async {
    print('[setFirstHouse] Im in  setFirstHouse');
    print('[setFirstHouse] houseid: $houseid, nameHouse: $nameHouse');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('mainHouseid', houseid.toString()); //for delete
    prefs.setString('mainNameHouse', nameHouse); //for show
    prefs.setString('mainHouseLat', lat); //for show
    prefs.setString('mainHouseLong', long); //for show
  }

  //ไม่ต้องมีก็ได้ initState
  @override
  void initState() {
    removeCookie('clientIdSelectedDevice');
    removeCookie('cancelAuto');
    super.initState();
    print('[MainPage] start init State');
  }

  Future<void> _pullRefresh() async {
    setState(() {});
    // why use freshNumbers var? https://stackoverflow.com/a/52992836/2301224
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: RefreshIndicator(
          onRefresh: _pullRefresh,
          child: FutureBuilder(
              future:
                  getHouseListApi(), //ทำงานในส่วนของฟังก์ชั่น getHouseListApi ก่อนจะสร้างหน้าแอป
              builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
                //ค่าที่ถูก return(houseList) มาจากฟังก์ชั้นจะถูกเก็บไว้ใน snapshot
                //เช้คว่า snapshot รับค่ามาจากฟังก์ชั่นแล้วหรือยัง
                if (snapshot.connectionState == ConnectionState.done) {
                  var tempHouseList = snapshot.data; //กำหนดตัวแปร จะได้ใช้ง่ายๆ

                  //print('snapshot.data: ${snapshot.data.data.length}');
                  //future build and check mainHouseid localstorage if null, keep first house in list
                  //dropdownvalue = mainHouseid localstorage
                  //every change house = change mainHouseid localstorage too
                  if (tempHouseList != null) {
                    //เช้ค tempHouseList
                    return FutureBuilder(
                      //ใช้ FutureBuilder อีกครั้ง
                      future:
                          checkFirstHouse(), //เช้คว่าบ้านหลังแรกชื่ออะไร return nameHouse
                      builder: (BuildContext context,
                          AsyncSnapshot<dynamic> snapshotCheckFirstHouse) {
                        if (snapshotCheckFirstHouse.connectionState ==
                            ConnectionState.done) {
                          //print('snapshotCheckFirstHouse: ${snapshotCheckFirstHouse.data}');

                          if (tempHouseList.data.toString() == "[]") {
                            //clear main house
                            mainFirstHouseClear();
                          } else {
                            print("HouseMain ID Golbel: $houseidGolble");
                            var theHouse = [];
                            if (houseidGolble != "null") {
                              theHouse = myHouseList
                                  .where((element) =>
                                      element['houseid'] ==
                                      int.parse(houseidGolble))
                                  .toList();
                            }
                            //array of only selected items
                            //print('the house:: ${theHouse.toString()}');
                            //print('theHouse: ${theHouse[0]['houseName']}');

                            //ถ้า mainNameHouse =null หมายความว่ายังไม่ได้เลือกบ้านหลังใดเลย
                            //แต่การใช้งานจริงเราจะต้องเลือกบ้านหลังแรกที่เราสร้างไว้อัตโนมัติตั้งแต่ login เสร็จ
                            if (mainNameHouse == null || theHouse.isEmpty) {
                              print("set mainHouse");
                              //ดังนั้นเราจึงต้องทำการ set บ้านหลังแรกใน list house ลงไปใน localStorage
                              setFirstHouse(
                                  tempHouseList.data[0].houseid,
                                  tempHouseList.data[0].houseName,
                                  tempHouseList.data[0].latitude,
                                  tempHouseList.data[0].longitude);
                              dropdownvalue = tempHouseList.data[0]
                                  .houseName; //ให้บ้านที่เลือกเป็นบ้านหลังแรกใน list house
                            } else {
                              //แต่ถ้า mainNameHouse != null ก้ให้บ้านที่เลือกเป็นชื่อบ้านที่อยู่ใน localStorage
                              //check name house current : ในกรณีที่มีการเปลี่ยนชื่อบ้านในอีก user จะมีต้องมีการเช็คว่า mainHouseid ตรงกับ mainHouseName รึป่าว
                              if (theHouse[0]['houseName'] != mainNameHouse) {
                                setCookie(
                                    'mainNameHouse', theHouse[0]['houseName']);
                                dropdownvalue = theHouse[0]['houseName'];
                              } else {
                                dropdownvalue = snapshotCheckFirstHouse.data;
                              }
                            }
                          }

                          //ส่วนนี้เป็นส่วนที่แสดงในหน้าแอป
                          return Container(
                            width: size.width,
                            height: size.height,
                            color: const Color.fromARGB(255, 243, 243, 243),
                            child: Column(
                              children: [
                                //App bar
                                Container(
                                  width: size.width,
                                  height: size.height * 0.13,
                                  //color: Colors.yellow,
                                  padding: const EdgeInsets.only(
                                      left: 20, right: 10, top: 20),
                                  alignment: Alignment.bottomLeft,
                                  child: Row(
                                    children: [
                                      //dropdown for select house
                                      //Dropdown สำหรับการเลือกบ้าน
                                      Container(
                                        width: size.width * 0.78,
                                        height: size.height * 0.12,
                                        //color: Colors.red,
                                        alignment: Alignment.centerLeft,
                                        child: TextButton(
                                          style: TextButton.styleFrom(
                                            splashFactory:
                                                NoSplash.splashFactory,
                                          ),
                                          onPressed: () {
                                            //open popup house list
                                            //จะทำการเปิด popup house list ขึ้นมา
                                            showDialog(
                                                context: context,
                                                //barrierDismissible: false,
                                                builder:
                                                    (BuildContext context) {
                                                  return AlertDialog(
                                                      alignment:
                                                          Alignment.topRight,
                                                      contentPadding:
                                                          const EdgeInsets.only(
                                                              left: 25,
                                                              right: 25,
                                                              top: 10,
                                                              bottom: 10),
                                                      //insetPadding: const EdgeInsets.only(left: 50,right: 80),
                                                      insetPadding:
                                                          const EdgeInsets.only(
                                                              right: 110,
                                                              top: 30),
                                                      clipBehavior: Clip
                                                          .antiAliasWithSaveLayer,
                                                      shape: const RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          15))),
                                                      content: Container(
                                                        //เนื้อหาภายใน popup
                                                        width: size.width * 0.1,
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          children: [
                                                            if (tempHouseList
                                                                    .data
                                                                    .toString() ==
                                                                "[]")
                                                              ...{}
                                                            else ...{
                                                              ConstrainedBox(
                                                                constraints:
                                                                    BoxConstraints(
                                                                  maxHeight:
                                                                      size.height *
                                                                          0.5,
                                                                ),
                                                                child:
                                                                    Container(
                                                                  width: size
                                                                      .width,
                                                                  child: ListView //มีการนำค่าของ list house มาแสดงในส่วนนี้
                                                                      .builder(
                                                                          shrinkWrap: true,
                                                                          itemCount: tempHouseList.data.length, //จำนวนบ้านใน List house
                                                                          itemBuilder: (context, //จากนั้นสร้าง widget ตามจำนวนบ้านใน List house (tempHouseList.data..length)
                                                                                  i) =>
                                                                              //Container ตรงนี้จะถูกสร้างซ้ำตามจำนวนของ tempHouseList.data..length
                                                                              Container(
                                                                                  height: size.height * 0.06,
                                                                                  alignment: Alignment.centerLeft,
                                                                                  child: Stack(
                                                                                    children: [
                                                                                      if (dropdownvalue == tempHouseList.data[i].houseName) ...{
                                                                                        //เช็คว่าบ้านที่เลือกปัจจุบันตรงกับบ้านหลังไหนในlist house
                                                                                        //จะมีการเปลี่ยนสีข้อความและเพ่ิม icon หลังชื่อบ้านหากบ้านที่เลือกปัจจุบันตรงกับบ้านที่อยู่ใน list house
                                                                                        //สรุปง่ายๆ คือ บ้านที่อยู่ใน localStorage ชื่อตรงกับชื่อบ้านหลังไหนใน list house ที่รับมาจากเซิฟเวอรฺ์ให้เข้ามาทำงานในส่วนนี้
                                                                                        TextButton(
                                                                                            style: TextButton.styleFrom(
                                                                                              alignment: Alignment.centerLeft,
                                                                                              padding: EdgeInsets.zero,
                                                                                            ),
                                                                                            onPressed: () {
                                                                                              //ในส่วนนี้ที่จริงจะเป็นการ set บ้านที่เลือกลง localStorage ในกรณ๊ํที่เราเลือกบ้านหลังใหม่ที่ไม่ใช่หลังปัจจุบัน
                                                                                              setFirstHouse(tempHouseList.data[i].houseid, tempHouseList.data[i].houseName, tempHouseList.data[i].latitude, tempHouseList.data[i].longitude);
                                                                                              setState(() {
                                                                                                //dropdownvalue = tempHouseList.data[i].houseName;
                                                                                              });
                                                                                              //รีบิ้วหน้าแอปใหม่
                                                                                              Navigator.of(context).pop(); //จากนั้นก็ปิด popup house list
                                                                                            },
                                                                                            child: Row(
                                                                                              children: [
                                                                                                SizedBox(
                                                                                                  width: size.width * 0.48,
                                                                                                  child: Text(
                                                                                                    tempHouseList.data[i].houseName,
                                                                                                    overflow: TextOverflow.ellipsis,
                                                                                                    style: const TextStyle(
                                                                                                      fontSize: 24,
                                                                                                      fontWeight: FontWeight.w600,
                                                                                                      color: Color.fromARGB(255, 117, 138, 214), //ตัวหนังสือสี
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                                const Spacer(),
                                                                                                const Icon(
                                                                                                  //เพิ่มไอคอน
                                                                                                  Icons.check,
                                                                                                  color: Color.fromARGB(255, 117, 138, 214),
                                                                                                )
                                                                                              ],
                                                                                            )),
                                                                                      } else ...{
                                                                                        //ในกรณีที่บ้านใน list house ไม่ตรงกับ บ้านที่เลือกในปัจจุบัน ก็จะแสดงชื่อบ้านสีดำๆ เฉยๆ
                                                                                        TextButton(
                                                                                            style: TextButton.styleFrom(
                                                                                              alignment: Alignment.centerLeft,
                                                                                              padding: EdgeInsets.zero,
                                                                                            ),
                                                                                            onPressed: () {
                                                                                              //set บ้านที่เลือกลง localStorage ในกรณ๊ํที่เราเลือกบ้านหลังใหม่ที่ไม่ใช่หลังปัจจุบัน
                                                                                              setFirstHouse(tempHouseList.data[i].houseid, tempHouseList.data[i].houseName, tempHouseList.data[i].latitude, tempHouseList.data[i].longitude);
                                                                                              removeCookie('numDeviceInHouse'); //move old numDeviceInHouse
                                                                                              removeCookie('goOutStatus');
                                                                                              setState(() {
                                                                                                //dropdownvalue = tempHouseList.data[i].houseName;
                                                                                              });
                                                                                              //รีบิ้วหน้าแอปใหม่
                                                                                              Navigator.of(context).pop(); //จากนั้นก็ปิด popup house list
                                                                                            },
                                                                                            //เป็น text เปล่าๆ ไม่มีสีไม่มีไอคอนตามหลัง
                                                                                            child: SizedBox(
                                                                                              width: size.width,
                                                                                              child: Text(
                                                                                                tempHouseList.data[i].houseName,
                                                                                                overflow: TextOverflow.ellipsis,
                                                                                                style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w600, color: Color.fromARGB(255, 89, 85, 85)),
                                                                                              ),
                                                                                            )),
                                                                                      }
                                                                                    ],
                                                                                  ))),
                                                                ),
                                                              ),
                                                              //เว้นว่าง
                                                              const SizedBox(
                                                                height: 10,
                                                              ),

                                                              //เส้นสีเทา
                                                              Container(
                                                                width:
                                                                    size.width,
                                                                height: 1,
                                                                color: const Color
                                                                        .fromARGB(
                                                                    255,
                                                                    230,
                                                                    230,
                                                                    230),
                                                              ),
                                                            },

                                                            //เว้นว่าง
                                                            const SizedBox(
                                                              height: 10,
                                                            ),

                                                            //manag house bt
                                                            //ปุ่มจัดการบ้าน
                                                            //หลังจากที่วนลูปแสดงชื่อของบ้านภายใน List house เสร็จแล้วจะมีการสร้างปุ่ม จัดการบ้านขึ้นมาปิดท้าย
                                                            Container(
                                                              width: size.width,
                                                              height:
                                                                  size.height *
                                                                      0.06,
                                                              // padding: const EdgeInsets.only(
                                                              //     left: 10, right: 10),
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: TextButton(
                                                                style: TextButton
                                                                    .styleFrom(
                                                                  alignment:
                                                                      Alignment
                                                                          .centerLeft,
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                ),
                                                                onPressed: () {
                                                                  print(
                                                                      'go to manage house page');
                                                                  //ไปยังหน้า ManageHouseMainPage ในกรณ๊นี้ แม้จะเป็น pushReplacement
                                                                  //แต่ยังใช้ Navigator.pop หรือกดปุ่มย้อนกลับของแอปออกมาได้ ไม่เข้าใจเหมือนกันว่าทำไมได้
                                                                  Navigator.pushReplacement(
                                                                      context,
                                                                      MaterialPageRoute(
                                                                          builder: (context) =>
                                                                              const ManageHouseMainPage())).then(
                                                                      (value) {
                                                                    setState(
                                                                        () {}); //รีบิ้วใหม่เมื่อกลับมายังหน้า main page
                                                                  });
                                                                },
                                                                child:
                                                                    const Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  children: [
                                                                    Text(
                                                                      'Manage house',
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              24,
                                                                          fontWeight: FontWeight
                                                                              .w600,
                                                                          color: Color.fromARGB(
                                                                              255,
                                                                              89,
                                                                              85,
                                                                              85)),
                                                                    ),
                                                                    Spacer(),
                                                                    Icon(
                                                                      Icons
                                                                          .manage_accounts,
                                                                      color: Color.fromARGB(
                                                                          255,
                                                                          117,
                                                                          138,
                                                                          214),
                                                                    )
                                                                  ],
                                                                ),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      ));
                                                });
                                          },
                                          child: Row(children: [
                                            ConstrainedBox(
                                              constraints: BoxConstraints(
                                                maxWidth: size.width * 0.6,
                                              ),
                                              child: Text(
                                                //แสดงชื่อบ้านที่เลือกปัจจุบันบน appbar
                                                dropdownvalue ??
                                                    'Select house', //something wrong! กรณีนี้จะไม่มีทางเกิดขั้น
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                    fontSize: 24,
                                                    fontWeight: FontWeight.w600,
                                                    color: Color.fromARGB(
                                                        255, 89, 85, 85)),
                                              ),
                                            ),
                                            const Icon(
                                              Icons.arrow_drop_down,
                                              color: Color.fromARGB(
                                                  255, 89, 85, 85),
                                            )
                                          ]),
                                        ),
                                      ),

                                      //เว้นระยะ
                                      const Spacer(),

                                      //add device bt
                                      if (tempHouseList.data.toString() ==
                                          "[]") ...{
                                        //refresh bt
                                        Container(
                                            height: size.height * 0.12,
                                            alignment: Alignment.centerLeft,
                                            child: IconButton(
                                                icon: const Icon(Icons.refresh),
                                                onPressed: () {
                                                  setState(() {});
                                                }))
                                      } else ...{
                                        //ปุ่มแอดอุปกรณ์
                                        Container(
                                          height: size.height * 0.12,
                                          alignment: Alignment.centerLeft,
                                          child: IconButton(
                                            icon: const Icon(Icons.add),
                                            // onPressed: () {
                                            //   print('go to add decive page');
                                            //   Navigator.of(context).push(MaterialPageRoute(
                                            //       builder: (context) => const AddDevicePage()));
                                            // },
                                            onPressed: () {
                                              //open popup
                                              //จะทำการเปิด popup ขึ้นมา
                                              showDialog(
                                                  context: context,
                                                  //barrierDismissible: false,
                                                  builder:
                                                      (BuildContext context) {
                                                    return AlertDialog(
                                                        alignment:
                                                            Alignment.topLeft,
                                                        contentPadding:
                                                            const EdgeInsets.only(
                                                                left: 25,
                                                                right: 25,
                                                                top: 10,
                                                                bottom: 10),
                                                        //insetPadding: const EdgeInsets.only(left: 50,right: 80),
                                                        insetPadding:
                                                            const EdgeInsets
                                                                    .only(
                                                                left: 110,
                                                                top: 30),
                                                        clipBehavior: Clip
                                                            .antiAliasWithSaveLayer,
                                                        shape: const RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .all(Radius
                                                                        .circular(
                                                                            15))),
                                                        content: SizedBox(
                                                          //เนื้อหาใน popup
                                                          width:
                                                              size.width * 0.1,
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            children: [
                                                              //แอดอุปกรณ์แบบส่ง serial Number
                                                              Container(
                                                                width:
                                                                    size.width,
                                                                height:
                                                                    size.height *
                                                                        0.06,
                                                                // padding: const EdgeInsets.only(
                                                                //     left: 10, right: 10),
                                                                alignment: Alignment
                                                                    .centerLeft,
                                                                child:
                                                                    TextButton(
                                                                  style: TextButton
                                                                      .styleFrom(
                                                                    alignment:
                                                                        Alignment
                                                                            .centerLeft,
                                                                    padding:
                                                                        EdgeInsets
                                                                            .zero,
                                                                  ),
                                                                  onPressed:
                                                                      () {
                                                                    print(
                                                                        'go to add device page');
                                                                    //ไปยังหน้า SendSerialPage ในกรณ๊นี้ แม้จะเป็น pushReplacement
                                                                    //แต่ยังใช้ Navigator.pop หรือกดปุ่มย้อนกลับของแอปออกมาได้ ไม่เข้าใจเหมือนกันว่าทำไมได้
                                                                    Navigator.pushReplacement(
                                                                        context,
                                                                        MaterialPageRoute(
                                                                            builder: (context) =>
                                                                                const SendSerialPage())).then(
                                                                        (value) {
                                                                      setState(
                                                                          () {}); //รีบิ้วใหม่เมื่อกลับมายังหน้า main page
                                                                    });
                                                                  },
                                                                  child:
                                                                      SizedBox(
                                                                    width: size
                                                                        .width,
                                                                    child:
                                                                        const Row(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Icon(
                                                                          Icons
                                                                              .add,
                                                                          color:
                                                                              Colors.black,
                                                                        ),
                                                                        SizedBox(
                                                                          width:
                                                                              20,
                                                                        ),
                                                                        Text(
                                                                          'Add device',
                                                                          style: TextStyle(
                                                                              fontSize: 24,
                                                                              fontWeight: FontWeight.w600,
                                                                              color: Color.fromARGB(255, 89, 85, 85)),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),

                                                              //เว้นว่าง
                                                              const SizedBox(
                                                                height: 10,
                                                              ),

                                                              //แอดอุปกรณ์แบบ ถ่าย QRcode (ยังไม่ได้ทำ)
                                                              // Container(
                                                              //   width: size.width,
                                                              //   height:
                                                              //       size.height *
                                                              //           0.06,
                                                              //   // padding: const EdgeInsets.only(
                                                              //   //     left: 10, right: 10),
                                                              //   alignment: Alignment
                                                              //       .centerLeft,
                                                              //   child: TextButton(
                                                              //     style: TextButton
                                                              //         .styleFrom(
                                                              //       alignment: Alignment
                                                              //           .centerLeft,
                                                              //       padding:
                                                              //           EdgeInsets
                                                              //               .zero,
                                                              //     ),
                                                              //     onPressed: () {
                                                              //       print(
                                                              //           'open scan qrcode');
                                                              //       // Navigator.pushReplacement(
                                                              //       //     context,
                                                              //       //     MaterialPageRoute(
                                                              //       //         builder: (context) =>
                                                              //       //             const ManageHouseMainPage()));
                                                              //     },
                                                              //     child: SizedBox(
                                                              //       width:
                                                              //           size.width,
                                                              //       child: Row(
                                                              //         mainAxisSize:
                                                              //             MainAxisSize
                                                              //                 .min,
                                                              //         mainAxisAlignment:
                                                              //             MainAxisAlignment
                                                              //                 .start,
                                                              //         children: const [
                                                              //           Icon(
                                                              //             Icons
                                                              //                 .qr_code_scanner,
                                                              //             color: Colors
                                                              //                 .black,
                                                              //           ),
                                                              //           SizedBox(
                                                              //             width: 20,
                                                              //           ),
                                                              //           Text(
                                                              //             'Scan',
                                                              //             style: TextStyle(
                                                              //                 fontSize:
                                                              //                     24,
                                                              //                 fontWeight: FontWeight
                                                              //                     .w600,
                                                              //                 color: Color.fromARGB(
                                                              //                     255,
                                                              //                     89,
                                                              //                     85,
                                                              //                     85)),
                                                              //           ),
                                                              //         ],
                                                              //       ),
                                                              //     ),
                                                              //   ),
                                                              // )
                                                            ],
                                                          ),
                                                        ));
                                                  });
                                            },
                                          ),
                                        ),
                                      }
                                    ],
                                  ),
                                ),
                                //---------------------------------------------------------------------

                                //Body ในส่วนนี้จะแสดงรายกายของอุปกรณ์ที่มีในบ้านนั้นๆ
                                if (tempHouseList.data.toString() == "[]") ...{
                                  SizedBox(
                                    width: size.width,
                                    height: size.height * 0.745,
                                    child: const Center(
                                        child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.house,
                                          size: 100,
                                          color: Color.fromARGB(
                                              255, 180, 180, 220),
                                        ),
                                        Text("Don't have any house.",
                                            style: TextStyle(
                                                fontSize: 24,
                                                color: Color.fromARGB(
                                                    255, 180, 180, 220),
                                                fontWeight: FontWeight.w600))
                                      ],
                                    )),
                                  )
                                } else ...{
                                  SizedBox(
                                    width: size.width,
                                    height: size.height * 0.745,
                                    child: ListView(children: [
                                      //loop for show device here!
                                      FutureBuilder(
                                          future:
                                              getDeviceListApi(), //ทำงานในฟังก์ชั่น getDeviceListApi ก่อน
                                          builder: (BuildContext context,
                                              AsyncSnapshot<dynamic>
                                                  snapshotDevice) {
                                            //เช้คว่า snapshotDevice รับค่า return มารึยัง
                                            if (snapshotDevice
                                                    .connectionState ==
                                                ConnectionState.done) {
                                              // print(
                                              //     'snapshot device num: ${snapshotDevice.data.data.length}');

                                              //เช้คว่า snapshotDevice.data = nullหรือไม่
                                              if (snapshotDevice.data != null) {
                                                //เช้คจำนวนอุปกรณ์
                                                if (snapshotDevice
                                                        .data.data.length !=
                                                    0) {
                                                  //keep number of device in the house for checking map notification in bg service
                                                  setCookie(
                                                      'numDeviceInHouse',
                                                      snapshotDevice
                                                          .data.data.length
                                                          .toString());
                                                  return Column(
                                                    children: [
                                                      //วนลูปตามความยาวของ list device (snapshotDevice.data.data.length)
                                                      for (int i = 0;
                                                          i <
                                                              snapshotDevice
                                                                  .data
                                                                  .data
                                                                  .length;
                                                          i++) ...{
                                                        //เรียกใช้ฟังก์ชั่น deviceBox และใส่ข้อมูลเข้าไป
                                                        deviceBox(
                                                            nameDevice:
                                                                snapshotDevice
                                                                    .data
                                                                    .data[i]
                                                                    .deviceName
                                                                    .toString(),
                                                            room: snapshotDevice
                                                                .data
                                                                .data[i]
                                                                .room
                                                                .toString(),
                                                            serialNumber:
                                                                snapshotDevice
                                                                    .data
                                                                    .data[i]
                                                                    .serialNumber
                                                                    .toString(),
                                                            con: context)
                                                      },

                                                      // TextButton(
                                                      //     onPressed: () {
                                                      //       FlutterBackgroundService()
                                                      //           .invoke(
                                                      //               "stopService");
                                                      //     },
                                                      //     child: const Text(
                                                      //         'stop service')),

                                                      // TextButton(
                                                      //     onPressed: () async {
                                                      //      await initializeService();
                                                      //     },
                                                      //     child: const Text(
                                                      //         'bg service'))
                                                    ],
                                                  );
                                                } else {
                                                  //จำนวนอุปกรณ์เท่ากับ 0 = ยังไม่ได้เพิ่มอุปกรณ์
                                                  // removeCookie(
                                                  //     'numDeviceInHouse');
                                                  return Container(
                                                    width: size.width,
                                                    height: size.height * 0.7,
                                                    //color: Colors.red,
                                                    child: const Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: [
                                                          Icon(
                                                            Icons
                                                                .desktop_windows,
                                                            size: 100,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    180,
                                                                    180,
                                                                    220),
                                                          ),
                                                          Text(
                                                              "Don't have any device.",
                                                              style: TextStyle(
                                                                  fontSize: 24,
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          180,
                                                                          180,
                                                                          220),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600))
                                                        ]),
                                                  );
                                                }
                                              } else {
                                                //ถ้าเท่ากับ null นั้นหมายความว่าไม่สร้างรับข้อมูลจาก เซิฟเวอร์ได้
                                                //เซิฟอาจจะล้มหรือเน็ตเราไม่ดี ดั้งนั้นจึง return connectFailed
                                                return Column(
                                                  //ตรงนนี้จะช่วยให้  loadingBox อยุ่ตรงกลางจอ
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      width: size.width,
                                                      height: size.height * 0.6,
                                                      child: connectFailed(),
                                                    )
                                                  ],
                                                );
                                              }
                                            } else {
                                              //ในขณะที่ futurebuilder กำลังทำงานเพื่อ return ค่ามายัง snapshot ตัวแอปจะเข้ามาทำงานในส่วนนี้ก่อน
                                              return Column(
                                                //ตรงนนี้จะช่วยให้  loadingBox อยุ่ตรงกลางจอ
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    width: size.width,
                                                    height: size.height * 0.6,
                                                    child: loadingBox(),
                                                  )
                                                ],
                                              );
                                            }
                                          }),
                                    ]),
                                  ),
                                }
                              ],
                            ),
                          );
                        } else {
                          //ในขณะที่ futurebuilder กำลังทำงานเพื่อ return ค่ามายัง snapshot ตัวแอปจะเข้ามาทำงานในส่วนนี้ก่อน
                          //ทำการ สร้าง loadingBox ขึ้นมาในขณะที่รอค่า snapshot
                          return loadingBox();
                        }
                      },
                    );
                  } else {
                    //ในกรณีที่ tempHouseList == null นั้นหมายความว่าไม่สร้างรับข้อมูลจาก เซิฟเวอร์ได้
                    //เซิฟอาจจะล้มหรือเน็ตเราไม่ดี ดั้งนั้นจึง return connectFailed
                    return connectFailed();
                  }
                } else {
                  //ในขณะที่ futurebuilder กำลังทำงานเพื่อ return ค่ามายัง snapshot ตัวแอปจะเข้ามาทำงานในส่วนนี้ก่อน
                  //ทำการ สร้าง loadingBox ขึ้นมาในขณะที่รอค่า snapshot
                  return loadingBox();
                }
              }),
        ));
  }

  //แสดงตอนเชื่อมต่อล้มเหลว snapshot = null
  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Connection failed!',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width * 0.3,
            height: size.height * 0.06,
            child: TextButton(
              style: TextButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                foregroundColor: Colors.white,
                padding: EdgeInsets.zero,
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {}); //กดปุ่มแล้วจะรีบิ้วใหม่
              },
              child: const Text(
                'Try again',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'FCfont',
                  fontSize: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  //โหลดหน้ารอ snapshot
  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Loading...',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }

  //เป็น box สำหรับแสดงอุปกรณ์
  deviceBox({nameDevice, room, serialNumber, con}) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ

    return Container(
      width: size.width,
      height: 123.08571428571427, //size.height * 0.15,
      padding: const EdgeInsets.only(left: 30, right: 30),
      margin: const EdgeInsets.only(bottom: 20),
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          foregroundColor: Colors.white,
          padding:
              const EdgeInsets.only(top: 30, bottom: 20, left: 30, right: 25),
        ),
        onPressed: () async {
          print('go device page');
          //set serialNumber
          //เมื่อกดเข้ามาจะต้องบันทึก serial ของตัวอุปกรณ์ลง localStorage
          //เพื่อจะนำไปใช้ในหน้า DevicePage
          SharedPreferences prefs = await SharedPreferences.getInstance();
          prefs.setString('serial', serialNumber); //for delete

          Navigator.of(con).pushReplacement(
              MaterialPageRoute(builder: (context) => const NewDevicePage()));
        },
        child: Row(
          children: [
            SizedBox(
              width: size.width * 0.58,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(nameDevice,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w600,
                          color: Colors.black)),
                  Text(room,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w600,
                          color: Colors.black38))
                ],
              ),
            ),
            const Spacer(),
            const SizedBox(
              width: 30,
              height: 30,
              //color: Colors.red,
              child: Icon(
                Icons.arrow_forward_ios,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

///old drop down
//Container(
//   width: size.width * 0.3,
//   height: size.height * 0.12,
//   //color: Colors.red,
//   alignment: Alignment.centerLeft,
//   child: ButtonTheme(
//     alignedDropdown: false,
//     child: PopupMenuButton<String>(
//       itemBuilder: (context) {
//         return items.map((str) {
//           if (str == 'manage') {
//             return PopupMenuItem(
//               value: str,
//               child: Column(
//                 children: [
//                   TextButton(
//                       //padding: EdgeInsets.zero,
//                       onPressed: () {
//                         print('go to manager house page');
//                       },
//                       child: Row(
//                         children: const [
//                           Text('จัดการบ้าน'),
//                           Spacer(),
//                           Icon(Icons.manage_accounts)
//                         ],
//                       )),
//                 ],
//               ),
//             );
//           } else {
//             return PopupMenuItem(
//                 value: str,
//                 child: Text(
//                   str,
//                   style: const TextStyle(
//                       fontSize: 18,
//                       fontWeight: FontWeight.w600,
//                       color: Color.fromARGB(255, 89, 85, 85)),
//                 ));
//           }
//         }).toList();
//       },
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: <Widget>[
//           Text(
//             dropdownvalue,
//             style: const TextStyle(
//                 fontSize: 24,
//                 fontWeight: FontWeight.w600,
//                 color: Color.fromARGB(255, 89, 85, 85)),
//           ),
//           const Icon(Icons.arrow_drop_down),
//         ],
//       ),
//       onSelected: (v) {
//         setState(() {
//           print('!!!===== $v');
//           dropdownvalue = v;
//         });
//       },
//     ),
//   ),
// ),
