import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:homeplus_phase1/cookiesValue.dart';
import 'package:homeplus_phase1/page/manageHouse/editMapScreen.dart';
import 'package:homeplus_phase1/page/manageHouse/manageRoomPage.dart';
import 'package:homeplus_phase1/page/manageHouse/personInHousePage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class HousePage extends StatefulWidget {
  const HousePage(
      {super.key,
      required this.nameHouse,
      required this.numHouse,
      required this.numRoom,
      required this.numDevice,
      this.lat,
      this.long});

  final String nameHouse; //show name
  final String
      numHouse; //for check last house: last house = don't have delete house bt
  final String numRoom; //show num room
  final String numDevice; //show num device
  final String? lat;
  final String? long;
  @override
  State<HousePage> createState() => _HousePageState();
}

class _HousePageState extends State<HousePage> {
  //String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";
  String? nameHouse;
  TextEditingController houseNameController = TextEditingController();

  //Api function----------------------------------------------------------------
  //edit name house api
  var myRole; // บทบาท ของ เจ้าของ account ในบ้านหลังนี้
  var myRoleList; // list ข้อมูลของเจ้าของ account ที่ดึงมาจากข้อมูลของ api
  getAllPersonInHouse() async {
    print('[getAllPersonInHouse] Im getAllPersonInHouse function');
    String temp = await getHouseId();
    mainUserId = await getUserId();
    String urlBase = await getUrlBase();
    //print('[getAllPersonInHouse] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/allPersonInHouse');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"houseid": temp});

      print('[getAllPersonInHouse] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        print(response.body);
        var jsonResponse = jsonDecode(response.body);
        var numPerson = jsonResponse['data'].length.toString();

        myRoleList = jsonResponse['data'].toList();
        print('[getAllPersonInHouse] myRoleList: $myRoleList');

        print(
            '[getAllPersonInHouse] number of person in the house: ${jsonResponse['data'].length.toString()}');
        print('[getAllPersonInHouse] finsih!');
        return numPerson;
      } else {
        return null;
      }
    } catch (e) {
      print('[getAllPersonInHouse] error: $e');
      return null;
    }
  }

  //delete house api
  delHouseApi() async {
    print('[delHouseApi] Im getHouseListApi function');
    String temp = await getHouseId();
    String urlBase = await getUrlBase();
    String mainHouseId = await getMainHouseId();
    print('[delHouseApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/delHouse');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "houseid": temp,
          });

      print('[delHouseApi] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        print(response.body);

        //check บ้านที่ลบตรงกับบ้านหลักที่เราเลือกไว้รึไหม
        if (temp == mainHouseId) {
          print('[delHouseApi] clear mainFristHouse');
          //ถ้าใช่ให้ทำการ clear ค่าบ้านหลักที่เก็บไว้ใน cookies
          mainFirstHouseClear();
        }

        print('[delHouseApi] finsih!');
        Navigator.of(context).pop();
        popup('deleted', 'no');
        //deleted
      } else {
        //cant deleted
        popup("Can't delete this house.\nSomething is worng.", 'no');
      }
    } catch (e) {
      print('[getHouseListApi] error: $e');
      popup("Can't delete this house.\nConnection failed", 'no');
      //cant deleted
    }
  }

  //edit name house api
  editNameHouseApi(oldName, newName) async {
    print('[editNameHouseApi] Im editNameHouseApi function');
    String temp = await getHouseId();
    String urlBase = await getUrlBase();
    print('[editNameHouseApi] temp: $temp');
    print('[editNameHouseApi] newName: $newName');
    print('[editNameHouseApi] oldName: $oldName');
    Uri myUri = Uri.parse('$urlBase/EditHouseName');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"houseid": temp, "houseNewName": newName});

      print('[editNameHouseApi] status Code : ${response.statusCode}');

      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)

      if (jsonResponse['error'] == false) {
        print(response.body);
        //check new name with main name house
        SharedPreferences prefs = await SharedPreferences.getInstance();
        var mainNameHouse = prefs.getString('mainNameHouse');
        //print('[editNameHouseApi] mainNameHouse: $mainNameHouse');
        if (mainNameHouse == oldName) {
          prefs.setString('mainNameHouse', newName);
        }
        print('[editNameHouseApi] finsih!');
        return true;
        //edit already
      } else {
        if (jsonResponse['message'] ==
            "Data too long for column 'houseName' at row 1") {
          popup("Can't edit the name of this house.\nThe name is too long.",
              'no'); //wrong status code
          return false;
        } else {
          popup(
              "Can't edit the name of this house.\nSomething is worng.", 'no');
          return false;
        }
      }
    } catch (e) {
      print('[editNameHouseApi] error: $e');
      popup("Can't edit the name of this house.\nConnection failed", 'no');
      return false;
    }
  }

  //----------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  mainFirstHouseClear() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('mainHouseid');
    prefs.remove('mainNameHouse');
    prefs.remove('mainHouseLat');
    prefs.remove('mainNameLong');
  }

  //รับค่า userId จาก localStorage ใช้ในการเพิ่มคนในบ้าน
  var mainUserId;
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var mainUserId = prefs.getString('userId');
    //print('[getUserId] userId: $userId');
    return mainUserId;
    //prefs.setString('accessToken', token);
  }

  var houseid; //check login
  getHouseId() async {
    print('[getHouseId] Im in  getHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    houseid = prefs.getString('houseid');
    print('[getHouseId] houseid: $houseid');
    return houseid.toString();
    //prefs.setString('accessToken', token);
  }

  getMainHouseId() async {
    print('[getMainHouseId] Im in  getMainHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var mainHouseId = prefs.getString('mainHouseid');
    print('[getMainHouseId] MainHouseId: $mainHouseId');
    return mainHouseId.toString();
  }

  //----------------------------------------------------------------------------

  late Position userLocation;
  //การใช้งาน Geolocator สำหรับดึงพิกัดปัจจุบันของผู้ใช้งานจากโทรศัพท์ ด้วยการใช้งาน Future
  Future<Position?> getLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {}

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {}
    }
    if (permission == LocationPermission.deniedForever) {}
    return null;
  }

  LatLng? latlng;
  //รับค่าจากหน้าถัดไป
  void _awaitReturnValueFromSecondScreen(BuildContext context) async {
    // start the SecondScreen and wait for it to finish with a result
    final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => EditMapScreen(
            latOld: latlng != null ? latlng!.latitude.toString() : widget.lat,
            longOld:
                latlng != null ? latlng!.longitude.toString() : widget.long,
          ),
        ));

    // after the SecondScreen result comes back update the Text widget with it
    setState(() {
      latlng = result;
      //lat = latlng!.latitude.toString();
    });
  }

  var apin; // all person in house
  @override
  void initState() {
    super.initState();
    //apin = getAllPersonInHouse();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    print('hello house page!');

    //เช้คว่า จำนวนห้อและจำนวนอุปกรณ์มากกว่า 1 หรือป่าว เพราะหน่วยที่เป็นภาษาอังกฤษ ต้องเติม s
    String room = 'Room';
    String device = 'Device';

    if (widget.numRoom != '1' && widget.numRoom != '0') {
      room = 'Rooms';
    }
    if (widget.numDevice != '1' && widget.numDevice != '0') {
      device = 'Devices';
    }

    return Container(
      width: size.width,
      height: size.height,
      color: Colors.white,
      child: FutureBuilder(
        future: getAllPersonInHouse(),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.data != null) {
              myRole = myRoleList
                  .where(
                      (element) => element['userid'] == int.parse(mainUserId))
                  .toList();
              //array of only selected items
              print('mainUserId: $mainUserId');
              print('MyRole: ${myRole[0]['role']}');
              return Scaffold(
                appBar: AppBar(
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    color: Colors.black,
                    onPressed: () {
                      removeCookie('ownHouseUid');
                      Navigator.of(context).pop();
                    },
                  ),
                  actions: <Widget>[
                    IconButton(
                      icon: const Icon(
                        Icons.edit,
                        color: Colors.black,
                      ),
                      onPressed: () {
                        houseNameController.clear();
                        //popup สำหรับการเปลี่ยนชื่อบ้าน
                        showModalBottomSheet(
                            isDismissible: false,
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(25.0))),
                            backgroundColor: Colors.white,
                            context: context,
                            isScrollControlled: true,
                            builder: (BuildContext context) {
                              return StatefulBuilder(
                                  builder: (BuildContext context, setStatePOP) {
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      //Edit house name text
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12.0),
                                        child: Container(
                                          width: size.width,
                                          height: size.height * 0.08,
                                          //color: Colors.red,
                                          alignment: Alignment.center,
                                          child: const Text(
                                            'Edit house name',
                                            style: TextStyle(
                                                fontSize: 24,
                                                fontWeight: FontWeight.w600),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      //textfield
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12.0),
                                        child: Container(
                                          width: size.width * 0.9,
                                          height: size.height * 0.08,
                                          alignment: Alignment.center,
                                          //margin: const EdgeInsets.only(top: 15),
                                          decoration: BoxDecoration(
                                            color: Colors.black12,
                                            borderRadius:
                                                BorderRadius.circular(20),
                                          ),
                                          padding: const EdgeInsets.only(
                                              left: 20, right: 20),
                                          child: TextField(
                                            controller:
                                                houseNameController, //อาจจะไม่ได้ใช้
                                            onChanged: (text) {
                                              setStatePOP(() {
                                                //for check controller change
                                              });
                                            },
                                            //enableSuggestions: false,
                                            //autocorrect: false,
                                            decoration: const InputDecoration(
                                              hintStyle: TextStyle(
                                                  color: Colors.black38,
                                                  fontSize: 24,
                                                  fontWeight: FontWeight.w600),
                                              hintText: 'New house name',
                                              border: InputBorder.none,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 10),

                                      //bt
                                      Padding(
                                          padding: EdgeInsets.only(
                                              bottom: MediaQuery.of(context)
                                                  .viewInsets
                                                  .bottom),
                                          child: Container(
                                            width: size.width * 0.9,
                                            height: size.height * 0.08,
                                            alignment: Alignment.center,
                                            //color: Colors.yellowAccent,
                                            padding: const EdgeInsets.only(
                                                left: 10, right: 10),
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: size.width * 0.38,
                                                  height: size.height * 0.07,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                    color: const Color.fromARGB(
                                                        255, 189, 189, 189),
                                                  ),
                                                  child: TextButton(
                                                      style: ButtonStyle(
                                                          shape: MaterialStateProperty.all<
                                                                  RoundedRectangleBorder>(
                                                              RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20),
                                                      ))),
                                                      child: const Text(
                                                        'Cancel',
                                                        style: TextStyle(
                                                            fontSize: 24,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    35,
                                                                    35,
                                                                    35)),
                                                      ),
                                                      onPressed: () {
                                                        Navigator.of(context)
                                                            .pop();
                                                      }),
                                                ),
                                                const Spacer(),
                                                if (houseNameController.text !=
                                                    '') ...{
                                                  Container(
                                                    width: size.width * 0.38,
                                                    height: size.height * 0.07,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                      color:
                                                          const Color.fromARGB(
                                                              255,
                                                              117,
                                                              138,
                                                              214),
                                                    ),
                                                    child: TextButton(
                                                        style: ButtonStyle(
                                                            shape: MaterialStateProperty.all<
                                                                    RoundedRectangleBorder>(
                                                                RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(20),
                                                        ))),
                                                        child: const Text(
                                                          'Ok',
                                                          style: TextStyle(
                                                              fontSize: 24,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                        onPressed: () async {
                                                          //setstate
                                                          var c = await editNameHouseApi(
                                                              nameHouse ??
                                                                  widget
                                                                      .nameHouse,
                                                              houseNameController
                                                                  .text);

                                                          if (c) {
                                                            setState(() {
                                                              nameHouse =
                                                                  houseNameController
                                                                      .text;
                                                            });
                                                          }

                                                          houseNameController
                                                              .clear();

                                                          //close popup
                                                          Navigator.of(context)
                                                              .pop();
                                                        }),
                                                  ),
                                                } else ...{
                                                  //can't press
                                                  Container(
                                                    width: size.width * 0.38,
                                                    height: size.height * 0.07,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                      color:
                                                          const Color.fromARGB(
                                                              122,
                                                              117,
                                                              138,
                                                              214),
                                                    ),
                                                    child: TextButton(
                                                        style: ButtonStyle(
                                                            shape: MaterialStateProperty.all<
                                                                    RoundedRectangleBorder>(
                                                                RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(20),
                                                        ))),
                                                        child: const Text(
                                                          'Ok',
                                                          style: TextStyle(
                                                              fontSize: 24,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                        onPressed: () => false),
                                                  ),
                                                }
                                              ],
                                            ),
                                          )),
                                      const SizedBox(height: 10),
                                    ],
                                  ),
                                );
                              });
                            }).then((value) => {setState(() {})});
                      },
                    )
                  ],
                  toolbarHeight: size.height * 0.075,
                  backgroundColor: Colors.white,
                  centerTitle: true,
                  elevation: 0, //remove shadow
                  title: Text(nameHouse ?? widget.nameHouse,
                      style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: Colors.black)),
                  iconTheme: const IconThemeData(
                      color: Color.fromARGB(255, 69, 47, 139)),
                ),
                body: Container(
                  width: size.width,
                  height: size.height * 0.88,
                  color: Colors.white,
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      //text "Connected devices" และแสดงจำนวน อุปกรณ์
                      Container(
                        width: size.width * 0.9,
                        height: size.height * 0.1,
                        //color: Colors.orange,
                        padding: const EdgeInsets.only(left: 10),
                        alignment: Alignment.center,
                        child: Row(children: [
                          const Text('Connected devices',
                              style: TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.w600)),
                          const Spacer(),
                          Text('${widget.numDevice} $device',
                              style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black38)),
                        ]),
                      ),

                      //เส้นสี
                      Container(
                        width: size.width * 0.9,
                        height: 2,
                        color: Colors.black26,
                      ),

                      //เว้นว่าง
                      SizedBox(
                        width: size.width,
                        height: 10,
                      ),

                      //text "Room" และแสดงจำนวนห้องและสามารกดเข้าไปดูรายการของห้องที่มีอยู่ในบ้านได้
                      TextButton(
                        onPressed: () {
                          print('go to manage room page');
                          Navigator.of(context)
                              .push(MaterialPageRoute(
                                  builder: (context) => const ManageRoomPage()))
                              .then((value) => {
                                    setState(
                                        () {}) //re-build when come back to this page
                                  });
                        },
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: size.width * 0.9,
                          height: size.height * 0.05,
                          //color: Colors.orange,
                          padding: const EdgeInsets.only(left: 10),
                          alignment: Alignment.center,
                          child: Row(children: [
                            const Text('Room',
                                style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black)),
                            const Spacer(),
                            Text('${widget.numRoom} $room',
                                style: const TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black38)),
                            const SizedBox(
                              width: 2,
                            ),
                            const Icon(
                              Icons.arrow_forward_ios,
                              size: 15,
                              color: Colors.black,
                            )
                          ]),
                        ),
                      ),

                      //ดูสมาชิกที่อยู่่ภายในบ้าน
                      TextButton(
                        onPressed: () {
                          print('go to person in the house page');
                          Navigator.of(context)
                              .push(MaterialPageRoute(
                                  builder: (context) =>
                                      const PersonInHousePage()))
                              .then((value) => {
                                    setState(
                                        () {}) //re-build when come back to this page
                                  });
                        },
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: size.width * 0.9,
                          height: size.height * 0.05,
                          //color: Colors.orange,
                          padding: const EdgeInsets.only(left: 10),
                          alignment: Alignment.center,
                          child: Row(children: [
                            const Text('Member',
                                style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black)),
                            const Spacer(),
                            Text("${snapshot.data} ",
                                style: const TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black38)),
                            const Icon(
                              Icons.person,
                              size: 25,
                              color: Colors.black,
                            ),
                            const SizedBox(
                              width: 2,
                            ),
                            const Icon(
                              Icons.arrow_forward_ios,
                              size: 15,
                              color: Colors.black,
                            )
                          ]),
                        ),
                      ),

                      //Location
                      //TODOWORK: go to edit map screen page
                      TextButton(
                        onPressed: () async {
                          // print('go to edit map screen page');
                          await getLocation();
                          // Navigator.of(context)
                          //     .push(MaterialPageRoute(
                          //         builder: (context) => EditMapScreen(
                          //               latOld: widget.lat,
                          //               longOld: widget.long,
                          //             )))
                          //     .then((value) => {
                          //           setState(
                          //               () {}) //re-build when come back to this page
                          //         });
                          _awaitReturnValueFromSecondScreen(context);
                        },
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: size.width * 0.9,
                          height: size.height * 0.05,
                          padding: const EdgeInsets.only(left: 10),
                          alignment: Alignment.center,
                          child: Row(children: [
                            const Text('Location',
                                style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black)),
                            const Spacer(),
                            Text(
                                "${latlng != null ? latlng!.latitude.toStringAsFixed(5) : widget.lat != null && widget.lat != "0" ? double.parse(widget.lat!).toStringAsFixed(5) : "latitude"},${latlng != null ? latlng!.longitude.toStringAsFixed(5) : widget.long != null && widget.long != "0" ? double.parse(widget.long!).toStringAsFixed(5) : "longitude"}",
                                style: const TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black38)),
                            const SizedBox(
                              width: 2,
                            ),
                            const Icon(
                              Icons.arrow_forward_ios,
                              size: 15,
                              color: Colors.black,
                            )
                          ]),
                        ),
                      ),

                      //เว้นระยะห่าง
                      const Spacer(),

                      //ปุ่มลบบ้าน
                      //เช้คจำนวนบ้านว่ามีกี่หลัง ถ้ามี 1หลัง จะไม่แสดงปุ่มลบบ้าน
                      //ถ้ามีมากกว่า 1 จะแสดงปุ่มลบบ้าน
                      //และต้องเป็นเจ้าของบ้านจึงจะลบบ้านได้
                      if (widget.numHouse != "1" &&
                          myRole[0]['role'] == "own") ...{
                        //able to delete this house
                        Container(
                          width: size.width * 0.8,
                          height: size.height * 0.07,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Color.fromARGB(255, 223, 223, 223)),
                          child: TextButton(
                              style: ButtonStyle(
                                  shape: MaterialStateProperty.all<
                                          RoundedRectangleBorder>(
                                      RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ))),
                              onPressed: () {
                                print('delete this house!');
                                showDialog<String>(
                                  barrierDismissible: false,
                                  context: context,
                                  builder: (BuildContext context) =>
                                      AlertDialog(
                                    //title: const Text('Something is worng!'),
                                    contentPadding: const EdgeInsets.only(
                                        left: 20, right: 20, top: 20),
                                    content: Container(
                                      //width: size.width,
                                      height: 80,
                                      alignment: Alignment.center,
                                      child: const Text(
                                        'Do you want to delete this house?',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.black),
                                      ),
                                    ),
                                    actions: <Widget>[
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Container(
                                            //width: size.width,
                                            alignment: Alignment.center,
                                            child: TextButton(
                                              onPressed: () {
                                                Navigator.pop(
                                                    context, 'Cancel');
                                              },
                                              child: const Text(
                                                'Cancel',
                                                style: TextStyle(
                                                    fontSize: 24,
                                                    fontWeight: FontWeight.w600,
                                                    color: Color.fromARGB(
                                                        255, 117, 138, 214)),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            //width: size.width,
                                            alignment: Alignment.center,
                                            child: TextButton(
                                              onPressed: () {
                                                //call api change email.com
                                                delHouseApi();
                                                Navigator.pop(context, 'ok');
                                              },
                                              child: const Text(
                                                'Ok',
                                                style: TextStyle(
                                                    fontSize: 24,
                                                    fontWeight: FontWeight.w600,
                                                    color: Color.fromARGB(
                                                        255, 117, 138, 214)),
                                              ),
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                );

                                //Navigator.of(context).pop();
                              },
                              child: const Text(
                                'Delete house',
                                style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.red),
                              )),
                        )
                      }
                    ],
                  ),
                ),
              );
            } else {
              return connectFailed();
            }
          } else {
            return loadingBox();
          }
        },
      ),
    );
  }

  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  if (move == 'move') {
                    //move to other page : main page
                    //mainFirstHouseClear();
                    Navigator.pop(context, 'Cancel');
                    // Navigator.pushReplacement(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => const ManageHouseMainPage()));
                  } else {
                    Navigator.pop(context, 'Cancel');
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //แสดงตอนเชื่อมต่อล้มเหลว snapshot = null
  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Connection failed!',
              style: TextStyle(fontSize: 24, color: Colors.black),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width * 0.3,
            height: size.height * 0.06,
            child: TextButton(
              style: TextButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                foregroundColor: Colors.white,
                padding: EdgeInsets.zero,
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {}); //กดปุ่มแล้วจะรีบิ้วใหม่
              },
              child: const Text(
                'Try again',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'FCfont',
                  fontSize: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          DefaultTextStyle(
            style: TextStyle(
                fontSize: 24, fontFamily: 'FCfont', color: Colors.black),
            child: Card(
              shadowColor: Colors.transparent,
              elevation: 0,
              child: Text(
                'Loading...',
                textAlign: TextAlign.center,
              ),
            ),
          )
        ],
      ),
    );
  }
}
