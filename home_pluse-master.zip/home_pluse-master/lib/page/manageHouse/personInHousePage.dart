import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../modelData/getAllPersonInHouseModel.dart';

class PersonInHousePage extends StatefulWidget {
  const PersonInHousePage({super.key});

  @override
  State<PersonInHousePage> createState() => _PersonInHousePageState();
}

class _PersonInHousePageState extends State<PersonInHousePage> {
  TextEditingController personEmailController =
      TextEditingController(); //เก็บอีเมลผู้ใช้งานที่ต้องการจะเพิ่มเข้าไปในบ้าน

  //Api function--------------------------------------------------------------
  var myRole; // บทบาท ของ เจ้าของ account ในบ้านหลังนี้
  var myRoleList; // list ข้อมูลของเจ้าของ account ที่ดึงมาจากข้อมูลของ api
  //edit name house api
  GetAllPersonInHouse? personList;
  Future<GetAllPersonInHouse?> getAllPersonInHouse() async {
    print('[getAllPersonInHouse] Im getAllPersonInHouse function');
    String temp = await getHouseId();
    mainUserId = await getUserId();
    String urlBase = await getUrlBase();
    //print('[getAllPersonInHouse] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/allPersonInHouse');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"houseid": temp});

      print('[getAllPersonInHouse] status Code : ${response.statusCode}');
      var jsonResponse = jsonDecode(response.body);
      if (response.statusCode == 200) {
        print(response.body);
        myRoleList = jsonResponse['data'].toList();
        print('[getAllPersonInHouse] myRoleList: $myRoleList');
        personList = getAllPersonInHouseFromJson(response.body);
        print('[getAllPersonInHouse] finsih!');
        //personList.sort((a, b) => a.someProperty.compareTo(b.userid));
        return personList;
        //edit already
      } else {
        //cant edit
        //maybe show popup
      }
      return personList;
    } catch (e) {
      print('[getAllPersonInHouse] error: $e');
      // return personList;
      return null;
      //cant edit
      //maybe show popup
    }
  }

  delPerson(useridPerson) async {
    print('[delPerson] Im getHouseListApi function');
    String tempHouseid = await getHouseId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/delPersonInHouse');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "houseid": tempHouseid.toString(),
            "useridPerson": useridPerson.toString()
          });

      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['message'].toString() == 'DELETE complete') {
        //pop up deleted already!
        popup('Delete this person already!', "no")
            .then((e) => {setState(() => {})});
      } else {
        //pop up  cannt delete!
        popup("Can't delete this person!\nSomething is wrong", "no");
      }
      print('[delPerson] finsih!');
    } catch (e) {
      print('[delPerson] error: $e');
      //pop up  cannt delete!
      popup("Can't delete this person!\nConnection failed.",
          'null'); //wrong code or can't connect to server.
    }
  }

  addPerson(email) async {
    String tempUid = await getUserId();
    String tempHouseid = await getHouseId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/addPersonInHouse');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "userid": tempUid.toString(), //เจ้าของบ้านเท่านั้น
            "houseid": tempHouseid.toString(),
            "email": email.toString()
          });

      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['message'].toString() == 'add success') {
        //pop up deleted already!
        popup('Add already!', "null").then((value) => {setState(() {})});
      } else if (jsonResponse['message'].toString() ==
          'dont found any user for email= $email') {
        popup("Can't add this person.\nWrong email.", "null");
      } else {
        //pop up  cannt delete!
        popup("Can't add this person!\nSomething is wrong", "null");
      }
    } catch (e) {
      print('[addPerson] error: $e');
      popup("Can't add this person!\nConnection failed.",
          'null'); //wrong code or can't connect to server.
    }
  }
  //-------------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  //รับค่า urlBase จาก localStorage
  //urlBase คือ url api ที่ใช้
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //รับค่า userId จาก localStorage ใช้ในการเพิ่มคนในบ้าน
  var mainUserId;
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var mainUserId = prefs.getString('userId');
    //print('[getUserId] userId: $userId');
    return mainUserId;
    //prefs.setString('accessToken', token);
  }

  //รับค่า mainHouseid จาก localStorage ใช้ในการเพิ่มคนในบ้าน
  getHouseId() async {
    print('[getHouseId] Im in  getHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var houseid = prefs.getString('houseid');
    //print('[getHouseId] mainNameHouse: $mainNameHouse');
    return houseid.toString();
    //prefs.setString('accessToken', token);
  }

  //  getHouseId() async {
  //   print('[getHouseId] Im in  getHouseId');
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   houseid = prefs.getString('houseid');
  //   print('[getHouseId] houseid: $houseid');
  //   return houseid.toString();
  //   //prefs.setString('accessToken', token);
  // }
  //--------------------------------------------------------------------------

  var apih; // all person in house
  @override
  void initState() {
    super.initState();
    // apih = getAllPersonInHouse();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ

    return Container(
      width: size.width,
      height: size.height,
      color: Colors.white,
      child: FutureBuilder(
          future: getAllPersonInHouse(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              if (snapshot.data != null) {
                myRole = myRoleList
                    .where(
                        (element) => element['userid'] == int.parse(mainUserId))
                    .toList();
                //array of only selected items
                print('mainUserId: $mainUserId');
                print('MyRole: ${myRole[0]['role']}');
                return Scaffold(
                  appBar: AppBar(
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back),
                      color: Colors.black,
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    actions: [
                      if (myRole[0]['role'] == 'own') ...{
                        IconButton(
                            icon: const Icon(Icons.add),
                            color: Colors.black,
                            onPressed: () {
                              personEmailController.clear();
                              showModalBottomSheet(
                                  isDismissible: false,
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(25.0))),
                                  backgroundColor: Colors.white,
                                  context: context,
                                  isScrollControlled: true,
                                  builder: (BuildContext context1) {
                                    return StatefulBuilder(builder:
                                        (BuildContext context1, setStatePOP) {
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 12.0),
                                              child: Container(
                                                width: size.width,
                                                height: size.height * 0.08,
                                                //color: Colors.red,
                                                alignment: Alignment.center,
                                                child: const Text(
                                                  'Add member',
                                                  style: TextStyle(
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.w600),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 12.0),
                                              child: Container(
                                                width: size.width * 0.9,
                                                height: size.height * 0.08,
                                                alignment: Alignment.center,
                                                //margin: const EdgeInsets.only(top: 15),
                                                decoration: BoxDecoration(
                                                  color: Colors.black12,
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                ),
                                                padding: const EdgeInsets.only(
                                                    left: 20, right: 20),
                                                child: TextField(
                                                  controller:
                                                      personEmailController, //อาจจะไม่ได้ใช้
                                                  onChanged: (text) {
                                                    setStatePOP(() {
                                                      //for check controller
                                                    });
                                                  },
                                                  enableSuggestions: false,
                                                  autocorrect: false,
                                                  decoration:
                                                      const InputDecoration(
                                                    hintStyle: TextStyle(
                                                        color: Colors.black38,
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600),
                                                    hintText: "Person's email",
                                                    border: InputBorder.none,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 10),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    bottom:
                                                        MediaQuery.of(context1)
                                                            .viewInsets
                                                            .bottom),
                                                child: Container(
                                                  width: size.width * 0.9,
                                                  height: size.height * 0.08,
                                                  alignment: Alignment.center,
                                                  //color: Colors.yellowAccent,
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 10, right: 10),
                                                  child: Row(
                                                    children: [
                                                      Container(
                                                        width:
                                                            size.width * 0.38,
                                                        height:
                                                            size.height * 0.07,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(20),
                                                          color: const Color
                                                                  .fromARGB(255,
                                                              189, 189, 189),
                                                        ),
                                                        child: TextButton(
                                                            style: ButtonStyle(
                                                                shape: MaterialStateProperty.all<
                                                                        RoundedRectangleBorder>(
                                                                    RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          20),
                                                            ))),
                                                            child: const Text(
                                                              'Cancel',
                                                              style: TextStyle(
                                                                  fontSize: 24,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          35,
                                                                          35,
                                                                          35)),
                                                            ),
                                                            onPressed: () {
                                                              Navigator.of(
                                                                      context1)
                                                                  .pop();
                                                            }),
                                                      ),
                                                      const Spacer(),
                                                      if (personEmailController
                                                              .text !=
                                                          '') ...{
                                                        Container(
                                                          width:
                                                              size.width * 0.38,
                                                          height: size.height *
                                                              0.07,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20),
                                                            color: const Color
                                                                    .fromARGB(
                                                                255,
                                                                117,
                                                                138,
                                                                214),
                                                          ),
                                                          child: TextButton(
                                                              style:
                                                                  ButtonStyle(
                                                                      shape: MaterialStateProperty.all<
                                                                              RoundedRectangleBorder>(
                                                                          RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            20),
                                                              ))),
                                                              child: const Text(
                                                                'Ok',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        24,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                    color: Colors
                                                                        .white),
                                                              ),
                                                              onPressed: () {
                                                                //setstate
                                                                setStatePOP(() {
                                                                  //api add person here!
                                                                  addPerson(
                                                                      personEmailController
                                                                          .text);
                                                                });

                                                                //close popup
                                                                Navigator.of(
                                                                        context1)
                                                                    .pop();
                                                              }),
                                                        ),
                                                      } else ...{
                                                        Container(
                                                          width:
                                                              size.width * 0.38,
                                                          height: size.height *
                                                              0.07,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20),
                                                            color: const Color
                                                                    .fromARGB(
                                                                122,
                                                                117,
                                                                138,
                                                                214),
                                                          ),
                                                          child: TextButton(
                                                              style:
                                                                  ButtonStyle(
                                                                      shape: MaterialStateProperty.all<
                                                                              RoundedRectangleBorder>(
                                                                          RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            20),
                                                              ))),
                                                              child: const Text(
                                                                'Ok',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        24,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                    color: Colors
                                                                        .white),
                                                              ),
                                                              onPressed: () {
                                                                //notting
                                                              }),
                                                        ),
                                                      }
                                                    ],
                                                  ),
                                                )),
                                            const SizedBox(height: 10),
                                          ],
                                        ),
                                      );
                                    });
                                  }).then(
                                (value) {
                                  setState(() {});
                                },
                              );
                            })
                      }
                    ],
                    toolbarHeight: size.height * 0.075,
                    backgroundColor: Colors.white,
                    centerTitle: true,
                    elevation: 0, //remove shadow
                    title: const Text('Member',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Colors.black)),
                    iconTheme: const IconThemeData(
                        color: Color.fromARGB(255, 69, 47, 139)),
                  ),
                  body: Container(
                    width: size.width,
                    height: size.height,
                    color: Colors.white,
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: Column(children: [
                      for (int i = 0; i < snapshot.data.data.length; i++) ...{
                        memberBox(
                            myRole[0]['role'],
                            snapshot.data.data[i].userName,
                            snapshot.data.data[i].email,
                            snapshot.data.data[i].role,
                            snapshot.data.data[i].userid)
                      }
                    ]),
                  ),
                );
              } else {
                return connectFailed();
              }
            } else {
              return loadingBox();
            }
          }),
    );
  }

  //mianUserId = userid ของผู้ใช้งานในตอนนี้
  //userId = userid ที่รับมาจาก api
  memberBox(mainRole, username, gmail, role, useridPerson) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    String roleText = '';
    if (role == "own") {
      roleText = "(own)";
    }
    return Container(
      width: size.width * 0.9,
      height: size.height * 0.12,
      padding: const EdgeInsets.only(left: 10, right: 10),
      //color: Colors.red,
      child: Column(children: [
        SizedBox(
          width: size.width,
          height: 20,
        ),
        Row(
          children: [
            Container(
              width: size.width * 0.6,
              //color: Colors.red,
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                //mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Text(
                        "$username ",
                        style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      ),
                      Text(
                        roleText,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: Color.fromARGB(255, 117, 138, 214),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 5),
                    child: Text(
                      gmail,
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black38),
                    ),
                  )
                ],
              ),
            ),
            const Spacer(),
            if (role != "own") ...{
              if (mainRole == "own") ...{
                IconButton(
                  icon: const Icon(
                    Icons.delete,
                    size: 25,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    //deleted
                    showDialog<String>(
                      barrierDismissible: false,
                      context: context,
                      builder: (BuildContext context) => AlertDialog(
                        //title: const Text('Something is worng!'),
                        contentPadding:
                            const EdgeInsets.only(left: 20, right: 20, top: 20),
                        content: Container(
                          //width: size.width,
                          height: 80,
                          alignment: Alignment.center,
                          child: const Text(
                            'Do you want to delete this member from the house?',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                color: Colors.black),
                          ),
                        ),
                        actions: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                //width: size.width,
                                alignment: Alignment.center,
                                child: TextButton(
                                  onPressed: () {
                                    //call api delete

                                    Navigator.pop(context, 'Cancel');
                                  },
                                  child: const Text(
                                    'Cancel',
                                    style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.w600,
                                        color:
                                            Color.fromARGB(255, 117, 138, 214)),
                                  ),
                                ),
                              ),
                              Container(
                                //width: size.width,
                                alignment: Alignment.center,
                                child: TextButton(
                                  onPressed: () {
                                    //call api delete
                                    delPerson(useridPerson);
                                    Navigator.pop(context, 'Cancel');
                                  },
                                  child: const Text(
                                    'Ok',
                                    style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.w600,
                                        color:
                                            Color.fromARGB(255, 117, 138, 214)),
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    );
                  },
                )
              }
            }
          ],
        ),
        const Spacer(),
        Container(
          width: size.width * 0.9,
          height: 1,
          color: Colors.black26,
        ),
      ]),
    );
  }

  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context, 'Cancel');
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Connection failed!',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width * 0.3,
            height: size.height * 0.06,
            child: TextButton(
              style: TextButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                foregroundColor: Colors.white,
                padding: EdgeInsets.zero,
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {});
              },
              child: const Text(
                'Try again',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'FCfont',
                  fontSize: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Loading...',
              style: TextStyle(
                  fontSize: 24, fontFamily: 'FCfont', color: Colors.black),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }
}
