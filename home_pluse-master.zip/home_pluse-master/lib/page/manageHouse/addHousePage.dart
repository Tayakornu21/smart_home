import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:homeplus_phase1/page/manageHouse/mapScreen.dart';
import 'package:homeplus_phase1/modelData/getHouseListModel.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AddHousePage extends StatefulWidget {
  const AddHousePage({super.key});

  @override
  State<AddHousePage> createState() => _AddHousePageState();
}

class _AddHousePageState extends State<AddHousePage> {
  //String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";
  String? nameHouse;
  TextEditingController houseNameController = TextEditingController();
  LatLng? latlng;

  //Api function ---------------------------------------------------------------
  GetHouseListModel? houseList;
  Future<GetHouseListModel?> getHouseListApi() async {
    print('[getHouseListApi] Im getHouseListApi function');
    String temp = await getUserId();
    String urlBase = await getUrlBase();
    print('[getHouseListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/house');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "userid": temp,
          });

      print('[getHouseListApi] status Code : ${response.statusCode}');
      //print('[getHouseListApi] response body : ${response.body}');
      if (response.statusCode == 200) {
        print(response.body);
        houseList = getHouseListModelFromJson(response.body);
        // for (int i = 0; i < houseList!.data.length; i++) {
        //   houseNameList.add(houseList!.data[i].houseName);
        // }
        print('[getHouseListApi] finsih!');
        return houseList;
      } else {
        //err
        return null;
      }

      //return houseList;
    } catch (e) {
      print('[getHouseListApi] error: $e');
      return null;
    }
  }

  //add house api
  addHouse(houseName) async {
    print('[addHouse] Im in addHouse');
    String tempUid = await getUserId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/addHouse');

    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: latlng != null
              ? {
                  "userid": tempUid,
                  "houseName": houseName,
                  "latitude": latlng!.latitude.toString(),
                  "longitude": latlng!.longitude.toString(),
                }
              : {
                  "userid": tempUid,
                  "houseName": houseName,
                });

      print('[addHouse] status Code : ${response.statusCode}');
      print('[addHouse] res body : ${response.body}');

      var jsonResponse = jsonDecode(
          response.body); //decode json(change String json to map json)

      if (jsonResponse['error'] == false) {
        print('[addHouse] finsih!');
        Navigator.pop(context, 'Cancel'); //pop out to manage house paeg
        //show popup
        popup('Add the house complete', 'null'); //add house complete
      } else {
        if (jsonResponse['message'] ==
            "Data too long for column 'houseName' at row 1") {
          popup("Can't add the house!\nThe name is too long.",
              'null'); //wrong status code
        } else {
          popup("Can't add the house!\nSomething is worng",
              'null'); //wrong status code
        }
      }
    } catch (e) {
      print('[addHouse] error: $e');
      popup("Can't add the house!\nConnection failed", 'null');
    }
  }
  //----------------------------------------------------------------------------

  //localStorage function-------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //get userid
  var userId; //check login
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userId = prefs.getString('userId');
    print('[getUserId] userId: $userId');
    return userId.toString();
    //prefs.setString('accessToken', token);
  }

  //----------------------------------------------------------------------------

  late Position userLocation;
  //การใช้งาน Geolocator สำหรับดึงพิกัดปัจจุบันของผู้ใช้งานจากโทรศัพท์ ด้วยการใช้งาน Future
  Future<Position?> getLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // return Future.error(
      //     'Location permissions are permanently denied, we cannot request permissions.');
    }

    // userLocation = await Geolocator.getCurrentPosition();
    // final GoogleMapController controller = await _controller.future;
    // controller.animateCamera(
    //   CameraUpdate.newCameraPosition(
    //     CameraPosition(
    //       target: LatLng(userLocation.latitude, userLocation.longitude),
    //       zoom: 15,
    //     ),
    //   ),
    // );
    return null; //userLocation
  }

  //รับค่าจากหน้าถัดไป
  void _awaitReturnValueFromSecondScreen(BuildContext context) async {
    // start the SecondScreen and wait for it to finish with a result
    final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MapScreen(
            latLngOld: latlng,
          ),
        ));

    // after the SecondScreen result comes back update the Text widget with it
    setState(() {
      latlng = result;
      //lat = latlng!.latitude.toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.of(context).pop(),
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow
        title: const Text('Add house',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: Container(
        width: size.width,
        height: size.height * 0.85,
        color: Colors.white,
        padding: const EdgeInsets.only(top: 0, bottom: 10, left: 10, right: 10),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          //name device//
          Container(
            width: size.width * 0.9,
            height: size.height * 0.08,
            //color: Colors.orange,
            padding: const EdgeInsets.only(left: 10),
            alignment: Alignment.center,
            child: Row(
              children: [
                const Text('Name',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                const Spacer(),
                TextButton(
                  onPressed: () {
                    houseNameController.clear();
                    //popup สำหรับพิมชื่อห้อง
                    showModalBottomSheet(
                        isDismissible: false,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(25.0))),
                        backgroundColor: Colors.white,
                        context: context,
                        isScrollControlled: true,
                        builder: (BuildContext context) {
                          return StatefulBuilder(
                              builder: (BuildContext context, setState) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width,
                                      height: size.height * 0.08,
                                      //color: Colors.red,
                                      alignment: Alignment.center,
                                      child: const Text(
                                        'House name',
                                        style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0),
                                    child: Container(
                                      width: size.width * 0.9,
                                      height: size.height * 0.08,
                                      alignment: Alignment.center,
                                      //margin: const EdgeInsets.only(top: 15),
                                      decoration: BoxDecoration(
                                        color: Colors.black12,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      padding: const EdgeInsets.only(
                                          left: 20, right: 20),
                                      child: TextField(
                                        controller:
                                            houseNameController, //อาจจะไม่ได้ใช้
                                        onChanged: (text) {
                                          setState(() {
                                            //for check controller
                                          });
                                        },
                                        enableSuggestions: false,
                                        autocorrect: false,
                                        decoration: const InputDecoration(
                                          hintStyle: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 24,
                                              fontWeight: FontWeight.w600),
                                          hintText: 'House name',
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          bottom: MediaQuery.of(context)
                                              .viewInsets
                                              .bottom),
                                      child: Container(
                                        width: size.width * 0.9,
                                        height: size.height * 0.08,
                                        alignment: Alignment.center,
                                        //color: Colors.yellowAccent,
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: size.width * 0.38,
                                              height: size.height * 0.07,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                color: const Color.fromARGB(
                                                    255, 189, 189, 189),
                                              ),
                                              child: TextButton(
                                                  style: ButtonStyle(
                                                      shape: MaterialStateProperty.all<
                                                              RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ))),
                                                  child: const Text(
                                                    'Cancel',
                                                    style: TextStyle(
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: Color.fromARGB(
                                                            255, 35, 35, 35)),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  }),
                                            ),
                                            const Spacer(),
                                            if (houseNameController.text !=
                                                '') ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      255, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () {
                                                      //setstate
                                                      setState(() {
                                                        nameHouse =
                                                            houseNameController
                                                                .text;
                                                      });

                                                      //close popup
                                                      Navigator.of(context)
                                                          .pop();
                                                    }),
                                              ),
                                            } else ...{
                                              Container(
                                                width: size.width * 0.38,
                                                height: size.height * 0.07,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: const Color.fromARGB(
                                                      122, 117, 138, 214),
                                                ),
                                                child: TextButton(
                                                    style: ButtonStyle(
                                                        shape: MaterialStateProperty.all<
                                                                RoundedRectangleBorder>(
                                                            RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ))),
                                                    child: const Text(
                                                      'Ok',
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white),
                                                    ),
                                                    onPressed: () {
                                                      //notting
                                                    }),
                                              ),
                                            }
                                          ],
                                        ),
                                      )),
                                  const SizedBox(height: 10),
                                ],
                              ),
                            );
                          });
                        });
                  },
                  child: Row(
                    children: [
                      Container(
                          width: size.width * 0.6,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(left: 5),
                          //color: Colors.yellow,
                          child: Text(
                            nameHouse ?? 'Specify house name',
                            style: const TextStyle(
                                color: Colors.black38, fontSize: 24),
                          )),
                      //const Spacer(),
                      Container(
                          width: size.width * 0.055,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          //color: Colors.blue,
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: Colors.black,
                          ))
                    ],
                  ),
                )
              ],
            ),
          ),

          //location
          Container(
            width: size.width * 0.9,
            height: size.height * 0.08,
            //color: Colors.orange,
            padding: const EdgeInsets.only(left: 10),
            alignment: Alignment.center,
            child: Row(
              children: [
                const Text('Position',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                const Spacer(),
                TextButton(
                  onPressed: () async {
                    //go map page
                    await getLocation();
                    _awaitReturnValueFromSecondScreen(context);
                    // Navigator.of(context).push(MaterialPageRoute(
                    //     builder: (context) => const MapScreen()));
                  },
                  child: Row(
                    children: [
                      Container(
                          width: size.width * 0.6,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(left: 5),
                          //color: Colors.yellow,
                          child: Text(
                            // (OK) TODOWORK: เปลี่ยนตัวแปร
                            latlng != null
                                ? '${latlng!.latitude.toStringAsFixed(4)}, ${latlng!.longitude.toStringAsFixed(4)}'
                                : 'latitude, longitude  ',
                            style: const TextStyle(
                                color: Colors.black38, fontSize: 24),
                          )),
                      //const Spacer(),
                      Container(
                          width: size.width * 0.055,
                          height: size.height * 0.074,
                          alignment: Alignment.centerRight,
                          //color: Colors.blue,
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: Colors.black,
                          ))
                    ],
                  ),
                )
              ],
            ),
          ),

          //เว้นระยะห่าง
          const Spacer(),

          //bt เช้คว่าได้ nameHouse ว่างหรือป่าว ถ้าว่างจะไม่สามารถกดปุมเพ่ิมได้
          if (nameHouse != null) ...{
            //กดได้
            Container(
              width: size.width * 0.8,
              height: size.height * 0.07,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color.fromARGB(255, 117, 138, 214)),
              child: TextButton(
                  style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ))),
                  child: const Text(
                    'Add',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Colors.white),
                  ),
                  onPressed: () async {
                    print('comeback to manage house main page');
                    //send add api
                    //pop up for confirm add
                    //go to main page
                    var nameHouseList = await getHouseListApi();
                    //print(nameHouseList.runtimeType);
                    var contain = nameHouseList?.data.indexWhere(
                        (element) => element.houseName == nameHouse);
                    //print(contain); //-1 = ยังไม่มีค่าใน List นั้นๆ

                    if (contain.toString() == "-1") {
                      addHouse(nameHouse);
                    } else {
                      popup("This name is already taken.", "null");
                    }

                    //
                  }),
            )
          } else ...{
            //กดไม่ได้
            Container(
              width: size.width * 0.8,
              height: size.height * 0.07,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color.fromARGB(122, 117, 138, 214)),
              child: TextButton(
                  style: ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ))),
                  onPressed: null,
                  child: const Text(
                    'Add',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Colors.white),
                  )),
            )
          }
        ]),
      ),
    );
  }

  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => WillPopScope(
        onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
        child: AlertDialog(
          //title: const Text('Something is worng!'),
          contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          content: Container(
            //width: size.width,
            height: 80,
            alignment: Alignment.center,
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
          actions: <Widget>[
            Container(
              //width: size.width,
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  if (move == 'move') {
                    //move to other page : main page
                    // Navigator.pushReplacement(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) =>
                    //             const NavigationBottomBarWidget()));
                  } else {
                    Navigator.pop(context, 'Cancel');
                  }
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
