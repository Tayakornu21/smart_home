import 'dart:async';
import 'dart:convert';
// import 'dart:ffi' as Double;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class EditMapScreen extends StatefulWidget {
  const EditMapScreen({super.key, required this.latOld, required this.longOld});

  // final LatLng? latLngOld;
  final String? latOld, longOld;

  @override
  State<EditMapScreen> createState() => _EditMapScreenState();
}

class _EditMapScreenState extends State<EditMapScreen> {
  late LatLng latLng;
  LatLng? latLngOld;
  bool getMark = false;

  //LocationData เพื่อใช้เก็บข้อมูลเกี่ยวกับตำแหน่ง
  late LocationData currentPosition;
  late LocationData currentLocation;

  //Marker เพื่อใช้ตั้งค่าเวลาแสดงมาร์คเกอร์บนแผนที่ google map
  late Marker marker;
  //สร้างลิสต์เพื่อเก็บมาร์คเกอร์
  List<Marker> myMarker = [];

  //ดึงตำแหน่ง location โดยใช้ location.getLocation() ซึ่งต้องระวังกรณีไม่มี permission ด้วย
  Future<LocationData?> getCurrentLocation() async {
    Location location = Location();
    try {
      return await location.getLocation();
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        // Permission denied
      }
      return null;
    }
  }

  //
  editLatLng(latLng, context) async {
    print('[editLatLng] Im in editLatLng');
    String tempHouseId = await getHouseId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/editHouseLatLong');
    print(tempHouseId);
    print(latLng!.latitude.toString());
    print(latLng!.longitude.toString());

    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "houseid": tempHouseId,
            "houseNewLat": latLng!.latitude.toString(),
            "houseNewLong": latLng!.longitude.toString(),
          });

      print('[editLatLng] status Code : ${response.statusCode}');
      print('[editLatLng] res body: ${response.body}');
      if (response.statusCode == 200) {
        print('[editLatLng] finsih!');
        Navigator.pop(context, latLng); 
        //show popup
        popup('Edit Location complete', 'null'); 
      } else {
        popup('Something is wrong!\nPlease try again.',
            'null'); //wrong status code
      }
    } catch (e) {
      print('[editLatLng] error: $e');
      popup("Can't edit Location !\nPlease check your connection.",
          'null'); //wrong code or can't connect to server.
    }
  }

  getHouseId() async {
    print('[getHouseId] Im in  getHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('houseid').toString();
    //prefs.setString('accessToken', token);
  }

  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  double? latitudeOld;
  double? longitudeOld;

  @override
  void initState() {
    super.initState();
    latitudeOld = double.parse(widget.latOld ?? "0.00");
    longitudeOld = double.parse(widget.longOld ?? "0.00");

    if (latitudeOld != 0.00 && latitudeOld != 0.00) {
      latLngOld = LatLng(latitudeOld!, longitudeOld!);
      myMarker.add(
        Marker(
          markerId: MarkerId(latLngOld.toString()),
          position:
              latLngOld ?? const LatLng(16.748085837511482, 100.19215890103426),
          draggable: true,
          //ไอคอนหมุด
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          onDragEnd: (dragEndPosition) {
            setState(() {
              print(dragEndPosition);
            });
          },
        ),
      );
    } else {
      print("lat and long itudeOld is 0.00");
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          TextButton(
            //ปุ่มเซฟ
            onPressed: getMark
                ? () {
                    print('latlng: $latLng');
                    //TODOWORK: CALL API
                    editLatLng(latLng, context);
                    //TODOWORK: POP TO PRERIOUS PAGE
                    // Navigator.pop(context, latLng);
                  }
                : null,
            child: Text(
              "Save",
              style: TextStyle(
                color: getMark
                    ? const Color.fromARGB(255, 117, 138, 214)
                    : Colors.black38,
                fontWeight: FontWeight.w800,
              ),
            ),
          )
        ],
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        title: const Text('Edit Location Point',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: latLngOld ??
              const LatLng(16.748085837511482,
                  100.19215890103426), //พิกัดมหาวิทยาลัยนเรศวร
          zoom: 15,
        ),
        myLocationEnabled: true, //ปุ่ม
        markers: Set.from(myMarker),
        mapType: MapType.normal,
        onTap: _handleTap1,
      ),
    );
  }

  //TODOWORK: not print latlng
  _handleTap1(LatLng tappedPoint) {
    //ปริ้นท์ค่าแลติจูลองติจูด
    print(tappedPoint);
    setState(
      () {
        latLng = tappedPoint;
        getMark = true;
        myMarker = [];
        myMarker.add(
          Marker(
            markerId: MarkerId(tappedPoint.toString()),
            position: tappedPoint,
            draggable: true,
            //ไอคอนหมุด
            icon:
                BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
            onDragEnd: (dragEndPosition) {
              // setState(() {
              //   print(dragEndPosition);
              // });
            },
          ),
        );
      },
    );
  }

  //popup
  popup(text, move) {
    return showDialog<String>(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => AlertDialog(
        contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
        content: Container(
          height: 80,
          alignment: Alignment.center,
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 24, fontWeight: FontWeight.w600, color: Colors.black),
          ),
        ),
        actions: [
          if (move == 'ok') ...{
            //ok
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  alignment: Alignment.center,
                  child: TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Ok',
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: Color.fromARGB(255, 117, 138, 214)),
                    ),
                  ),
                ),
              ],
            ),
          } else ...{
            Container(
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context, 'Ok');
                },
                child: const Text(
                  'Ok',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Color.fromARGB(255, 117, 138, 214)),
                ),
              ),
            ),
          }
        ],
      ),
    );
  }
}
