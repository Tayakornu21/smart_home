import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/manageHouse/addHousePage.dart';
import 'package:homeplus_phase1/page/manageHouse/housePage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import '../../modelData/getHouseListModel.dart';

class ManageHouseMainPage extends StatefulWidget {
  const ManageHouseMainPage({super.key});

  @override
  State<ManageHouseMainPage> createState() => _ManageHouseMainPageState();
}

class _ManageHouseMainPageState extends State<ManageHouseMainPage> {
  //String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";

  //Api function ---------------------------------------------------------------
  //get list of house
  // List<String> houseNameList =[];
  GetHouseListModel? houseList;
  Future<GetHouseListModel?> getHouseListApi() async {
    print('[getHouseListApi] Im getHouseListApi function');
    String temp = await getUserId();
    String urlBase = await getUrlBase();
    print('[getHouseListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/house');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {
            "userid": temp,
          });

      print('[getHouseListApi] status Code : ${response.statusCode}');
      //print('[getHouseListApi] response body : ${response.body}');
      if (response.statusCode == 200) {
        print(response.body);
        houseList = getHouseListModelFromJson(response.body);
        // for (int i = 0; i < houseList!.data.length; i++) {
        //   houseNameList.add(houseList!.data[i].houseName);
        // }
        print('[getHouseListApi] finsih!');
      } else {
        //err
      }

      return houseList;
    } catch (e) {
      print('[getHouseListApi] error: $e');
      return null;
    }
  }

  //get num room
  //รับ list ของ ห้อง แต่เราใช้ จำนวนห้อง
  Future<String?> getRoomListApi(uidOwn, hid) async {
    //print('[getRoomListApi] Im getRoomListApi function');
    //String temp = await getUserId();
    //print('[getRoomListApi] temp: $temp');
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/deviceRooms');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": uidOwn, "houseid": hid});

      //print('[getRoomListApi] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        //print(response.body);
        var jsonResponse = jsonDecode(response.body);
        print('[getRoomListApi] finsih!');
        return jsonResponse['data'].length.toString();
      } else {
        return '-';
      }
    } catch (e) {
      print('[getRoomListApi] error: $e');
      return '-';
    }
  }

  //get num device
  //รับ list ของ อุปกรณ์ แต่เราใช้ จำนวนอุปกรณ์
  Future<String?> getDeviceListApi(hid) async {
    //print('[getDeviceListApi] Im getDeviceListApi function');
    String temp = await getUserId();
    String urlBase = await getUrlBase();
    //print('[getDeviceListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/myDevices');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": temp, "houseid": hid});

      //print('[getDeviceListApi] status Code : ${response.statusCode}');
      if (response.statusCode == 200) {
        //print(response.body);
        var jsonResponse = jsonDecode(response.body);
        print('[getDeviceListApi] finsih!');
        return jsonResponse['data'].length.toString();
      } else {
        return '-';
      }
    } catch (e) {
      print('[getDeviceListApi] error: $e');
      return '-';
    }
  }

  //----------------------------------------------------------------------------

  //localStorage function--------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  //get userid
  var userId; //check login
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userId = prefs.getString('userId');
    print('[getUserId] userId: $userId');
    return userId.toString();
    //prefs.setString('accessToken', token);
  }

  //----------------------------------------------------------------------------

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    print('Welcome to ManageHouseMainPage'); //check re-build

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.of(context).pop(),
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow
        title: const Text('Manage house',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: FutureBuilder(
          future: getHouseListApi(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              if (snapshot.data != null) {
                return Container(
                  width: size.width,
                  height: size.height,
                  color: Colors.white,
                  child: ListView(children: [
                    Container(
                      width: size.width,
                      height: size.height * 0.05,
                      //color: Colors.yellow,
                      padding:
                          const EdgeInsets.only(left: 25, right: 25, top: 10),
                      alignment: Alignment.centerLeft,
                      child: const Text(
                        'My family',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.black38),
                      ),
                    ),
                    if (snapshot.data.data.length == 0) ...{
                      SizedBox(
                        width: size.width,
                        height: size.height * 0.7,
                        child:const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text("Don't have any house.",
                                  style: TextStyle(
                                      fontSize: 24,
                                      color: Color.fromARGB(255, 180, 180, 220),
                                      fontWeight: FontWeight.w600))
                            ]),
                      )
                    } else ...{
                      //วนลูปนำรายการของ บ้านมาแสดง
                      for (int i = 0; i < snapshot.data.data.length; i++) ...{
                        //add name house to list

                        //house box
                        FutureBuilder(
                            future: Future.wait([
                              getRoomListApi(
                                  snapshot.data.data[i].userid.toString(),
                                  snapshot.data.data[i].houseid
                                      .toString()), //snapshotSub[0]
                              getDeviceListApi(snapshot.data.data[i].houseid
                                  .toString()) //snapshotSub[1]
                            ]),
                            builder: (BuildContext context,
                                AsyncSnapshot<dynamic> snapshotSub) {
                              if (snapshotSub.connectionState ==
                                  ConnectionState.done) {
                                return houseBox(
                                    ownHouseUid: snapshot.data.data[i].userid,
                                    nameHosue: snapshot.data.data[i].houseName,
                                    houseid: snapshot.data.data[i].houseid,
                                    numHouse: snapshot.data.myHouse.length,
                                    numRoom: snapshotSub.data[0],
                                    numDevice: snapshotSub.data[1],
                                    lat: snapshot.data.data[i].latitude,
                                    long: snapshot.data.data[i].longitude);
                              } else {
                                return Container();
                              }
                            })
                      },
                    }
                  ]),
                );
              } else {
                return connectFailed();
              }
            } else {
              return const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 5),
                    Text(
                      'Loading...',
                      style: TextStyle(fontSize: 24),
                      textAlign: TextAlign.center,
                    )
                  ],
                ),
              );
            }
          }),
      //ปุ่มกดเพิ่มบ้าน
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // go to add house
          Navigator.of(context)
              .push(
                  MaterialPageRoute(builder: (context) => const AddHousePage()))
              .then((value) {
            setState(() {});
          });
        },
        backgroundColor: const Color.fromARGB(255, 117, 138, 214),
        child: const Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
    );
  }

  houseBox(
      {ownHouseUid,
      nameHosue,
      houseid,
      numHouse,
      numRoom,
      numDevice,
      lat,
      long}) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ

    //เช้คว่า จำนวนห้อและจำนวนอุปกรณ์มากกว่า 1 หรือป่าว เพราะหน่วยที่เป็นภาษาอังกฤษ ต้องเติม s
    String room = 'Room';
    String device = 'Device';
    if (numRoom != '1' && numRoom != '0') {
      room = 'Rooms';
    }
    if (numDevice != '1' && numDevice != '0') {
      device = 'Devices';
    }
    return SizedBox(
      width: size.width,
      height: 90,
      //color: Colors.red,
      child: TextButton(
        onPressed: () async {
          //set local houseid
          SharedPreferences prefs = await SharedPreferences.getInstance();
          prefs.setString('houseid', houseid.toString());
          prefs.setString('ownHouseUid', ownHouseUid.toString());
          //go to house page
          Navigator.of(context)
              .push(MaterialPageRoute(
                  builder: (context) => HousePage(
                        nameHouse: nameHosue.toString(),
                        numHouse: numHouse.toString(),
                        numRoom: numRoom.toString(),
                        numDevice: numDevice.toString(),
                        lat: lat,
                        long: long,
                      )))
              .then((value) => {
                    setState(() {}) //re-build when come back to this page
                  });
        },
        child: Container(
          width: size.width,
          height: 90,
          padding:
              const EdgeInsets.only(left: 35, right: 35, top: 10, bottom: 5),
          child: Column(
            children: [
              Row(children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: size.width * 0.7,
                      child: Text(
                        nameHosue,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Colors.black),
                      ),
                    ),
                    Text(
                      '$numRoom $room/ $numDevice $device',
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black38),
                    )
                  ],
                ),
                const Spacer(),
                const Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.black,
                  size: 20,
                )
              ]),
              const Spacer(),
              Container(
                width: size.width,
                height: 2,
                color: Colors.black12,
              )
            ],
          ),
        ),
      ),
    );
  }

  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Connection failed!',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width * 0.3,
            height: size.height * 0.06,
            child: TextButton(
              style: TextButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                foregroundColor: Colors.white,
                padding: EdgeInsets.zero,
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {});
              },
              child: const Text(
                'Try again',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'FCfont',
                  fontSize: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
