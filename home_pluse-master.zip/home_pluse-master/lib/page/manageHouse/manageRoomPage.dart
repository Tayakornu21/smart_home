import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:homeplus_phase1/cookiesValue.dart';
import 'package:homeplus_phase1/modelData/getRoomListModel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class ManageRoomPage extends StatefulWidget {
  const ManageRoomPage({super.key});

  @override
  State<ManageRoomPage> createState() => _ManageRoomPageState();
}

class _ManageRoomPageState extends State<ManageRoomPage> {
  //String url = "http://203.154.158.166/api";
  //String url = "http://10.58.248.116:3000";
  List<dynamic> deviceList = []; //เก็บ List of device
  var filterDevice; //filter device โดยอ้างอิงจากรายชื่อของห้องใน roomlist

  //Api function----------------------------------------------------------------
  GetRoomListModel? roomList;
  Future<GetRoomListModel?> getRoomListApi() async {
    print('[getRoomListApi] Im getRoomListApi function');
    String tempUid = await getCookie('ownHouseUid');
    String tempHid = await getHouseId();
    String urlBase = await getUrlBase();
    Uri myUri = Uri.parse('$urlBase/deviceRooms');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": tempUid, "houseid": tempHid});

      print('[getRoomListApi] status Code : ${response.statusCode}');
      print('[getRoomListApi] res body : ${response.body}');

      if (response.statusCode == 200) {
        var c =
            await getDeviceListApi(); //เรียกใช้ฟังก์ชั่นนี้เพื่อ เก็บค่าของ list device ไว้ในตัวแปร deviceList
        if (!c) {
          throw Exception("get devices list api err");
        }
        //print(response.body);
        roomList = getRoomListModelFromJson(response.body);
        print('[getRoomListApi] finsih!');
      } else {
        //err
      }

      return roomList;
    } catch (e) {
      print('[getRoomListApi] error: $e');
      return null;
    }
  }

  getDeviceListApi() async {
    print('[getDeviceListApi] Im getDeviceListApi function');
    String temp = await getCookie('ownHouseUid');
    String hid = await getHouseId(); //get houseId current.
    String urlBase = await getUrlBase();
    print('[getDeviceListApi] temp: $temp');
    Uri myUri = Uri.parse('$urlBase/myDevices');
    try {
      http.Response response = await http.post(myUri,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          encoding: Encoding.getByName('utf-8'),
          body: {"userid": temp, "houseid": hid});

      print('[getDeviceListApi] status Code : ${response.statusCode}');
      print('[getDeviceListApi] response body : ${response.body}');
      var jsonResponse = jsonDecode(response.body);
      if (jsonResponse['error'].toString() == 'false') {
        for (int i = 0; i < jsonResponse['data'].length; i++) {
          deviceList.add(jsonResponse['data'][i]);
        }
        print(deviceList.toString());
        print('[getDeviceListApi] finsih!');
        return true;
      } else {
        return false;
      }
    } catch (e) {
      print('[getDeviceListApi] error: $e');
      return false;
    }
  }

  //----------------------------------------------------------------------------

  //localStorage function--------------------------------------------------------
  getUrlBase() async {
    print('[getUrlBase] Im in  getUrlBase');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var urlBase = prefs.getString('urlBase');
    return urlBase.toString();
  }

  var houseid; //check login
  getHouseId() async {
    print('[getHouseId] Im in  getHouseId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    houseid = prefs.getString('houseid');
    print('[getHouseId] houseid: $houseid');
    return houseid.toString();
    //prefs.setString('accessToken', token);
  }

  //get userid
  var userId; //check login
  getUserId() async {
    print('[getUserId] Im in  getUserId');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userId = prefs.getString('userId');
    print('[getUserId] userId: $userId');
    return userId.toString();
    //prefs.setString('accessToken', token);
  }

  //----------------------------------------------------------------------------

  // //filter device in a room
  filterDeviceFunction(String nR) {
    //เป็นการหาจำนวนของอุปกรณ์ที่มีอยู่ในแต่ละห้อง
    //nR = name room
    filterDevice = deviceList.where((map) => nR.contains(map["room"])).toList();
    return filterDevice.length.toString();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.of(context).pop(),
        ),
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0, //remove shadow
        title: const Text('Room',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: Container(
          width: size.width,
          height: size.height,
          color: Colors.white,
          padding: const EdgeInsets.only(bottom: 10),
          child: FutureBuilder(
            future: getRoomListApi(),
            builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                if (snapshot.data != null) {
                  if (snapshot.data.data.length != 0) {
                    return ListView(children: [
                      for (int i = 0; i < snapshot.data.data.length; i++) ...{
                        roomBox(snapshot.data.data[i].room,
                            filterDeviceFunction(snapshot.data.data[i].room)),
                      }
                    ]);
                  } else {
                    return const Center(
                      child: Text(
                        "Don't have any rooms in this house.",
                        style: TextStyle(fontSize: 24, color: Colors.black38),
                      ),
                    );
                  }
                } else {
                  return connectFailed();
                }
              } else {
                return loadingBox();
              }
            },
          )),
    );
  }

  roomBox(name, numDevice) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ

    //เช้คว่า จำนวนอุปกรณ์มากกว่า 1 หรือป่าว เพราะหน่วยที่เป็นภาษาอังกฤษ ต้องเติม s
    String device = 'Device';
    if (numDevice != '1' && numDevice != '0') {
      device = 'Devices';
    }
    return Container(
      width: size.width * 0.9,
      height: size.height * 0.1,
      padding: const EdgeInsets.only(left: 30, right: 30),
      //color: Colors.red,
      child: Column(children: [
        SizedBox(
          width: size.width,
          height: 20,
        ),
        Row(
          children: [
            Container(
              width: size.width * 0.6,
              //color: Colors.red,
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                //mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Colors.black),
                  ),
                  Text(
                    '$numDevice $device',
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black38),
                  )
                ],
              ),
            ),
            // const Spacer(),
            // SizedBox(
            //   width: 40,
            //   child: TextButton(
            //       onPressed: () {
            //         //edit name
            //         print('Edit room name');
            //       },
            //       child: const Icon(
            //         Icons.edit,
            //         color: Colors.black,
            //       )),
            // ),
            // SizedBox(
            //   width: 40,
            //   child: TextButton(
            //       onPressed: () {
            //         //delete house name
            //         print('delete room');
            //       },
            //       child: const Icon(
            //         Icons.delete,
            //         color: Colors.black,
            //       )),
            // )
          ],
        ),
        const Spacer(),
        Container(
          width: size.width * 0.9,
          height: 1,
          color: Colors.black26,
        ),
      ]),
    );
  }

  connectFailed() {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Connection failed!',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            width: size.width * 0.3,
            height: size.height * 0.06,
            child: TextButton(
              style: TextButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                foregroundColor: Colors.white,
                padding: EdgeInsets.zero,
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {});
              },
              child: const Text(
                'Try again',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'FCfont',
                  fontSize: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  loadingBox() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 5),
          Card(
            shadowColor: Colors.transparent,
            elevation: 0,
            child: Text(
              'Loading...',
              style: TextStyle(
                  fontSize: 24, fontFamily: 'FCfont', color: Colors.black),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }
}
