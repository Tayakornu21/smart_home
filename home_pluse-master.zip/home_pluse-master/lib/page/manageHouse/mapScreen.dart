import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key, required this.latLngOld});

  final LatLng? latLngOld;

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  // final Completer<GoogleMapController> _controller = Completer();

  late LatLng latLng;
  bool getMark = false;

  //LocationData เพื่อใช้เก็บข้อมูลเกี่ยวกับตำแหน่ง
  late LocationData currentPosition;
  late LocationData currentLocation;

  //Marker เพื่อใช้ตั้งค่าเวลาแสดงมาร์คเกอร์บนแผนที่ google map
  late Marker marker;
  //สร้างลิสต์เพื่อเก็บมาร์คเกอร์
  List<Marker> myMarker = [];

  //ดึงตำแหน่ง location โดยใช้ location.getLocation() ซึ่งต้องระวังกรณีไม่มี permission ด้วย
  Future<LocationData?> getCurrentLocation() async {
    Location location = Location();
    try {
      return await location.getLocation();
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        // Permission denied
      }
      return null;
    }
  }

  //เขียน method สำหรับนำ currentLocation มาใช้กับ Google Maps
  //วิธีการคือ เอา Lat Lng มาใส่ใน CameraPosition แล้วกำหนด newCameraPosition ผ่าน GoogleMapController
  // Future _goToMe() async {
  //   print('My Location');
  //   final GoogleMapController controller = await _controller.future;
  //   currentLocation = (await getCurrentLocation())!;
  //การปรับตำแหน่งปัจจุบันบนแผนที่ด้วย animateCamera
  //   controller.animateCamera(
  //     CameraUpdate.newCameraPosition(
  //       CameraPosition(
  //         target: LatLng(currentLocation.latitude!, currentLocation.longitude!),
  //         zoom: 15,
  //       ),
  //     ),
  //   );
  // }

  @override
  void initState() {
    super.initState();
    if (widget.latLngOld != null) {
      myMarker.add(
        Marker(
          markerId: MarkerId(widget.latLngOld.toString()),
          position: widget.latLngOld ??
              const LatLng(16.748085837511482, 100.19215890103426),
          draggable: true,
          //ไอคอนหมุด
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          onDragEnd: (dragEndPosition) {
            setState(() {
              print(dragEndPosition);
            });
          },
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () => Navigator.pop(context, widget.latLngOld),
        ),
        actions: [
          TextButton(
            //ปุ่มเซฟ
            onPressed: getMark
                ? () {
                    print('latlng: $latLng');
                    Navigator.pop(context, latLng);
                  }
                : null,
            child: Text(
              "Save",
              style: TextStyle(
                color: getMark
                    ? const Color.fromARGB(255, 117, 138, 214)
                    : Colors.black38,
                fontWeight: FontWeight.w800,
              ),
            ),
          )
        ],
        toolbarHeight: size.height * 0.075,
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        title: const Text('Getting Location Point',
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: widget.latLngOld ??
              const LatLng(16.748085837511482,
                  100.19215890103426), //พิกัดมหาวิทยาลัยนเรศวร
          zoom: 15,
        ),
        myLocationEnabled: true, //ปุ่ม
        markers: Set.from(myMarker),
        mapType: MapType.normal,
        onTap: _handleTap,
      ),
      //ปุ่ม floatingActionButton จะใช้เหมือนต้องการให้แผนที่แสดงตำแหน่งของเครื่อง
      // floatingActionButton: FloatingActionButton.extended(
      //ดังนั้น onPressed: จึงเรียกฟังชัน _goToMe(),
      //   onPressed: _getLocation,
      //   label: const Text('My location'),
      //   icon: const Icon(Icons.near_me),
      // ),
    );
  }

  _handleTap(LatLng tappedPoint) {
    //ปริ้นท์ค่าแลติจูลองติจูด
    print(tappedPoint);
    setState(
      () {
        latLng = tappedPoint;
        getMark = true;
        myMarker = [];
        myMarker.add(
          Marker(
            markerId: MarkerId(tappedPoint.toString()),
            position: tappedPoint,
            draggable: true,
            //ไอคอนหมุด
            icon:
                BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
            onDragEnd: (dragEndPosition) {
              setState(() {
                print(dragEndPosition);
              });
            },
          ),
        );
      },
    );
  }
}
