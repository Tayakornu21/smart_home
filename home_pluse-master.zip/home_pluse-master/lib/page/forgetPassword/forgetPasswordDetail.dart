import 'package:flutter/material.dart';

import '../loginPage.dart';

class ForgetPasswordDetailPage extends StatefulWidget {
  const ForgetPasswordDetailPage({super.key});

  @override
  State<ForgetPasswordDetailPage> createState() =>
      _ForgetPasswordDetailPageState();
}

class _ForgetPasswordDetailPageState extends State<ForgetPasswordDetailPage> {
  TextEditingController otpPassword = TextEditingController();
  TextEditingController newPassword = TextEditingController();
  TextEditingController confirmNewPassword = TextEditingController();
  //show the password or not
  bool _isObscure = true; //pass
  bool _isObscure2 = true; //confirm pass
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => const LoginPage())),
          ),
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow

          iconTheme:
              const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: Container(
          width: size.width,
          height: size.height,
          color: Colors.white,
          child: Column(
              // mainAxisAlignment: MainAxisAlignment.start,
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: size.width,
                  height: size.height * 0.12,
                  //color: Colors.red,
                ),

                //text
                Container(
                    width: size.width,
                    height: size.height * 0.08,
                    //color: Colors.yellow,
                    alignment: Alignment.center,
                    child: const Text(
                      'Forgot password',
                      style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w600,
                          color: Color.fromARGB(255, 117, 138, 214)),
                    )),

                //textfield otp
                Container(
                  width: size.width,
                  height: size.height * 0.08,
                  //color: Colors.orange,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.only(
                      left: 40, right: 40, top: 10, bottom: 10),
                  child: TextField(
                    controller: otpPassword,
                    //obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      prefixIcon: const Icon(
                        Icons.email,
                        color: Colors.black,
                      ),
                      //labelText: 'รหัสยืนยัน',
                      contentPadding: const EdgeInsets.only(left: 20),
                      hintText: 'Verification code',
                      hintStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black26),
                    ),
                  ),
                ),

                //new password
                Container(
                  width: size.width,
                  height: size.height * 0.08,
                  //color: Colors.orange,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.only(
                      left: 40, right: 40, top: 10, bottom: 10),
                  child: TextField(
                    controller: newPassword,
                    obscureText: _isObscure,
                    decoration: InputDecoration(
                      suffixIcon: IconButton(
                          icon: Icon(_isObscure
                              ? Icons.visibility_off
                              : Icons.visibility),
                          onPressed: () {
                            setState(() {
                              _isObscure = !_isObscure;
                            });
                          }),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      prefixIcon: const Icon(
                        Icons.lock,
                        color: Colors.black,
                      ),
                      //labelText: 'รหัสยืนยัน',
                      contentPadding: const EdgeInsets.only(left: 20),
                      hintText: 'New password',
                      hintStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black26),
                    ),
                  ),
                ),

                //confirm passwoed
                Container(
                  width: size.width,
                  height: size.height * 0.08,
                  //color: Colors.orange,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.only(
                      left: 40, right: 40, top: 10, bottom: 10),
                  child: TextField(
                    controller: confirmNewPassword,
                    obscureText: _isObscure2,
                    decoration: InputDecoration(
                      suffixIcon: IconButton(
                          icon: Icon(_isObscure2
                              ? Icons.visibility_off
                              : Icons.visibility),
                          onPressed: () {
                            setState(() {
                              _isObscure2 = !_isObscure2;
                            });
                          }),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      prefixIcon: const Icon(
                        Icons.lock,
                        color: Colors.black,
                      ),
                      //labelText: 'รหัสยืนยัน',
                      contentPadding: const EdgeInsets.only(left: 20),
                      hintText: 'Confirm new password',
                      hintStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black26),
                    ),
                  ),
                ),

                Container(
                  width: size.width,
                  height: 20,
                  //color: Colors.red,
                ),

                //bt
                Container(
                  width: size.width * 0.3,
                  height: size.height * 0.06,
                  //color: Colors.red,
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.zero,
                      textStyle: const TextStyle(fontSize: 20),
                    ),
                    onPressed: () {
                      print(
                          'otp: ${otpPassword.text}, new pass: ${newPassword.text}, confirm pass: ${confirmNewPassword.text}');
                    },
                    child: const Text(
                      'Confirm',
                      style: TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ),
                )
              ]),
        ),
      ),
    );
  }
}
