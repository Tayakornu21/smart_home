import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/forgetPassword/forgetPasswordDetail.dart';

import '../loginPage.dart';

class ForgetPasswordPage extends StatefulWidget {
  const ForgetPasswordPage({super.key});

  @override
  State<ForgetPasswordPage> createState() => _ForgetPasswordPageState();
}

class _ForgetPasswordPageState extends State<ForgetPasswordPage> {
  TextEditingController gmailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () => Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => const LoginPage())),
          ),
          toolbarHeight: size.height * 0.075,
          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0, //remove shadow

          iconTheme: const IconThemeData(color: Color.fromARGB(255, 69, 47, 139)),
        ),
        body: Container(
          width: size.width,
          height: size.height,
          color: Colors.white,
          child: Column(
              // mainAxisAlignment: MainAxisAlignment.start,
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: size.width,
                  height: size.height * 0.12,
                  //color: Colors.red,
                ),

                //text
                Container(
                    width: size.width,
                    height: size.height * 0.08,
                    //color: Colors.yellow,
                    alignment: Alignment.center,
                    child: const Text(
                      'Forgot password',
                      style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w600,
                          color: Color.fromARGB(255, 117, 138, 214)),
                    )),

                Container(
                    width: size.width,
                    height: size.height * 0.05,
                    //color: Colors.yellow,
                    alignment: Alignment.topCenter,
                    child: const Text(
                      'Enter your registered email address.',
                      style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w600,
                          color: Colors.black38),
                    )),

                //textfield gmail
                Container(
                  width: size.width,
                  height: size.height * 0.08,
                  //color: Colors.orange,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.only(
                      left: 40, right: 40, top: 10, bottom: 10),
                  child: TextField(
                    controller: gmailController,
                    //obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      prefixIcon: const Icon(
                        Icons.email,
                        color: Colors.black,
                      ),
                      contentPadding: const EdgeInsets.only(left: 20),
                      hintText: 'Gmail',
                      hintStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black26),
                    ),
                  ),
                ),

                Container(
                  width: size.width,
                  height: 20,
                  //color: Colors.red,
                ),

                //bt
                Container(
                  width: size.width * 0.3,
                  height: size.height * 0.06,
                  //color: Colors.red,
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 117, 138, 214),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.zero,
                      textStyle: const TextStyle(fontSize: 20),
                    ),
                    onPressed: () {
                      print('gmail: ${gmailController.text}');
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const ForgetPasswordDetailPage()));
                    },
                    child: const Text(
                      'Send',
                      style: TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ),
                )
              ]),
        ),
      ),
    );
  }
}
