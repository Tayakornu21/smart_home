import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:geolocator/geolocator.dart';

import 'package:homeplus_phase1/cookiesValue.dart';
import 'package:homeplus_phase1/firebaseMessageProvider.dart';
//import 'package:intl/intl.dart';

import 'package:http/http.dart' as http;
import 'dart:math';

//! flutter_background_service : iOS not config and coding

setCountTimeApi(String sn, String countTimeStatus, DateTime timeStart,
    DateTime timeClose) async {
  // print('[setCountTimeApi in bg] Im setCountTimeApi function');
  // print(
  //     '[setCountTimeApi in bg] countTimeStatus: ${countTimeStatus.toString()}');
  // print('[setCountTimeApi in bg] timeStart: ${timeStart.toString()}');
  // print('[setCountTimeApi in bg] timeClose: ${timeClose.toString()}');

  String urlBase = await getUrlBase();
  Uri myUri = Uri.parse('$urlBase/countTime');
  try {
    http.Response response = await http.put(myUri,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        encoding: Encoding.getByName('utf-8'),
        body: {
          "serialNumber": sn,
          "countTimeStatus": countTimeStatus,
          "timerOpen": timeStart.toString(),
          'timerClose': timeClose.toString(),
        });

    // print('[setCountTimeApi in bg] status Code : ${response.statusCode}');
    // print('[setCountTimeApi in bg] response body: ${response.body}');

    var jsonResponse =
        jsonDecode(response.body); //decode json(change String json to map json)

    if (jsonResponse['error'] == false) {
      //send off shadow to netpie
      //หลังจากเพิ่มอุปกรณ์เสร้จจะ้ตองส่งคำสั่งควบคุอุปกรณ์ครั้งแรกให้เป็น off
      //return popup('Add device is complete.', 'move');
    } else {
      // return popup(
      //     'Failed to set counting time!\nSomething is wrong.', 'null');
      //nothin to do
    }
  } catch (e) {
    print('[setCountTimeApi in bg] error: $e');
    // popup("Failed to set counting time!\nConnection failed.",
    //     'null'); //wrong code or can't connect to server.
    //nothin to do
  }
}

Future<void> initializeService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      // this will be executed when app is in foreground or background in separated isolate
      onStart: onStart,

      // auto start service
      autoStart: true,
      isForegroundMode: true,
    ),
    iosConfiguration: IosConfiguration(
      // auto start service
      autoStart: true,

      // this will be executed when app is in foreground in separated isolate
      onForeground: onStart,

      // you have to enable background fetch capability on xcode project
      onBackground: onIosBackground,
    ),
  );

  service.startService();
}

@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  print('onStart background service android!');
  // Only available for flutter 3.0.0 and later
  DartPluginRegistrant.ensureInitialized();

  if (service is AndroidServiceInstance) {
    // print('setService');

    service.setAsBackgroundService();

    service.on('setAsForeground').listen((event) {
      print('setAsForeground');
      service.setAsForegroundService();
    });

    service.on('setAsBackground').listen((event) {
      print('setAsBackground');
      service.setAsBackgroundService();
    });
  }

  service.on('stopService').listen((event) {
    print('stopService');
    service.stopSelf();
  });

  // bring to foreground
  Timer.periodic(const Duration(seconds: 1), (timer) async {
    if (service is AndroidServiceInstance) {}

    // //call list of device that set time cookie [serialNumberAutoList]
    // //get serialNumberAutoList ข้อมูลอยู่ในรูปแบบ "text,text,text"
    // var serialNumberAutoList = '${await getCookie('serialNumberAutoList')}';
    // //  print('serialNumberAutoList: $serialNumberAutoList');
    // //convert string to list
    // List<String> tempList = serialNumberAutoList.split(
    //     ','); //TempList is list of device that set the duration of work in auto function
    // // print('finish convert string to list: $tempList');
    // //print('tempList[0]: ${tempList[0]}');

    // //print('time set of ${tempList[0]} is ${await getCookie(tempList[0])}');

    // //get each timer of device in dast List from cookie.
    // if (tempList.toString() != '[null]' && tempList.toString() != '[]') {
    //   for (int i = 0; i < tempList.length; i++) {
    //     var devicaValueList = await getCookie(
    //         tempList[i]); //recive: closetime,deviceName string type

    //     //   print('devicaValueList: $devicaValueList');
    //     //convert string to list
    //     List<String> tempDevicaValueList = devicaValueList.split(
    //         ','); //tempDevicaValueList[0] = closeTime ,tempDevicaValueList[1] = device Name

    //      print('tempDevicaValueList: $tempDevicaValueList');
    //      print('tempDevicaValueList[0]: ${tempDevicaValueList[0]}');
    //      print('tempDevicaValueList[1]: ${tempDevicaValueList[1]}');
    //     if (DateFormat('yyyy-MM-dd HH:mm:ss')
    //               .parse(DateTime.parse(tempDevicaValueList[0]).toString())
    //               .compareTo(DateFormat('yyyy-MM-dd HH:mm:ss')
    //                   .parse(DateTime.now().toString())) >
    //           0) {
    //         //continue count time
    //         //    print('${tempList[i]}: continue count time');
    //       } else {
    //         //time out!

    //         //call local notification
    //         sendNotification(
    //             title: "Counting time finished",
    //             body:
    //                 "The device ${tempDevicaValueList[1]} operation timer has ended.");

    //         //call api
    //         //ถ้าไม่สามารถส่ง api ได้ก็ไม่เป็นไร เพราะมีการแจ้งเตือน จาก local notification แล้วและหน้า settimer ก็มีการเช็คเวลาทุกครั้งที่เปิดหน้า set the duration of work
    //         setCountTimeApi(
    //             tempList[i],
    //             'idle',
    //             DateTime.parse('0000-01-01 00:00:00'),
    //             DateTime.parse('0000-01-01 00:00:00'));

    //         //  print('${tempList[i]}: TIME OUT!');
    //         await removeCookie(
    //             tempList[i]); // remove serial number from cookie.
    //         tempList.remove(tempList[i]); //remove serial number from list.

    //         //  print('remove out from list and cookie: ${tempList.toString()}');

    //         if (tempList.isEmpty) {
    //           removeCookie(
    //               "serialNumberAutoList"); // remove serial number from cookie.
    //         } else {
    //           String tempString =
    //               tempList.join(','); //change list of deviceAutoList to string
    //           setCookie(
    //               'serialNumberAutoList',
    //               tempString
    //                   .toString()); //save current device that set timer to cookie.
    //         }
    //         break;
    //       }

    //   }
    // } else {
    //   //print('tempList is []');
    //   //notting
    // }

    //map notification

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.always) {
      //ร้องขอการเข้าถึงตำแหน่งปัจจุบัน
      //check null of lat and long of main house before start mapCheck fn.
      //check lat aand long
      var houseLat = await getCookie('mainHouseLat');
      var houseLong = await getCookie('mainHouseLong');
      var numDevice = await getCookie('numDeviceInHouse');

      print('numDevice: $numDevice');

      // print('houseLat: $houseLat');
      // print('houseLong: $houseLong');
      //print('$houseLat , $houseLat');
      if (houseLat != "null" && houseLong != "null" && numDevice != "null") {
        //print('have lat and long');
        mapCheck(houseLat, houseLong);
      }
    }

    /// you can see this log in logcat
    // if (c > 0) {
    //   //${DateTime.now()}
    //   print('FLUTTER BACKGROUND SERVICE: $c ');
    //   c--;
    // } else {
    //   print('STOP BACKGROUND SERVICE!');
    //   await service.stopSelf();
    // }
  });
}

mapCheck(String houseLat, String houseLong) async {
  if (houseLat != "0" || houseLong != "0") {
    //print('mapCheck fn');
    //check open gps
    bool servicestatus = await Geolocator.isLocationServiceEnabled();

    if (servicestatus) {
      //print("GPS service is enabled");

      //String long = "", lat = "";

      //code here
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      // print(position.longitude); //Output: 80.24599079
      // print(position.latitude); //Output: 29.6593457

      // LocationSettings locationSettings = const LocationSettings(
      //   accuracy: LocationAccuracy.high, //accuracy of the location data
      //   distanceFilter: 100, //minimum distance (measured in meters) a
      //   //device must move horizontally before an update event is generated;
      // );

      // StreamSubscription<Position> positionStream =
      //     Geolocator.getPositionStream(locationSettings: locationSettings)
      //         .listen((Position position) {
      //   print(position.longitude); //Output: 80.24599079
      //   print(position.latitude); //Output: 29.6593457

      //   long = position.longitude.toString();
      //   lat = position.latitude.toString();
      // });

      var distanceKm = calculateDistance(double.parse(houseLat),
          double.parse(houseLong), position.latitude, position.longitude);

      var goOut = await getCookie('goOutStatus');

      if (distanceKm > 0.2 && goOut != "true") {
        //testsend localnoti
        //sendNotification(title: "Go out your zone", body: 'Test notification');
        //move out of main house 100m
        //set goOut is ture;
        await setCookie('goOutStatus', 'true');
      }

      if (distanceKm < 0.2 && goOut == 'true') {
        //come back to main house
        //send notification
        sendNotification(
            title: "Turn on some devices?",
            body: 'Do you want to turn on some devices before you get home?');

        //remove goOutStatus
        await removeCookie('goOutStatus');
      }
    } else {
      //print("GPS service is disabled.");
    }
  }
  //print('mapCheck fn');
  // LocationPermission permission = await Geolocator.checkPermission();
  // if (permission == LocationPermission.denied) {
  //   print('Location permissions are denied');
  // } else if (permission == LocationPermission.deniedForever) {
  //   print("'Location permissions are permanently denied");
  // } else {
  //   print("GPS Location service is granted");

  // }
}

//lat, long 1 = house lat,long
//lat, long 2 = current location of phone
double calculateDistance(lat1, lon1, lat2, lon2) {
  var p = 0.017453292519943295;
  var a = 0.5 -
      cos((lat2 - lat1) * p) / 2 +
      cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
  return 12742 * asin(sqrt(a));
}

//! ยังไงมีการใช้ iOS
// to ensure this is executed
// run app from xcode, then from xcode menu, select Simulate Background Fetch
@pragma('vm:entry-point')
Future<bool> onIosBackground(ServiceInstance service) async {
  WidgetsFlutterBinding.ensureInitialized();
  DartPluginRegistrant.ensureInitialized();

  //code here!

  // SharedPreferences preferences = await SharedPreferences.getInstance();
  // await preferences.reload();
  // final log = preferences.getStringList('log') ?? <String>[];
  // log.add(DateTime.now().toIso8601String());
  // await preferences.setStringList('log', log);

  return true;
}
