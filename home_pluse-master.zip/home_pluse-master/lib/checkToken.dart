// ignore_for_file: avoid_print

import 'dart:convert';
//import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; //libary สำหรับเรียกใช้ค่าใน local Storage
import 'package:http/http.dart' as http;

import 'page/loginPage.dart'; //libary สำหรับการเรียกใช้ api

checkToken(context) async {
  //SharedPreferences prefs = await SharedPreferences.getInstance();
  String temp = await getUserId();
  String urlBase = await getUrlBase();
  String token = await getToken();

  // print('[checkToken] userid(temp) : $temp');
  // print('[checkToken] urlBase : $urlBase');

  Uri myUri = Uri.parse('$urlBase/checkToken');

  try {
    http.Response response = await http.post(myUri,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        encoding: Encoding.getByName('utf-8'),
        body: {"userid": temp});

    // print('[checkToken] status Code : ${response.statusCode}');
    // print('[checkToken] response body : ${response.body}');

    var jsonResponse = jsonDecode(response.body);
    if (jsonResponse['error'].toString() == 'false') {
      print('[checkToken] res token : ${jsonResponse['data']['token']}');
      //check token
      if (jsonResponse['data']['token'] == token) {
        //it's ok
        print('[checkToken] finsih ok!');
        return "ok";
      } else {
        print('[checkToken] finsih not same token!');
        popup("This account is logged in another device!", context);
        throw Exception("tokens are not the same!");
      }
    } else {
      //err throw err
      throw Exception("response error: true");
    }
  } catch (e) {
    print('[checkToken] error: $e');
    return e.toString();
    //return null;
  }
}

getUrlBase() async {
  print('[getUrlBase] Im in  getUrlBase');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var urlBase = prefs.getString('urlBase');
  return urlBase.toString();
}

getUserId() async {
  print('[getUserId] Im in  getUserId');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var userId = prefs.getString('userId');
  //print('[getUserId] userId: $userId');
  return userId.toString();
  //prefs.setString('accessToken', token);
}

getToken() async {
  print('[getToken] Im in  getToken');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var token = prefs.getString('tokenPhone');
  //print('[getUserId] userId: $userId');
  return token.toString();
  //prefs.setString('accessToken', token);
}

popup(text, context) {
  return showDialog<String>(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) => WillPopScope(
      onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
      child: AlertDialog(
        //title: const Text('Something is worng!'),
        contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 20),
        content: Container(
          //width: size.width,
          height: 80,
          alignment: Alignment.center,
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 24, fontWeight: FontWeight.w600, color: Colors.black),
          ),
        ),
        actions: <Widget>[
          Container(
            //width: size.width,
            alignment: Alignment.center,
            child: TextButton(
              onPressed: () {
                mainFirstHouseClear();
                cookiesClear();
                Navigator.pop(context, 'Cancel');
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => const LoginPage()));
              },
              child: const Text(
                'Ok',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Color.fromARGB(255, 117, 138, 214)),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

mainFirstHouseClear() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  //mainHouse หริอ mainNameHouse คือบ้่านที่เราเลือกให้แสดงในหน้า main page
  prefs.remove('mainHouseid'); //ลบค่าของ mainHouseid ที่มีใน local Storage
  prefs.remove('mainNameHouse'); //ลบค่าของ mainNameHouse ที่มีใน local Storage
  prefs.remove('mainHouseLat');
  prefs.remove('mainHouseLong');
}

cookiesClear() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  prefs.remove('userId'); //ลบค่าของ userId ที่มีใน local Storage
  //prefs.remove('demo'); //for demo
  prefs.remove('userName'); //ลบค่าของ userName ที่มีใน local Storage
  prefs.remove('urlBase');
}
