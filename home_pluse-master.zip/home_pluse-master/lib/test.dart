import 'package:flutter/material.dart';

//ไฟล์นีสำหรับการทดสอบโค้ด ไม่ได้ถูกใช้งานในส่วนของแอป

class TestPage extends StatefulWidget {
  const TestPage({super.key});

  @override
  State<TestPage> createState() => _TestPageState();
}

class _TestPageState extends State<TestPage> {
  var list1 = {'Bedroom', 'Bathroom'};
  var text = 'Bathroom';
  var list2 = [
    {'name': 'test1', 'id': '1', 'room': 'Bedroom'},
    {'name': 'test2', 'id': '2', 'room': 'Bedroom'},
    {'name': 'test3', 'id': '3', 'room': 'Bathroom'},
    {'name': 'test4', 'id': '4', 'room': 'ttt'}
  ];
  var list3;

  //---------------------------------------
  List<dynamic> deviceList = [
    {'name': 'test1', 'id': '1', 'room': 'Bedroom'},
    {'name': 'test2', 'id': '2', 'room': 'Bedroom'},
    {'name': 'test3', 'id': '3', 'room': 'Bathroom'},
    {'name': 'test4', 'id': '4', 'room': 'ttt'}
  ]; //เก็บ List of device
  var filterDevice; //filter device โดยอ้างอิงจากรายชื่อของห้องใน roomlist

  filterDeviceFunction(nR) {
    //nR = name room
    filterDevice = deviceList.where((map) => nR.contains(map["room"])).toList();
    return filterDevice.length.toString();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    //list3 = list2.where((map) => text.contains(map["room"]!)).toList();
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        body: Container(
          width: size.width,
          height: size.height,
          color: Colors.white,
          child: Center(
              child: Text(
            filterDeviceFunction(text),
            style: const TextStyle(fontSize: 18, color: Colors.black),
          )),
        ),
      ),
    );
  }
}
