import 'package:flutter/material.dart';
import 'package:homeplus_phase1/page/autoFunction/mainAutoFunction.dart';
import 'package:homeplus_phase1/page/profilePage.dart';

import '../page/mainPage.dart';
//import '../page/notificationPage.dart';


//ไฟล์นี้จะเป็น navbar(แถบเมนู) ที่ใช้ในการเลือกหน้า ตัว navbar จะเป็นตัวเรียกหน้า main, notification และ profile มาแสดง

class NavigationBottomBarWidget extends StatefulWidget {
  const NavigationBottomBarWidget({Key? key}) : super(key: key);

  @override
  State<NavigationBottomBarWidget> createState() =>
      _NavigationBottomBarWidgetState();
}

class _NavigationBottomBarWidgetState extends State<NavigationBottomBarWidget> {
  int _selectedIndex = 0; //index สำหรับกำหนดว่าตอนนี้ navbar เรียกใช้ หน้าอะไรอยุ่

  //ตรงนี้เป็น list ของหน้าที่เราต้องการให้ navbar นำมาแสดงได้
  final _pageOptions = [
    const MainPage(),
    const MainAutoFunctionPage(),
    const ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    //Size size = MediaQuery.of(context).size; //เอาไว้กำหนดขนาดของจอ
    return WillPopScope( //WillPopScope ใช้ในการปิดการกดปุ่มย้อนกลับในมือถือ
      onWillPop: () async => false, //ตรงนี้จะเป็นการปิดการกดปุ่มน้อรกลับในมือถือ
      child: Scaffold(
          body: Center(child: _pageOptions.elementAt(_selectedIndex)), // body ของ scaffold(ส่วนที่แสดงผลในแอป) ให้แสดงหน้าที่ถูกเลือก
          bottomNavigationBar: SizedBox( //ตรงนี้จะเป็นแถบเมนู
            height: 85,
            child: BottomNavigationBar(
              iconSize: 30, //ขนาดของไอคอนในแถบเมนู
              selectedIconTheme: const IconThemeData(
                  color: Color.fromARGB(255, 117, 138, 214), size: 40), //เลือกแล้วใหเแสดงสีอะไร
              selectedItemColor: const Color.fromARGB(255, 117, 138, 214),  //เลือกแล้วใหเแสดงสีอะไร
              backgroundColor: Colors.white, //พื้นหลังของแถบเมนู
              items: const <BottomNavigationBarItem>[ //จำนวนปุ่มที่กดได้ในแถบเมนู
                //หน้าหลัก (index: 0)
                BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'), 
                //หน้าแจ้งเตือน (index: 1)
                BottomNavigationBarItem(
                    icon: Icon(Icons.auto_awesome_mosaic), label: 'Auto Function'), 
                //หน้าโปรไฟล์ (index: 2)
                BottomNavigationBarItem( 
                    icon: Icon(Icons.person), label: 'Profile') 
              ],
              currentIndex: _selectedIndex, //index ปัจจุบัน อิงตามค่า _selectedIndex 
              onTap: _onItemTapped, //เหมือนมีการกดแถบเมนูจะเรียกใช้ ฟังก์ชั่น _onItemTapped
            ),
          )),
    );
  }

  //ฟังก์ชั่นนี้ใช้สำหรับการกำหนดค่าใหม่ให้กับ _selectedIndex 
  //เมื่อกดเมนู index ตัวใหม่ค่า _selectedIndex ก็จะถูกเซตใหม่ currentIndex ก็จะเปลี่ยน การแสดงผลในส่วนของ body ก้จะเปลี่ยนตามไปด้วย
  void _onItemTapped(int index) {
    setState(() { //setState เป็นการรีหน้าแอปใหม่อีกครั้ง ในส่วนนี้จะเป็นการกำหนดค่า _selectedIndex ก่อนหลังจากนั้นก็จะรีหน้าใหม่
      _selectedIndex = index;
    });
  }
}
