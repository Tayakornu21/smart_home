import 'package:shared_preferences/shared_preferences.dart'; //libary สำหรับเรียกใช้ค่าใน local Storage

setCookie(String key, String value) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  prefs.setString(key, value); //set userId to localstorage
}

getCookie(String key) async {
  //print('[getCookie] Im in  getCookie $key');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  var value = prefs.getString(key);
  return value.toString();
}

removeCookie(String key) async {
  print('[removeCookie] Im im removeCookie $key');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  await prefs.reload();
  prefs.remove(key);
}

getUrlBase() async {
  print('[getUrlBase] Im in  getUrlBase');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  var urlBase = prefs.getString('urlBase');
  return urlBase.toString();
}

getUserId() async {
  print('[getUserId] Im in  getUserId');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  //print('[getUserId] userId: $userId');
  return prefs.getString('userId').toString();
  //prefs.setString('accessToken', token);
}

getHouseId() async {
  print('[getHouseId] Im in  getHouseId');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  //print('[getHouseId] mainNameHouse: $mainNameHouse');
  return prefs.getString('mainHouseid').toString();
  //prefs.setString('accessToken', token);
}
