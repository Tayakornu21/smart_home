// To parse this JSON data, do
//
//     final getAllPersonInHouse = getAllPersonInHouseFromJson(jsonString);

import 'dart:convert';

GetAllPersonInHouse getAllPersonInHouseFromJson(String str) =>
    GetAllPersonInHouse.fromJson(json.decode(str));

String getAllPersonInHouseToJson(GetAllPersonInHouse data) =>
    json.encode(data.toJson());

class GetAllPersonInHouse {
  GetAllPersonInHouse({
    required this.error,
    required this.message,
    required this.data,
  });

  bool error;
  String message;
  List<Datum> data;

  factory GetAllPersonInHouse.fromJson(Map<String, dynamic> json) =>
      GetAllPersonInHouse(
        error: json["error"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "error": error,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    required this.userid,
    required this.email,
    required this.userName,
    required this.role,
  });

  int userid;
  String email;
  String userName;
  String role;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        userid: json["userid"],
        email: json["email"],
        userName: json["userName"],
        role: json["role"],
      );

  Map<String, dynamic> toJson() => {
        "userid": userid,
        "email": email,
        "userName": userName,
        "role": role,
      };
}
