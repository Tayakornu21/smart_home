// To parse this JSON data, do
//
//     final getDeviceAutoListModel = getDeviceAutoListModelFromJson(jsonString);

import 'dart:convert';

GetDeviceAutoListModel getDeviceAutoListModelFromJson(String str) => GetDeviceAutoListModel.fromJson(json.decode(str));

String getDeviceAutoListModelToJson(GetDeviceAutoListModel data) => json.encode(data.toJson());

class GetDeviceAutoListModel {
    bool error;
    String message;
    List<Datum> data;

    GetDeviceAutoListModel({
        required this.error,
        required this.message,
        required this.data,
    });

    factory GetDeviceAutoListModel.fromJson(Map<String, dynamic> json) => GetDeviceAutoListModel(
        error: json["error"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "error": error,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class Datum {
    String serialNumber;
    String deviceName;
    String room;
    String clientId;
    String token;
    String setTimeStatus;
    String countTimeStatus;

    Datum({
        required this.serialNumber,
        required this.deviceName,
        required this.room,
        required this.clientId,
        required this.token,
        required this.setTimeStatus,
        required this.countTimeStatus,
    });

    factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        serialNumber: json["serialNumber"],
        deviceName: json["deviceName"],
        room: json["room"],
        clientId: json["clientID"],
        token: json["token"],
        setTimeStatus: json["setTimeStatus"],
        countTimeStatus: json["countTimeStatus"],
    );

    Map<String, dynamic> toJson() => {
        "serialNumber": serialNumber,
        "deviceName": deviceName,
        "room": room,
        "clientID": clientId,
        "token": token,
        "setTimeStatus": setTimeStatus,
        "countTimeStatus": countTimeStatus,
    };
}
