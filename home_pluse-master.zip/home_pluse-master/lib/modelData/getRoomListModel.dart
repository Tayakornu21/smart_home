// To parse this JSON data, do
//
//     final getRoomListModel = getRoomListModelFromJson(jsonString);

import 'dart:convert';

GetRoomListModel getRoomListModelFromJson(String str) => GetRoomListModel.fromJson(json.decode(str));

String getRoomListModelToJson(GetRoomListModel data) => json.encode(data.toJson());

class GetRoomListModel {
    GetRoomListModel({
        required this.error,
        required this.message,
        required this.data,
    });

    bool error;
    String message;
    List<Datum> data;

    factory GetRoomListModel.fromJson(Map<String, dynamic> json) => GetRoomListModel(
        error: json["error"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "error": error,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class Datum {
    Datum({
        required this.room,
    });

    String room;

    factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        room: json["room"],
    );

    Map<String, dynamic> toJson() => {
        "room": room,
    };
}
