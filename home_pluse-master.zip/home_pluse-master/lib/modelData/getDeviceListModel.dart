// To parse this JSON data, do
//
//     final getDeviceListModel = getDeviceListModelFromJson(jsonString);

import 'dart:convert';

GetDeviceListModel getDeviceListModelFromJson(String str) => GetDeviceListModel.fromJson(json.decode(str));

String getDeviceListModelToJson(GetDeviceListModel data) => json.encode(data.toJson());

class GetDeviceListModel {
    GetDeviceListModel({
      required  this.error,
      required  this.message,
      required  this.data,
    });

    bool error;
    String message;
    List<Datum> data;

    factory GetDeviceListModel.fromJson(Map<String, dynamic> json) => GetDeviceListModel(
        error: json["error"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "error": error,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class Datum {
    Datum({
        required this.serialNumber,
        required this.deviceName,
       required this.room,
    });

    String serialNumber;
    String deviceName;
    String room;

    factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        serialNumber: json["serialNumber"],
        deviceName: json["deviceName"],
        room: json["room"],
    );

    Map<String, dynamic> toJson() => {
        "serialNumber": serialNumber,
        "deviceName": deviceName,
        "room": room,
    };
}
