// To parse this JSON data, do
//
//     final getHouseListModel = getHouseListModelFromJson(jsonString);

import 'dart:convert';

GetHouseListModel getHouseListModelFromJson(String str) =>
    GetHouseListModel.fromJson(json.decode(str));

String getHouseListModelToJson(GetHouseListModel data) =>
    json.encode(data.toJson());

class GetHouseListModel {
  GetHouseListModel({
    required this.error,
    required this.message,
    required this.data,
    required this.myHouse,
  });

  bool error;
  String message;
  List<Datum> data;
  List<MyHouse> myHouse;

  factory GetHouseListModel.fromJson(Map<String, dynamic> json) =>
      GetHouseListModel(
        error: json["error"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
        myHouse:
            List<MyHouse>.from(json["myHouse"].map((x) => MyHouse.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "error": error,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
        "myHouse": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    required this.userid,
    required this.houseid,
    required this.houseName,
    required this.latitude,
    required this.longitude,
  });

  int userid;
  int houseid;
  String houseName;
  String latitude;
  String longitude;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        userid: json["userid"],
        houseid: json["houseid"],
        houseName: json["houseName"],
        latitude: json["latitude"],
        longitude: json["longitude"],
      );

  Map<String, dynamic> toJson() => {
        "userid": userid,
        "houseid": houseid,
        "houseName": houseName,
        "latitude": latitude,
        "longitude": longitude,
      };
}

class MyHouse {
  MyHouse({
    required this.userid,
    required this.houseid,
    required this.houseName,
    required this.latitude,
    required this.longitude,
  });

  int userid;
  int houseid;
  String houseName;
  String latitude;
  String longitude;

  factory MyHouse.fromJson(Map<String, dynamic> json) => MyHouse(
        userid: json["userid"],
        houseid: json["houseid"],
        houseName: json["houseName"],
        latitude: json["latitude"],
        longitude: json["longitude"],
      );

  Map<String, dynamic> toJson() => {
        "userid": userid,
        "houseid": houseid,
        "houseName": houseName,
        "latitude": latitude,
        "longitude": longitude,
      };
}
