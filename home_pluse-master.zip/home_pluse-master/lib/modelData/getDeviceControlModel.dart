// To parse this JSON data, do
//
//     final getDeviceControlModel = getDeviceControlModelFromJson(jsonString);

import 'dart:convert';

GetDeviceControlModel getDeviceControlModelFromJson(String str) =>
    GetDeviceControlModel.fromJson(json.decode(str));

String getDeviceControlModelToJson(GetDeviceControlModel data) =>
    json.encode(data.toJson());

class GetDeviceControlModel {
  GetDeviceControlModel({
    required this.error,
    required this.message,
    required this.data,
  });

  bool error;
  String message;
  Data data;

  factory GetDeviceControlModel.fromJson(Map<String, dynamic> json) =>
      GetDeviceControlModel(
        error: json["error"],
        message: json["message"],
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "error": error,
        "message": message,
        "data": data.toJson(),
      };
}

class Data {
  Data({
    required this.serialNumber,
    required this.deviceName,
    required this.room,
    required this.houseid,
    required this.clientId,
    required this.token,
    required this.secret,
  });

  String serialNumber;
  String deviceName;
  String room;
  int houseid;
  String clientId;
  String token;
  String secret;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        serialNumber: json["serialNumber"],
        deviceName: json["deviceName"],
        room: json["room"],
        houseid: json["houseid"],
        clientId: json["clientID"],
        token: json["token"],
        secret: json["secret"],
      );

  Map<String, dynamic> toJson() => {
        "serialNumber": serialNumber,
        "deviceName": deviceName,
        "room": room,
        "houseid": houseid,
        "clientID": clientId,
        "token": token,
        "secret": secret,
      };
}
