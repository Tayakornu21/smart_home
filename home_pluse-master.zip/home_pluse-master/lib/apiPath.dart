//กำหนด api path ที่นี่
//String apiPath = "http://10.58.41.29:3000";

String apiPath = "https://xeuslab.nu.ac.th/api/smartHouse";
//String apiPath = "http://10.58.41.29:3045";
//String apiPath = "http://203.154.158.166/api/smartHouse";


// real api of citcome server
//https://xeuslab.nu.ac.th/api/smartHouse

//real api inet
// http://203.154.158.166/api


//Netpie account
//gmail: XeusLab_Dev01@hotmail.com
//pass: xeuslabee703



//======================================//
//                                      //
//  Note สำหรับเรื่องต่างๆ ที่อาจจะลืมได้ในอนาคต  //
//                                      //            
//======================================//


// การทดสอบการเพิ่มคนในบ้าน และ socketio สำหรับ local server
//     1.รันดาต้าเบส จะมีการ Inser user ให้ 2 account
//     2.สามารถทดสอบการ api เพิ่มคนในบ้านได้เล
//     3.สำหรับการทดสอบเพิ่มอุปกรณ์ให้ทำการสร้าง serialNumber ขึ้นมาก่อน
//     4.addDevice and updateDevice ตามลำดับ
//     5.ทำการ upload code ให้กับ ตัว node mcu
//     6.config wifi และให้ clientid , username, password ตามที่ได้รับมาจากการ addDevice
