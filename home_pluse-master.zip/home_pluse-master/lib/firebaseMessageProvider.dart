// ignore_for_file: unused_import, unnecessary_null_comparison, unused_field

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:homeplus_phase1/cookiesValue.dart';
import 'package:homeplus_phase1/page/loginPage.dart';
import 'package:homeplus_phase1/widget/navigationBottomBarWidget.dart';
import 'package:shared_preferences/shared_preferences.dart';

// notification อย่างแรกต้องมี firebase_messaging เพื่อรับค่า token จากมือถือใช้ในการรับ noti จาก firebase
// local notification ใช้ในการแสดงการแจ้งเตือนเมื่อเราเปิดใช้งานแอปพลิเคชั่่น
// เดิมทีแล้วเราสามารถรับ notification จาก firebase ได้เมื่อลง package firebase_messaging แต่จะสามารถรับได้เมื่อแอปเราถูกปิดเท่านั้น
// ดั้งนั้นจึงต้องนำ local notification มาใช้งานเพื่อให้มีการแจ้งเตือนเมื่อเปิดแอปด้วย

// ref. สำหรับการทำ notifcation
// https://youtu.be/qbApeKz50Pg (มาสเตอร์อึ่ง ep.78 - 81) เป็น config firebase และการใช้งาน firebase noti พร้อมกับตัว แอปพลิเคชั่น
// https://youtu.be/yEqb3EjDolI เป็นการเรียกใช้ local notification เมื่อมีการส้ง notification จาก firebase
// https://youtu.be/ZYkRZ1tRdEs เป็นการสร้าง api สำหรับส่ง notification ไปยัง firebase เพื่อให้ firebase ส่ง noti มายังตัวแอปพลิเคชั่น
//! ยังไม่ได้ cofig การใช้งานตัว local notification สำหรับ iOS

//! การแจ้งเตือนจาก firebase messaging มีแค่ multi login กับการเพิ่มคนเข้าบ้าน และจะเกิดการแจ้งเตือนได้เมื่อ user login เข้าใช้งานได้เท่านั้น

class NotificationListenerProvider {
  final _firebaseMessaging = FirebaseMessaging.instance.getInitialMessage();

  void getMessage(context) {
    print("getMessage Notification :::::::::::::::::::::::::::");
    FirebaseMessaging.onMessage.listen((RemoteMessage event) async {
      RemoteNotification notification = event.notification!;
      Map<String, dynamic> notificationData = event.data;

      print(":::::::::::::::::::::::::::: ${notification}");

      // AppleNotification apple = event.notification!.apple!;
      AndroidNotification androidNotification = event.notification!.android!;

      // get userid
      String useridNow = await getUserId();

      if (notification != null && androidNotification != null) {
        print(":::::::::::::::::::::::::::: noti not null");
        print("notificationData userid:${notificationData["userid"]}");
        //split noti body for get userid
        // String oldUserid;
        // try {
        //   oldUserid = notification.body!.split(":")[1];
        // } catch (e) {
        //   print("oldUserid is null");
        //   oldUserid = "";
        // }

        //print("noti userid: $oldUserid");
        //print("now userid: $useridNow");

        //(OK)TODOWORK(): check userid for notification
        //จะแจ้งเตือนเฉพาะตอนที่ user login อยู่เท่านั้น

        if (notificationData["userid"].toString() == useridNow.toString()) {
          if (notification.title! == "Double login") {
            // /This account logged in another device
            showDialog(
                barrierDismissible: false,
                context: context,
                builder: (context) {
                  return WillPopScope(
                    onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
                    child: AlertDialog(
                      // title: Text(notification.title!),
                      contentPadding:
                          const EdgeInsets.only(left: 20, right: 20, top: 20),
                      content: Container(
                        //width: size.width,
                        height: 80,
                        alignment: Alignment.center,
                        child: Text(
                          notification.body!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w600,
                              color: Colors.black),
                        ),
                      ),
                      actions: [
                        Container(
                          //width: size.width,
                          alignment: Alignment.center,
                          child: TextButton(
                            onPressed: () {
                              //(OK)TODOWORK:clear cookies for logout here!
                              clearCookies();
                              Navigator.pop(context, 'Cancel');
                              //(OK)TODOWORK: navigator replement to login page
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const LoginPage()));
                            },
                            child: const Text(
                              'Ok',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: Color.fromARGB(255, 117, 138, 214)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                });

            // if (oldUserid.toString() == useridNow.toString()) {
            //   ///Show Alert dialog

            // } else {
            //   print("userID : $oldUserid logout ready!");
            // }
          } else if (notification.title! == "Device offline") {
            print('device offline notificaiton.');
            if ((notificationData["clientid"].toString() ==
                        await getCookie("clientIdSelectedDevice") ||
                    notificationData["clientid"].toString() ==
                        await getCookie("clientIDAuto")) &&
                await getCookie("cancelAuto") != "ture") {
              showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (context) {
                    return WillPopScope(
                      onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
                      child: AlertDialog(
                        // title: Text(notification.title!),
                        contentPadding:
                            const EdgeInsets.only(left: 20, right: 20, top: 20),
                        content: Container(
                          //width: size.width,
                          height: 80,
                          alignment: Alignment.center,
                          child: const Text(
                            "This device is offline now!",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                color: Colors.black),
                          ),
                        ),
                        actions: [
                          Container(
                            //width: size.width,
                            alignment: Alignment.center,
                            child: TextButton(
                              onPressed: () {
                                Navigator.pop(context, 'Cancel');
                                //(OK)TODOWORK: navigator replement to login page

                                Navigator.of(context).pushReplacement(
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const NavigationBottomBarWidget()));
                              },
                              child: const Text(
                                'Ok',
                                style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Color.fromARGB(255, 117, 138, 214)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  });
            } else {
              sendNotification(
                  title: notification.title!, body: notification.body);
            }
          } else if (notification.title! == "Finish count time") {
            print('device Finish count time notificaiton.');
            if ((notificationData["clientid"].toString() ==
                        await getCookie("clientIdSelectedDevice")) &&
                await getCookie("cancelAuto") != "ture") {
              showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (context) {
                    return WillPopScope(
                      onWillPop: () async => false, //ปิดการกดย้อนกลับขอมือถือ
                      child: AlertDialog(
                        // title: Text(notification.title!),
                        contentPadding:
                            const EdgeInsets.only(left: 20, right: 20, top: 20),
                        content: Container(
                          //width: size.width,
                          height: 80,
                          alignment: Alignment.center,
                          child: const Text(
                            "This device is finish count time!",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                color: Colors.black),
                          ),
                        ),
                        actions: [
                          Container(
                            //width: size.width,
                            alignment: Alignment.center,
                            child: TextButton(
                              onPressed: () {
                                Navigator.pop(context, 'Cancel');
                                //(OK)TODOWORK: navigator replement to login page

                                Navigator.of(context).pushReplacement(
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const NavigationBottomBarWidget()));
                              },
                              child: const Text(
                                'Ok',
                                style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                    color: Color.fromARGB(255, 117, 138, 214)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  });
            } else {
              sendNotification(
                  title: notification.title!, body: notification.body);
            }
          } else {
            //another noti not show dialog
            print(":::::::::::::::::::::::::::: show noti func");

            ///Show local notification
            sendNotification(
                title: notification.title!, body: notification.body);
            // body: oldUserid.toString() != ""
            //     ? notification.body!.split(":")[0]
            //     : notification.body);
          }
        }
      }
    });
  }
}

getUserId() async {
  print('[getUserId] Im in  getUserId');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  prefs.getString('userId');
  //print('[getUserId] userId: $userId');
  return prefs.getString('userId').toString();
  //prefs.setString('accessToken', token);
}

clearCookies() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  //mainHouse หริอ mainNameHouse คือบ้่านที่เราเลือกให้แสดงในหน้า main page
  prefs.remove('mainHouseid'); //ลบค่าของ mainHouseid ที่มีใน local Storage
  prefs.remove('mainNameHouse'); //ลบค่าของ mainNameHouse ที่มีใน local Storage

  prefs.remove('userId'); //ลบค่าของ userId ที่มีใน local Storage
  //prefs.remove('demo'); //for demo
  prefs.remove('userName'); //ลบค่าของ userName ที่มีใน local Storage
  //prefs.remove('urlBase');
}

void sendNotification({String? title, String? body}) async {
  //::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::://

  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  ////Set the settings for various platform
  // initialise the plugin. app_icon needs to be a added as a drawable resource to the Android head project
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  // const IOSInitializationSettings initializationSettingsIOS =
  //     IOSInitializationSettings(
  //   requestAlertPermission: true,
  //   requestBadgePermission: true,
  //   requestSoundPermission: true,
  // );

  const InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
    //iOS: initializationSettingsIOS,
  );

  await flutterLocalNotificationsPlugin.initialize(
    initializationSettings,
  );

  //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::://

  ///
  const AndroidNotificationDetails androidNotificationDetails =
      AndroidNotificationDetails(
          'high_channel_01', 'High Importance Notification',
          channelDescription: 'This channel is for important notification',
          importance: Importance.max,
          priority: Priority.high,
          ticker: 'ticker');

  const NotificationDetails platformChannelDetails = NotificationDetails(
    android: androidNotificationDetails,
  );

  await flutterLocalNotificationsPlugin.show(
      0, title, body, platformChannelDetails);
}
